import { CheatsheetShell } from "@/components/cheatsheet/cheatsheet-shell"

export default function Page() {
  return <CheatsheetShell />
}
