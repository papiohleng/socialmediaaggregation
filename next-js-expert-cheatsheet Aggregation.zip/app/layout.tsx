import React from "react"
import type { Metadata, Viewport } from 'next'
import { Inter, JetBrains_Mono } from 'next/font/google'

import './globals.css'

const _inter = Inter({ subsets: ['latin'], variable: '--font-inter' })
const _jetbrains = JetBrains_Mono({ subsets: ['latin'], variable: '--font-jetbrains' })

export const metadata: Metadata = {
  title: 'The Next.js Codex | The Definitive Cheatsheet',
  description: 'The most comprehensive Next.js + Supabase reference ever assembled. 15 chapters covering routing, rendering, data fetching, auth, real-time, RLS, and maximum SEO.',
  openGraph: {
    title: 'The Next.js Codex',
    description: 'Every concept, pattern, and API in Next.js + Supabase — 15 chapters, SEO mastery, complete production coverage.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  themeColor: '#0f1117',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${_inter.variable} ${_jetbrains.variable}`}>
      <body className="font-sans antialiased">{children}</body>
    </html>
  )
}
