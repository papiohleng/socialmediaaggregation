"use client"

import { Search, SlidersHorizontal, X, ArrowUpDown } from "lucide-react"
import { useState } from "react"
import type { SortOption, ContentType } from "@/lib/hub-data"

interface SearchFilterBarProps {
  query: string
  onQueryChange: (q: string) => void
  sort: SortOption
  onSortChange: (s: SortOption) => void
  contentFilter: ContentType | "all"
  onContentFilterChange: (f: ContentType | "all") => void
}

const SORT_OPTIONS: { value: SortOption; label: string }[] = [
  { value: "newest", label: "Newest" },
  { value: "popular", label: "Most Popular" },
  { value: "most-clicked", label: "Most Clicked" },
  { value: "trending", label: "Trending" },
]

const CONTENT_TYPES: { value: ContentType | "all"; label: string }[] = [
  { value: "all", label: "All Types" },
  { value: "video", label: "Video" },
  { value: "image", label: "Image" },
  { value: "text", label: "Text" },
  { value: "carousel", label: "Carousel" },
]

export function SearchFilterBar({
  query,
  onQueryChange,
  sort,
  onSortChange,
  contentFilter,
  onContentFilterChange,
}: SearchFilterBarProps) {
  const [showFilters, setShowFilters] = useState(false)

  return (
    <div className="flex flex-col gap-3">
      {/* Main search row */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        {/* Search input */}
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--hub-text-tertiary)]" />
          <input
            type="text"
            placeholder="Search posts, hashtags, captions..."
            value={query}
            onChange={(e) => onQueryChange(e.target.value)}
            className="h-11 w-full rounded-xl border border-[var(--hub-border)] bg-[var(--hub-surface)] pl-10 pr-10 text-sm text-[var(--hub-text)] placeholder:text-[var(--hub-text-tertiary)] outline-none transition-all duration-300 focus:border-[var(--hub-neon-cyan)] focus:shadow-[0_0_20px_rgba(0,245,255,0.1)]"
          />
          {query && (
            <button
              onClick={() => onQueryChange("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--hub-text-tertiary)] hover:text-[var(--hub-text)] transition-colors"
              aria-label="Clear search"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Sort dropdown */}
        <div className="relative">
          <ArrowUpDown className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--hub-text-tertiary)] pointer-events-none" />
          <select
            value={sort}
            onChange={(e) => onSortChange(e.target.value as SortOption)}
            className="h-11 appearance-none rounded-xl border border-[var(--hub-border)] bg-[var(--hub-surface)] pl-9 pr-8 text-sm text-[var(--hub-text)] outline-none transition-all duration-300 hover:border-[var(--hub-neon-cyan)]/50 focus:border-[var(--hub-neon-cyan)] cursor-pointer"
          >
            {SORT_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        </div>

        {/* Filter toggle */}
        <button
          onClick={() => setShowFilters(!showFilters)}
          className={`flex h-11 items-center gap-2 rounded-xl border px-4 text-sm font-medium transition-all duration-300 ${
            showFilters
              ? "border-[var(--hub-neon-cyan)] bg-[var(--hub-neon-cyan)]/10 text-[var(--hub-neon-cyan)] shadow-[0_0_15px_rgba(0,245,255,0.1)]"
              : "border-[var(--hub-border)] bg-[var(--hub-surface)] text-[var(--hub-text-secondary)] hover:border-[var(--hub-neon-cyan)]/50"
          }`}
        >
          <SlidersHorizontal className="h-4 w-4" />
          <span className="hidden sm:inline">Filters</span>
        </button>
      </div>

      {/* Expandable filter chips */}
      {showFilters && (
        <div className="flex flex-wrap gap-2 rounded-xl border border-[var(--hub-border)] bg-[var(--hub-surface)]/50 p-3 backdrop-blur-sm animate-in slide-in-from-top-2 duration-200">
          <span className="text-xs font-medium text-[var(--hub-text-tertiary)] self-center mr-1">Content:</span>
          {CONTENT_TYPES.map((ct) => (
            <button
              key={ct.value}
              onClick={() => onContentFilterChange(ct.value)}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-all duration-200 ${
                contentFilter === ct.value
                  ? "bg-[var(--hub-neon-cyan)]/15 text-[var(--hub-neon-cyan)] border border-[var(--hub-neon-cyan)]/30 shadow-[0_0_10px_rgba(0,245,255,0.08)]"
                  : "bg-[var(--hub-surface-elevated)] text-[var(--hub-text-secondary)] border border-transparent hover:border-[var(--hub-border)]"
              }`}
            >
              {ct.label}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
