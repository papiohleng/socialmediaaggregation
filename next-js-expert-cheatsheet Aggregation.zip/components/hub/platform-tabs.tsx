"use client"

import { useRef, useEffect, useState } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { PLATFORMS, getPlatformIcon, type Platform } from "@/lib/hub-data"

interface PlatformTabsProps {
  active: Platform
  onChange: (platform: Platform) => void
  postCounts: Record<Platform, number>
}

export function PlatformTabs({ active, onChange, postCounts }: PlatformTabsProps) {
  const scrollRef = useRef<HTMLDivElement>(null)
  const [canScrollLeft, setCanScrollLeft] = useState(false)
  const [canScrollRight, setCanScrollRight] = useState(false)

  function checkScroll() {
    const el = scrollRef.current
    if (!el) return
    setCanScrollLeft(el.scrollLeft > 10)
    setCanScrollRight(el.scrollLeft < el.scrollWidth - el.clientWidth - 10)
  }

  useEffect(() => {
    checkScroll()
    const el = scrollRef.current
    if (!el) return
    el.addEventListener("scroll", checkScroll)
    window.addEventListener("resize", checkScroll)
    return () => {
      el.removeEventListener("scroll", checkScroll)
      window.removeEventListener("resize", checkScroll)
    }
  }, [])

  function scroll(direction: "left" | "right") {
    const el = scrollRef.current
    if (!el) return
    el.scrollBy({ left: direction === "left" ? -200 : 200, behavior: "smooth" })
  }

  return (
    <div className="relative">
      {/* Left fade + arrow */}
      {canScrollLeft && (
        <div className="absolute left-0 top-0 bottom-0 z-10 flex items-center">
          <div className="absolute inset-y-0 left-0 w-12 bg-gradient-to-r from-[var(--hub-bg)] to-transparent" />
          <button
            onClick={() => scroll("left")}
            className="relative z-10 flex h-8 w-8 items-center justify-center rounded-full bg-[var(--hub-surface)] border border-[var(--hub-border)] text-[var(--hub-text-secondary)] hover:text-[var(--hub-text)] transition-colors"
            aria-label="Scroll platforms left"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Right fade + arrow */}
      {canScrollRight && (
        <div className="absolute right-0 top-0 bottom-0 z-10 flex items-center">
          <div className="absolute inset-y-0 right-0 w-12 bg-gradient-to-l from-[var(--hub-bg)] to-transparent" />
          <button
            onClick={() => scroll("right")}
            className="relative z-10 flex h-8 w-8 items-center justify-center rounded-full bg-[var(--hub-surface)] border border-[var(--hub-border)] text-[var(--hub-text-secondary)] hover:text-[var(--hub-text)] transition-colors"
            aria-label="Scroll platforms right"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Scrollable tab strip */}
      <div
        ref={scrollRef}
        className="flex gap-2 overflow-x-auto scrollbar-hide px-1 py-1"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        role="tablist"
        aria-label="Social media platforms"
      >
        {PLATFORMS.map((p) => {
          const isActive = active === p.id
          const count = postCounts[p.id] || 0

          return (
            <button
              key={p.id}
              role="tab"
              aria-selected={isActive}
              onClick={() => onChange(p.id)}
              className="group relative flex shrink-0 items-center gap-2 rounded-full px-4 py-2.5 text-sm font-medium transition-all duration-300 whitespace-nowrap"
              style={{
                background: isActive
                  ? `linear-gradient(135deg, ${p.color}18, ${p.color}08)`
                  : "transparent",
                borderWidth: "1px",
                borderStyle: "solid",
                borderColor: isActive ? `${p.color}40` : "var(--hub-border)",
                color: isActive ? p.color : "var(--hub-text-secondary)",
                boxShadow: isActive ? `0 0 20px ${p.hoverGlow}, inset 0 0 20px ${p.color}05` : "none",
              }}
            >
              {/* Platform icon */}
              <svg
                className="h-4 w-4 shrink-0 transition-transform duration-300 group-hover:scale-110"
                viewBox="0 0 24 24"
                fill="currentColor"
              >
                <path d={getPlatformIcon(p.id)} />
              </svg>

              <span>{p.label}</span>

              {/* Post count badge */}
              {count > 0 && (
                <span
                  className="flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-[10px] font-bold"
                  style={{
                    background: isActive ? `${p.color}25` : "var(--hub-surface-elevated)",
                    color: isActive ? p.color : "var(--hub-text-secondary)",
                  }}
                >
                  {count}
                </span>
              )}

              {/* Active neon underline */}
              {isActive && (
                <span
                  className="absolute bottom-0 left-1/4 right-1/4 h-px"
                  style={{
                    background: `linear-gradient(90deg, transparent, ${p.color}, transparent)`,
                    boxShadow: `0 0 8px ${p.color}`,
                  }}
                />
              )}
            </button>
          )
        })}
      </div>
    </div>
  )
}
