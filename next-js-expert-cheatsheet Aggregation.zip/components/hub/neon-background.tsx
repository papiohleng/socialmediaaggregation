"use client"

import { useTheme } from "./theme-provider"

export function NeonBackground() {
  const { theme } = useTheme()
  const isDark = theme === "dark"

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden" aria-hidden="true">
      {/* Base gradient */}
      <div
        className="absolute inset-0 transition-colors duration-700"
        style={{
          background: isDark
            ? "radial-gradient(ellipse 120% 80% at 50% 0%, #0d1224 0%, #06080f 50%, #000000 100%)"
            : "radial-gradient(ellipse 120% 80% at 50% 0%, #f0f4ff 0%, #e8ecf4 50%, #dde3ef 100%)",
        }}
      />

      {/* Neon orb 1 - top left cyan */}
      <div
        className="absolute -top-40 -left-40 h-[600px] w-[600px] rounded-full transition-opacity duration-700"
        style={{
          background: isDark
            ? "radial-gradient(circle, rgba(0,245,255,0.12) 0%, transparent 70%)"
            : "radial-gradient(circle, rgba(0,180,220,0.08) 0%, transparent 70%)",
          animation: "float-orb-1 20s ease-in-out infinite",
        }}
      />

      {/* Neon orb 2 - bottom right magenta */}
      <div
        className="absolute -bottom-40 -right-40 h-[700px] w-[700px] rounded-full transition-opacity duration-700"
        style={{
          background: isDark
            ? "radial-gradient(circle, rgba(255,0,128,0.10) 0%, transparent 70%)"
            : "radial-gradient(circle, rgba(200,0,100,0.06) 0%, transparent 70%)",
          animation: "float-orb-2 25s ease-in-out infinite",
        }}
      />

      {/* Neon orb 3 - center electric blue */}
      <div
        className="absolute top-1/3 left-1/2 h-[500px] w-[500px] -translate-x-1/2 rounded-full transition-opacity duration-700"
        style={{
          background: isDark
            ? "radial-gradient(circle, rgba(99,102,241,0.08) 0%, transparent 70%)"
            : "radial-gradient(circle, rgba(80,80,200,0.05) 0%, transparent 70%)",
          animation: "float-orb-3 18s ease-in-out infinite",
        }}
      />

      {/* Animated grid lines */}
      {isDark && (
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0,245,255,0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0,245,255,0.3) 1px, transparent 1px)
            `,
            backgroundSize: "80px 80px",
            animation: "grid-pulse 8s ease-in-out infinite",
          }}
        />
      )}

      {/* Floating particles */}
      {isDark && (
        <div className="absolute inset-0">
          {Array.from({ length: 30 }).map((_, i) => (
            <div
              key={i}
              className="absolute rounded-full"
              style={{
                width: `${Math.random() * 3 + 1}px`,
                height: `${Math.random() * 3 + 1}px`,
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                background:
                  i % 3 === 0
                    ? "rgba(0,245,255,0.6)"
                    : i % 3 === 1
                      ? "rgba(255,0,128,0.5)"
                      : "rgba(99,102,241,0.5)",
                animation: `particle-float-${i % 5} ${12 + Math.random() * 20}s linear infinite`,
                animationDelay: `${Math.random() * 10}s`,
              }}
            />
          ))}
        </div>
      )}

      {/* Noise texture overlay */}
      <div
        className="absolute inset-0 opacity-[0.015]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
        }}
      />
    </div>
  )
}
