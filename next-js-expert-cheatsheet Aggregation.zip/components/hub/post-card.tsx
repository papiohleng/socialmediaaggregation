"use client"

import { ExternalLink, Heart, MessageCircle, Share2, Play, ImageIcon, FileText, Layers } from "lucide-react"
import { PLATFORMS, formatNumber, getRelativeTime, getPlatformIcon, type SocialPost } from "@/lib/hub-data"
import NextImage from "next/image"

interface PostCardProps {
  post: SocialPost
  index: number
}

function BadgeLabel({ badge }: { badge: SocialPost["badge"] }) {
  if (!badge) return null

  const config: Record<string, { bg: string; text: string; glow: string; label: string }> = {
    trending: { bg: "rgba(255,59,48,0.15)", text: "#ff3b30", glow: "rgba(255,59,48,0.3)", label: "Trending" },
    popular: { bg: "rgba(255,204,0,0.15)", text: "#ffcc00", glow: "rgba(255,204,0,0.3)", label: "Popular" },
    new: { bg: "rgba(0,245,255,0.15)", text: "#00f5ff", glow: "rgba(0,245,255,0.3)", label: "New" },
    featured: { bg: "rgba(175,82,222,0.15)", text: "#af52de", glow: "rgba(175,82,222,0.3)", label: "Featured" },
  }

  const c = config[badge]
  return (
    <span
      className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider"
      style={{
        background: c.bg,
        color: c.text,
        boxShadow: `0 0 12px ${c.glow}`,
        border: `1px solid ${c.text}30`,
      }}
    >
      <span className="relative flex h-1.5 w-1.5">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full opacity-75" style={{ background: c.text }} />
        <span className="relative inline-flex h-1.5 w-1.5 rounded-full" style={{ background: c.text }} />
      </span>
      {c.label}
    </span>
  )
}

function ContentTypeIcon({ type }: { type: SocialPost["contentType"] }) {
  const cls = "h-3 w-3"
  switch (type) {
    case "video": return <Play className={cls} />
    case "image": return <ImageIcon className={cls} />
    case "carousel": return <Layers className={cls} />
    case "text": return <FileText className={cls} />
  }
}

export function PostCard({ post, index }: PostCardProps) {
  const platform = PLATFORMS.find((p) => p.id === post.platform)
  const platformColor = platform?.color || "#a0a0a0"

  // Calculate height ratios for masonry
  const heightClass =
    post.aspectRatio === "portrait"
      ? "aspect-[3/4]"
      : post.aspectRatio === "square"
        ? "aspect-square"
        : "aspect-video"

  return (
    <a
      href={post.url}
      target="_blank"
      rel="noopener noreferrer"
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-[var(--hub-border)] bg-[var(--hub-surface)] backdrop-blur-md transition-all duration-500 hover:border-transparent hover:-translate-y-1"
      style={{
        animationDelay: `${index * 60}ms`,
        animationFillMode: "backwards",
      }}
      aria-label={`${post.title} on ${platform?.label}`}
    >
      {/* Neon border glow on hover */}
      <div
        className="absolute inset-0 rounded-2xl opacity-0 transition-opacity duration-500 group-hover:opacity-100 -z-0 pointer-events-none"
        style={{
          boxShadow: `inset 0 0 1px ${platformColor}80, 0 0 30px ${platformColor}15, 0 0 60px ${platformColor}08`,
          border: `1px solid ${platformColor}50`,
          borderRadius: "1rem",
        }}
      />

      {/* Thumbnail */}
      <div className={`relative ${heightClass} w-full overflow-hidden`}>
        <NextImage
          src={post.thumbnail}
          alt={post.title}
          fill
          className="object-cover transition-transform duration-700 group-hover:scale-110"
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
        />

        {/* Dark overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

        {/* Platform icon - top left */}
        <div
          className="absolute top-3 left-3 flex h-8 w-8 items-center justify-center rounded-full backdrop-blur-md transition-transform duration-300 group-hover:scale-110"
          style={{
            background: `${platformColor}20`,
            border: `1px solid ${platformColor}40`,
            boxShadow: `0 0 12px ${platformColor}20`,
          }}
        >
          <svg className="h-4 w-4" viewBox="0 0 24 24" fill={platformColor}>
            <path d={getPlatformIcon(post.platform)} />
          </svg>
        </div>

        {/* Badge - top right */}
        {post.badge && (
          <div className="absolute top-3 right-3">
            <BadgeLabel badge={post.badge} />
          </div>
        )}

        {/* Content type chip - bottom left */}
        <div className="absolute bottom-3 left-3 flex items-center gap-1.5 rounded-full bg-black/50 px-2.5 py-1 text-[10px] font-medium text-white/80 backdrop-blur-sm">
          <ContentTypeIcon type={post.contentType} />
          <span className="uppercase tracking-wider">{post.contentType}</span>
        </div>

        {/* External link icon - bottom right */}
        <div className="absolute bottom-3 right-3 flex h-7 w-7 items-center justify-center rounded-full bg-black/50 text-white/60 backdrop-blur-sm opacity-0 transition-all duration-300 group-hover:opacity-100 group-hover:text-white">
          <ExternalLink className="h-3.5 w-3.5" />
        </div>
      </div>

      {/* Content body */}
      <div className="relative flex flex-1 flex-col gap-2.5 p-4">
        {/* Title */}
        <h3 className="text-sm font-semibold leading-snug text-[var(--hub-text)] line-clamp-2 group-hover:text-[var(--hub-neon-cyan)] transition-colors duration-300">
          {post.title}
        </h3>

        {/* Caption */}
        <p className="text-xs leading-relaxed text-[var(--hub-text-secondary)] line-clamp-2">
          {post.caption}
        </p>

        {/* Hashtags */}
        <div className="flex flex-wrap gap-1.5">
          {post.hashtags.slice(0, 3).map((tag) => (
            <span
              key={tag}
              className="rounded-md bg-[var(--hub-surface-elevated)] px-2 py-0.5 text-[10px] font-medium text-[var(--hub-text-tertiary)] transition-colors duration-200 group-hover:text-[var(--hub-neon-cyan)]/70"
            >
              #{tag}
            </span>
          ))}
        </div>

        {/* Stats bar */}
        <div className="mt-auto flex items-center justify-between border-t border-[var(--hub-border)] pt-2.5">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-[10px] text-[var(--hub-text-tertiary)]">
              <Heart className="h-3 w-3" />
              {formatNumber(post.likes)}
            </span>
            <span className="flex items-center gap-1 text-[10px] text-[var(--hub-text-tertiary)]">
              <MessageCircle className="h-3 w-3" />
              {formatNumber(post.comments)}
            </span>
            <span className="flex items-center gap-1 text-[10px] text-[var(--hub-text-tertiary)]">
              <Share2 className="h-3 w-3" />
              {formatNumber(post.shares)}
            </span>
          </div>
          <span className="text-[10px] text-[var(--hub-text-tertiary)]">
            {getRelativeTime(post.date)}
          </span>
        </div>
      </div>

      {/* Hover sparkle micro-reward */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-700">
        <div
          className="h-32 w-32 rounded-full"
          style={{
            background: `radial-gradient(circle, ${platformColor}08 0%, transparent 70%)`,
          }}
        />
      </div>
    </a>
  )
}
