import { CodeBlock, InlineCode } from "../code-block"
import { SectionHeader, SubSection, Callout, KeyValueGrid } from "../section-header"

export function DeploymentSection() {
  return (
    <section>
      <SectionHeader
        id="deployment"
        title="Deployment"
        description="From Vercel to self-hosting, environment variables, and production hardening. Ship with confidence."
        badge="CHAPTER 09"
      />

      <SubSection id="vercel-deploy" title="Vercel Deployment">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Vercel is the native platform for Next.js. Zero-config deployments, edge functions,
          analytics, and preview deployments for every pull request.
        </p>
        <KeyValueGrid
          items={[
            { key: "git push", value: "Automatic deployment on every push. Preview URLs for branches, production for main." },
            { key: "Edge Functions", value: "Middleware and edge-optimized routes run at 30+ global locations." },
            { key: "Serverless Functions", value: "API routes and SSR pages run as serverless functions with auto-scaling." },
            { key: "ISR", value: "Incremental Static Regeneration. Pages rebuild in the background while serving stale." },
            { key: "Image Optimization", value: "Automatic WebP/AVIF conversion and resizing via Vercel's global CDN." },
            { key: "Analytics", value: "Real User Monitoring (RUM) for Core Web Vitals and performance metrics." },
          ]}
        />
        <CodeBlock
          filename="next.config.mjs (Production)"
          language="tsx"
          code={`/** @type {import('next').NextConfig} */
const nextConfig = {
  // React Compiler (stable in Next.js 16)
  reactCompiler: true,

  // Image optimization
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: 'cdn.yourapp.com' },
    ],
    formats: ['image/avif', 'image/webp'],
  },

  // Strict mode for development
  reactStrictMode: true,

  // Redirects
  async redirects() {
    return [
      { source: '/old-blog/:slug', destination: '/blog/:slug', permanent: true },
    ]
  },

  // Rewrites (proxy pattern)
  async rewrites() {
    return [
      { source: '/api/v1/:path*', destination: 'https://api.yourapp.com/:path*' },
    ]
  },

  // Turbopack (default in Next.js 16)
  // No configuration needed — it's the default bundler

  // Output configuration for self-hosting
  // output: 'standalone', // Creates minimal production build
}

export default nextConfig`}
          highlights={[3, 4, 11, 20, 27, 32]}
        />
      </SubSection>

      <SubSection id="self-hosting" title="Self-Hosting">
        <CodeBlock
          filename="Dockerfile (Production)"
          language="dockerfile"
          code={`FROM node:20-alpine AS base

# Install dependencies
FROM base AS deps
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci --only=production

# Build the application
FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm run build

# Production image
FROM base AS runner
WORKDIR /app
ENV NODE_ENV=production

# Create non-root user
RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

# Copy standalone output
COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs
EXPOSE 3000
ENV PORT=3000
ENV HOSTNAME="0.0.0.0"

CMD ["node", "server.js"]`}
          highlights={[1, 17, 21, 22, 26, 27, 34]}
        />
        <Callout type="info">
          Set <InlineCode>{"output: 'standalone'"}</InlineCode> in <InlineCode>next.config.mjs</InlineCode> for self-hosting.
          This creates a minimal production build that includes only the necessary files.
          The standalone output reduces your Docker image size dramatically.
        </Callout>
      </SubSection>

      <SubSection id="env-variables" title="Environment Variables">
        <CodeBlock
          filename="Environment Variables"
          language="tsx"
          code={`// === Server-only variables (default) ===
// .env.local
DATABASE_URL="postgresql://..."
STRIPE_SECRET_KEY="sk_live_..."
JWT_SECRET="your-secret-key"

// Access ONLY in Server Components, Route Handlers, middleware:
const db = new PrismaClient({
  datasources: { db: { url: process.env.DATABASE_URL } },
})

// === Client-safe variables (NEXT_PUBLIC_ prefix) ===
// .env.local
NEXT_PUBLIC_APP_URL="https://myapp.com"
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY="pk_live_..."
NEXT_PUBLIC_GA_ID="G-XXXXXXXXXX"

// Accessible in Client Components:
const publishableKey = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY

// === Environment file priority (highest to lowest) ===
// .env.$(NODE_ENV).local   → .env.local → .env.$(NODE_ENV) → .env

// === Runtime validation (recommended) ===
// lib/env.ts
import { z } from 'zod'

const envSchema = z.object({
  DATABASE_URL: z.string().url(),
  JWT_SECRET: z.string().min(32),
  STRIPE_SECRET_KEY: z.string().startsWith('sk_'),
  NEXT_PUBLIC_APP_URL: z.string().url(),
})

// Validate at build time — fails fast if misconfigured
export const env = envSchema.parse(process.env)`}
          highlights={[1, 2, 12, 13, 21, 26, 27, 36]}
        />
        <Callout type="danger">
          Never put secrets in <InlineCode>NEXT_PUBLIC_</InlineCode> variables. They are embedded in the
          client-side JavaScript bundle and visible to anyone. Database URLs, API secret keys,
          and JWT secrets must NEVER have the <InlineCode>NEXT_PUBLIC_</InlineCode> prefix.
        </Callout>
      </SubSection>
    </section>
  )
}
