import { CodeBlock, InlineCode } from "../code-block"
import { SectionHeader, SubSection, Callout, KeyValueGrid } from "../section-header"

export function OptimizationSection() {
  return (
    <section>
      <SectionHeader
        id="optimization"
        title="Optimization"
        description="Images, fonts, scripts, metadata, and bundle analysis. These are the marginal gains that separate a good app from a great one. Every millisecond matters."
        badge="CHAPTER 06"
      />

      <SubSection id="image-optimization" title="Image Optimization">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          The <InlineCode>{"<Image>"}</InlineCode> component automatically optimizes images: lazy loading, responsive sizing,
          modern formats (WebP/AVIF), and prevents Cumulative Layout Shift.
        </p>
        <CodeBlock
          filename="Image Component Deep Dive"
          language="tsx"
          code={`import Image from 'next/image'

// === Local images (automatically sized) ===
import heroImage from '@/public/hero.jpg'

export function Hero() {
  return (
    <Image
      src={heroImage || "/placeholder.svg"}         // Import = automatic width/height
      alt="Hero banner"
      priority                // Preload (for above-the-fold images)
      placeholder="blur"      // Built-in blur-up placeholder
      quality={85}            // JPEG/WebP quality (default: 75)
      sizes="100vw"           // Responsive sizing hint
    />
  )
}

// === Remote images (must specify dimensions) ===
export function Avatar({ user }: { user: User }) {
  return (
    <Image
      src={user.avatarUrl || "/placeholder.svg"}
      alt={\`\${user.name}'s avatar\`}
      width={48}
      height={48}
      className="rounded-full"
    />
  )
}

// === Fill mode (like CSS object-fit) ===
export function BackgroundImage() {
  return (
    <div className="relative h-96 w-full">
      <Image
        src="/background.jpg"
        alt=""                   // Decorative = empty alt
        fill                     // Fills parent container
        className="object-cover" // CSS object-fit
        sizes="100vw"
        priority
      />
    </div>
  )
}

// next.config.mjs — Allow remote image domains
// images: {
//   remotePatterns: [
//     { protocol: 'https', hostname: 'cdn.example.com' },
//     { protocol: 'https', hostname: '**.amazonaws.com' },
//   ],
// }`}
          highlights={[10, 11, 12, 13, 14, 38, 39, 40]}
        />
        <Callout type="tip">
          Always set <InlineCode>priority</InlineCode> on your LCP (Largest Contentful Paint) image.
          Always provide <InlineCode>sizes</InlineCode> when using responsive images.
          Use <InlineCode>fill</InlineCode> for background-style images where you do not know dimensions ahead of time.
        </Callout>
      </SubSection>

      <SubSection id="font-optimization" title="Font Optimization">
        <CodeBlock
          filename="app/layout.tsx"
          language="tsx"
          code={`import { Inter, JetBrains_Mono } from 'next/font/google'

// Google Fonts — zero layout shift, self-hosted
const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',        // CSS variable
  display: 'swap',                  // Font display strategy
})

const mono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  weight: ['400', '700'],          // Only load needed weights
})

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={\`\${inter.variable} \${mono.variable}\`}>
      <body className="font-sans">  {/* Uses --font-inter via Tailwind */}
        {children}
      </body>
    </html>
  )
}

// tailwind.config.ts
// theme: {
//   extend: {
//     fontFamily: {
//       sans: ['var(--font-inter)'],
//       mono: ['var(--font-mono)'],
//     },
//   },
// }

// === Local fonts ===
import localFont from 'next/font/local'

const customFont = localFont({
  src: [
    { path: './fonts/Custom-Regular.woff2', weight: '400', style: 'normal' },
    { path: './fonts/Custom-Bold.woff2', weight: '700', style: 'normal' },
    { path: './fonts/Custom-Italic.woff2', weight: '400', style: 'italic' },
  ],
  variable: '--font-custom',
  display: 'swap',
})`}
          highlights={[3, 4, 5, 6, 7, 13, 18, 19, 38, 39, 40, 41, 42, 43]}
        />
        <Callout type="info">
          Next.js automatically self-hosts Google Fonts. No external network requests at runtime.
          Fonts are downloaded at build time and served from your own domain. This eliminates
          the performance penalty and privacy concerns of Google Fonts CDN.
        </Callout>
      </SubSection>

      <SubSection id="script-optimization" title="Script & Metadata">
        <CodeBlock
          filename="Metadata API"
          language="tsx"
          code={`// === Static metadata ===
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'My App',
  description: 'The best app ever built',
  metadataBase: new URL('https://myapp.com'),
  openGraph: {
    title: 'My App',
    description: 'The best app ever built',
    url: 'https://myapp.com',
    siteName: 'My App',
    images: [{ url: '/og.png', width: 1200, height: 630 }],
    locale: 'en_US',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    creator: '@myapp',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
}

// === Script component ===
import Script from 'next/script'

<Script
  src="https://analytics.example.com/script.js"
  strategy="afterInteractive"  // Load after page is interactive
/>

<Script
  src="https://heavy-lib.example.com/lib.js"
  strategy="lazyOnload"        // Load during idle time
/>

<Script
  id="structured-data"
  type="application/ld+json"
  strategy="afterInteractive"
  dangerouslySetInnerHTML={{
    __html: JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'Article',
      headline: 'Sample Title',
      author: { '@type': 'Person', name: 'Sample Author' },
    }),
  }}
/>`}
          highlights={[5, 6, 7, 10, 37, 56, 57, 61, 62]}
        />
      </SubSection>

      <SubSection id="bundle-analysis" title="Bundle Analysis">
        <KeyValueGrid
          items={[
            { key: "dynamic()", value: "Lazy-load components. Reduces initial bundle. Use for heavy components below the fold." },
            { key: "next/dynamic", value: "Next.js wrapper around React.lazy with SSR control and loading states." },
            { key: "@next/bundle-analyzer", value: "Visualize bundle composition. Find large dependencies to optimize." },
            { key: "Tree Shaking", value: "Automatic. Named imports from barrel files are tree-shaken in Next.js." },
            { key: "Route Segments", value: "Each page only loads its own dependencies. Shared code is automatically split." },
          ]}
        />
        <CodeBlock
          filename="Dynamic Imports"
          language="tsx"
          code={`import dynamic from 'next/dynamic'

// Lazy-load a heavy component (e.g., rich text editor)
const RichEditor = dynamic(() => import('@/components/rich-editor'), {
  loading: () => <div className="h-64 animate-pulse bg-muted rounded" />,
  ssr: false, // Don't render on server (browser-only component)
})

// Lazy-load with named export
const Chart = dynamic(
  () => import('@/components/charts').then(mod => mod.BarChart),
  { ssr: false }
)

// Conditional loading
export function AdminPanel({ isAdmin }: { isAdmin: boolean }) {
  if (!isAdmin) return null

  // Only loads the admin component when isAdmin is true
  const AdminDashboard = dynamic(() => import('@/components/admin-dashboard'))
  return <AdminDashboard />
}`}
          highlights={[4, 5, 6, 10, 11]}
        />
      </SubSection>
    </section>
  )
}
