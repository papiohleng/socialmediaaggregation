'use client';

import { CodeBlock, InlineCode } from "../code-block"
import { SectionHeader, SubSection, Callout, KeyValueGrid } from "../section-header"

export function AdvancedSection() {
  return (
    <section>
      <SectionHeader
        id="advanced"
        title="Advanced Patterns"
        description="Architecture patterns, testing strategies, internationalization, and the performance playbook. This is the chapter that separates senior engineers from everyone else."
        badge="CHAPTER 10"
      />

      <SubSection id="architecture" title="Architecture Patterns">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Large-scale Next.js applications require disciplined architecture. These patterns
          have been battle-tested in production at companies handling millions of requests.
        </p>
        <CodeBlock
          filename="Feature-Based Architecture"
          language="text"
          code={`app/
├── (marketing)/
│   ├── layout.tsx
│   └── page.tsx
├── (dashboard)/
│   ├── layout.tsx
│   ├── overview/page.tsx
│   └── settings/page.tsx
├── api/
│   ├── auth/[...nextauth]/route.ts
│   └── webhook/stripe/route.ts
└── layout.tsx

features/                  # Feature modules (domain-driven)
├── auth/
│   ├── components/        # Feature-specific components
│   │   ├── login-form.tsx
│   │   └── register-form.tsx
│   ├── actions/           # Server Actions
│   │   ├── login.ts
│   │   └── register.ts
│   ├── lib/               # Feature utilities
│   │   ├── session.ts
│   │   └── validation.ts
│   └── types.ts
│
├── billing/
│   ├── components/
│   │   ├── pricing-table.tsx
│   │   └── subscription-card.tsx
│   ├── actions/
│   │   ├── create-checkout.ts
│   │   └── manage-subscription.ts
│   └── lib/
│       └── stripe.ts
│
└── blog/
    ├── components/
    │   ├── post-card.tsx
    │   └── post-editor.tsx
    ├── actions/
    │   └── create-post.ts
    └── lib/
        └── markdown.ts

components/                # Shared UI components (design system)
├── ui/                    # Primitive components (button, input, etc.)
├── layout/                # Layout components (header, footer, sidebar)
└── shared/                # Composed components (search bar, user menu)

lib/                       # Shared utilities
├── db.ts                  # Database client
├── utils.ts               # General utilities
└── constants.ts           # App-wide constants`}
          highlights={[14, 42, 47]}
        />
        <Callout type="tip">
          The key principle: <InlineCode>app/</InlineCode> directory only contains routing and page assembly.
          Business logic lives in <InlineCode>features/</InlineCode>. Shared UI lives in <InlineCode>components/</InlineCode>.
          Pages are thin orchestration layers that import from features.
        </Callout>

        <CodeBlock
          filename="Data Access Layer Pattern"
          language="tsx"
          code={`// lib/dal.ts (Data Access Layer)
// Centralizes ALL database access. No direct db calls in components.
import { cache } from 'react'
import { db } from './db'

export const getUser = cache(async (id: string) => {
  return db.user.findUnique({
    where: { id },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      // Never select password hash or sensitive fields
    },
  })
})

export const getPosts = cache(async (options?: {
  page?: number
  limit?: number
  authorId?: string
}) => {
  const { page = 1, limit = 20, authorId } = options ?? {}

  const [posts, total] = await Promise.all([
    db.post.findMany({
      where: authorId ? { authorId } : undefined,
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: { author: { select: { name: true, avatar: true } } },
    }),
    db.post.count({ where: authorId ? { authorId } : undefined }),
  ])

  return {
    posts,
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
    },
  }
})

// Benefits:
// 1. Single source of truth for data shapes
// 2. Automatic request deduplication via cache()
// 3. Never expose sensitive fields
// 4. Easy to add logging, metrics, rate limiting
// 5. Type-safe across your entire app`}
          highlights={[1, 2, 6, 14, 26, 46, 47, 48, 49, 50]}
        />
      </SubSection>

      <SubSection id="testing" title="Testing Strategies">
        <CodeBlock
          filename="Testing Next.js Applications"
          language="tsx"
          code={`// === Unit Tests (Vitest + React Testing Library) ===
import { render, screen, fireEvent } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'
import { AddToCartButton } from '@/components/add-to-cart'

describe('AddToCartButton', () => {
  it('renders with correct text', () => {
    render(<AddToCartButton productId="123" />)
    expect(screen.getByText('Add to Cart')).toBeInTheDocument()
  })

  it('disables during submission', async () => {
    const mockAction = vi.fn(() => new Promise(r => setTimeout(r, 100)))
    render(<AddToCartButton productId="123" />)

    fireEvent.click(screen.getByRole('button'))
    expect(screen.getByText('Adding...')).toBeInTheDocument()
  })
})

// === Server Component Tests ===
import { render } from '@testing-library/react'
import ProductsPage from '@/app/products/page'

// Mock the database
vi.mock('@/lib/db', () => ({
  db: {
    product: {
      findMany: vi.fn().mockResolvedValue([
        { id: '1', name: 'Product 1', price: 99 },
        { id: '2', name: 'Product 2', price: 149 },
      ]),
    },
  },
}))

it('renders products from database', async () => {
  // Server Components are async — await them
  const jsx = await ProductsPage()
  render(jsx)

  expect(screen.getByText('Product 1')).toBeInTheDocument()
  expect(screen.getByText('Product 2')).toBeInTheDocument()
})

// === Integration Tests (Playwright) ===
import { test, expect } from '@playwright/test'

test('user can complete checkout', async ({ page }) => {
  await page.goto('/products')

  // Add item to cart
  await page.click('[data-testid="add-to-cart-1"]')
  await expect(page.locator('[data-testid="cart-count"]')).toHaveText('1')

  // Go to checkout
  await page.click('[data-testid="checkout-button"]')
  await expect(page).toHaveURL('/checkout')

  // Fill in details
  await page.fill('#email', 'test@example.com')
  await page.fill('#card', '4242424242424242')
  await page.click('#submit')

  // Verify success
  await expect(page.locator('h1')).toHaveText('Order Confirmed')
})`}
          highlights={[1, 21, 37, 38, 47]}
        />
      </SubSection>

      <SubSection id="internationalization" title="Internationalization">
        <CodeBlock
          filename="i18n with App Router"
          language="tsx"
          code={`// middleware.ts — Detect and redirect to locale
import { NextRequest, NextResponse } from 'next/server'
import { match } from '@formatjs/intl-localematcher'
import Negotiator from 'negotiator'

const locales = ['en', 'de', 'fr', 'ja']
const defaultLocale = 'en'

function getLocale(request: NextRequest): string {
  const headers = { 'accept-language': request.headers.get('accept-language') ?? '' }
  const languages = new Negotiator({ headers }).languages()
  return match(languages, locales, defaultLocale)
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl
  const hasLocale = locales.some(
    locale => pathname.startsWith(\`/\${locale}/\`) || pathname === \`/\${locale}\`
  )

  if (hasLocale) return
  const locale = getLocale(request)
  return NextResponse.redirect(new URL(\`/\${locale}\${pathname}\`, request.url))
}

// app/[locale]/layout.tsx
export default async function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode
  params: Promise<{ locale: string }>
}) {
  const { locale } = await params
  const messages = await import(\`@/messages/\${locale}.json\`)

  return (
    <html lang={locale} dir={locale === 'ar' ? 'rtl' : 'ltr'}>
      <body>
        <IntlProvider locale={locale} messages={messages}>
          {children}
        </IntlProvider>
      </body>
    </html>
  )
}

// messages/en.json
// {
//   "greeting": "Hello, {name}!",
//   "nav": { "home": "Home", "about": "About" }
// }

// messages/de.json
// {
//   "greeting": "Hallo, {name}!",
//   "nav": { "home": "Startseite", "about": "Über uns" }
// }`}
          highlights={[6, 7, 26, 34, 38]}
        />
      </SubSection>

      <SubSection id="performance" title="Performance Playbook">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          The definitive checklist for building production-grade, high-performance Next.js applications.
          Every item here has been measured to impact Core Web Vitals.
        </p>
        <KeyValueGrid
          items={[
            { key: "LCP < 2.5s", value: "Use priority on hero images. Preload critical fonts. Stream SSR with Suspense boundaries." },
            { key: "FID < 100ms", value: "Minimize client-side JavaScript. Use Server Components. Lazy-load heavy components." },
            { key: "CLS < 0.1", value: "Set explicit width/height on images. Use font-display: swap. Reserve skeleton space." },
            { key: "TTFB < 800ms", value: "Use edge middleware. Cache aggressively. Place databases close to compute." },
            { key: "INP < 200ms", value: "Use useTransition for non-urgent updates. Debounce inputs. Virtualize long lists." },
          ]}
        />
        <CodeBlock
          filename="Performance Checklist"
          language="tsx"
          code={`// === 1. Prefetch critical routes ===
<Link href="/dashboard" prefetch={true}>Dashboard</Link>

// === 2. Parallel data fetching (never sequential) ===
const [user, posts, stats] = await Promise.all([
  getUser(id),
  getPosts({ authorId: id }),
  getStats(id),
])

// === 3. Streaming with granular Suspense ===
<Suspense fallback={<HeaderSkeleton />}>
  <DashboardHeader />
</Suspense>
<Suspense fallback={<ChartSkeleton />}>
  <AnalyticsChart />        {/* Streams in when ready */}
</Suspense>

// === 4. React cache() for deduplication ===
import { cache } from 'react'
export const getUser = cache(async (id: string) => {
  return db.user.findUnique({ where: { id } })
})

// === 5. useTransition for non-blocking updates ===
const [isPending, startTransition] = useTransition()
function handleSearch(query: string) {
  startTransition(() => {
    setSearchResults(filterResults(query))
  })
}

// === 6. Virtualize long lists ===
import { useVirtualizer } from '@tanstack/react-virtual'
// Only renders visible items, not 10,000 DOM nodes

// === 7. Optimize re-renders ===
// Move state down — keep state in the smallest component possible
// Lift content up — pass server-rendered JSX as children

// === 8. Route segment config ===
export const dynamic = 'force-static'     // Force static generation
export const revalidate = 3600            // Revalidate every hour
export const runtime = 'edge'             // Run on the edge
export const preferredRegion = 'iad1'     // Pin to a region
export const maxDuration = 30             // Max execution time (seconds)`}
          highlights={[1, 4, 5, 6, 12, 20, 26, 34, 40, 41, 42, 43, 44]}
        />
        <Callout type="tip">
          The single highest-impact performance optimization in Next.js is keeping components
          as Server Components by default. Every component you convert from Client to Server
          removes JavaScript from your bundle. Target less than 50KB of first-load client JS.
        </Callout>
      </SubSection>
    </section>
  )
}
