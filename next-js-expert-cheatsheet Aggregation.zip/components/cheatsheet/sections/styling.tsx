import { CodeBlock, InlineCode } from "../code-block"
import { SectionHeader, SubSection, Callout, KeyValueGrid } from "../section-header"

export function StylingSection() {
  return (
    <section>
      <SectionHeader
        id="styling"
        title="Styling"
        description="CSS Modules, Tailwind CSS, CSS-in-JS, and the strategies that let you ship beautiful, maintainable styles at scale."
        badge="CHAPTER 08"
      />

      <SubSection id="css-modules" title="CSS & Modules">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          CSS Modules scope styles to components automatically. No class name collisions.
          They work in both Server and Client Components with zero configuration.
        </p>
        <CodeBlock
          filename="components/button.module.css"
          language="css"
          code={`.button {
  padding: 0.75rem 1.5rem;
  border-radius: 0.5rem;
  font-weight: 600;
  transition: all 150ms ease;
}

.button:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

/* Composition — reuse styles */
.primary {
  composes: button;
  background: var(--color-primary);
  color: white;
}

.secondary {
  composes: button;
  background: transparent;
  border: 1px solid var(--color-border);
}

/* Global within module */
:global(.dark) .button {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
}`}
        />
        <CodeBlock
          filename="components/button.tsx"
          language="tsx"
          code={`import styles from './button.module.css'

export function Button({ variant = 'primary', ...props }) {
  return (
    <button className={styles[variant]} {...props} />
    // Renders: <button class="button_primary__x7f2k">
    // Unique hash = no collisions
  )
}`}
        />
      </SubSection>

      <SubSection id="tailwind-css" title="Tailwind CSS">
        <CodeBlock
          filename="Tailwind Best Practices in Next.js"
          language="tsx"
          code={`// === Responsive design ===
<div className="
  grid
  grid-cols-1        // Mobile: single column
  md:grid-cols-2     // Tablet: two columns
  lg:grid-cols-3     // Desktop: three columns
  gap-6
">
  {items.map(item => <Card key={item.id} item={item} />)}
</div>

// === Conditional classes with cn() utility ===
import { cn } from '@/lib/utils'

function StatusBadge({ status }: { status: 'active' | 'inactive' | 'pending' }) {
  return (
    <span className={cn(
      "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
      {
        'bg-green-100 text-green-800': status === 'active',
        'bg-red-100 text-red-800': status === 'inactive',
        'bg-yellow-100 text-yellow-800': status === 'pending',
      }
    )}>
      {status}
    </span>
  )
}

// === Design tokens via CSS variables ===
// globals.css defines: --background, --foreground, --primary, etc.
// tailwind.config.ts maps: bg-background, text-foreground, bg-primary

// Use semantic tokens, not raw colors:
<div className="bg-background text-foreground">        {/* ✅ Themed */}
<div className="bg-white text-black">                  {/* ❌ Hardcoded */}

// === Dark mode with CSS variables ===
// When using CSS variable-based design tokens,
// dark mode is handled by changing variable values,
// not by adding dark: prefixes everywhere.
// This is the shadcn/ui approach.`}
          highlights={[4, 5, 6, 14, 17, 18, 33, 34, 35, 36]}
        />
      </SubSection>

      <SubSection id="css-in-js" title="CSS-in-JS & Strategies">
        <KeyValueGrid
          items={[
            { key: "Tailwind CSS", value: "Recommended. Zero-runtime. Works perfectly with Server Components. Best DX with IntelliSense." },
            { key: "CSS Modules", value: "Built-in. Zero config. Scoped styles. Works in Server & Client Components." },
            { key: "Global CSS", value: "Import in layout.tsx. Use for resets, base styles, and CSS variables." },
            { key: "Sass/SCSS", value: "Supported. Install sass package. Use CSS Modules with .module.scss extension." },
            { key: "CSS-in-JS", value: "Runtime libraries (styled-components, emotion) only work in Client Components. Avoid if possible." },
          ]}
        />
        <Callout type="tip">
          For Next.js apps, the best styling strategy is Tailwind CSS + CSS variables for theming + <InlineCode>cn()</InlineCode> utility
          for conditional classes. This gives you zero-runtime styles, excellent DX, and full Server Component compatibility.
          Avoid runtime CSS-in-JS (styled-components, emotion) as they require Client Components and add JavaScript overhead.
        </Callout>
      </SubSection>
    </section>
  )
}
