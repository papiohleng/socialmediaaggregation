import { CodeBlock, InlineCode } from "../code-block"
import { SectionHeader, SubSection, Callout, KeyValueGrid } from "../section-header"

export function FundamentalsSection() {
  return (
    <section>
      <SectionHeader
        id="fundamentals"
        title="Fundamentals"
        description="The mental model and file system architecture that powers every Next.js application. Internalize this and everything else clicks."
        badge="CHAPTER 01"
      />

      <SubSection id="project-structure" title="Project Structure">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Next.js uses a file-system based router. Every file you create in the <InlineCode>app/</InlineCode> directory
          becomes a route. This is the architectural decision that makes Next.js fundamentally different from traditional
          React SPAs. The directory structure IS your route tree.
        </p>
        <CodeBlock
          filename="Project Architecture"
          language="text"
          code={`my-app/
├── app/                    # App Router (recommended)
│   ├── layout.tsx          # Root layout (wraps ALL pages)
│   ├── page.tsx            # Home route (/)
│   ├── loading.tsx         # Loading UI (auto Suspense boundary)
│   ├── error.tsx           # Error boundary (catches render errors)
│   ├── not-found.tsx       # 404 page
│   ├── global-error.tsx    # Root-level error boundary
│   ├── template.tsx        # Re-renders on navigation (unlike layout)
│   ├── default.tsx         # Fallback for parallel routes
│   ├── route.ts            # API endpoint (GET, POST, etc.)
│   │
│   ├── dashboard/          # /dashboard route segment
│   │   ├── layout.tsx      # Dashboard-scoped layout
│   │   ├── page.tsx        # /dashboard page
│   │   └── settings/       # /dashboard/settings
│   │       └── page.tsx
│   │
│   ├── blog/
│   │   ├── page.tsx        # /blog (listing page)
│   │   └── [slug]/         # /blog/:slug (dynamic segment)
│   │       └── page.tsx
│   │
│   └── api/                # API routes
│       └── webhook/
│           └── route.ts    # /api/webhook
│
├── components/             # Shared React components
│   ├── ui/                 # Primitive UI components
│   └── features/           # Feature-specific components
│
├── lib/                    # Utility functions & shared logic
├── hooks/                  # Custom React hooks
├── public/                 # Static assets (served at /)
├── middleware.ts            # Edge middleware (runs before requests)
├── next.config.mjs         # Next.js configuration
├── tailwind.config.ts      # Tailwind CSS configuration
└── tsconfig.json           # TypeScript configuration`}
        />
        <Callout type="tip">
          The <InlineCode>app/</InlineCode> directory uses React Server Components by default.
          Every component is a Server Component unless you explicitly mark it with <InlineCode>{"'use client'"}</InlineCode>.
          This is the single most important mental model shift in modern Next.js.
        </Callout>
      </SubSection>

      <SubSection id="file-conventions" title="File Conventions">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Next.js has strict file naming conventions. Each file has a specific purpose and is
          processed differently by the framework. Understanding these is non-negotiable.
        </p>
        <KeyValueGrid
          items={[
            { key: "page.tsx", value: "Makes a route publicly accessible. Without it, the directory is just a layout wrapper." },
            { key: "layout.tsx", value: "Wraps child routes. Preserved across navigations (state persists). Can be nested." },
            { key: "template.tsx", value: "Like layout, but re-mounts on every navigation. Use for enter/exit animations." },
            { key: "loading.tsx", value: "Creates an instant loading state via React Suspense. Shows while page.tsx streams." },
            { key: "error.tsx", value: "React Error Boundary. Must be 'use client'. Catches errors in child tree." },
            { key: "not-found.tsx", value: "Rendered when notFound() is called or route doesn't match." },
            { key: "global-error.tsx", value: "Root error boundary. Catches errors in root layout. Must render <html> and <body>." },
            { key: "route.ts", value: "API endpoint. Exports HTTP method handlers (GET, POST, PUT, PATCH, DELETE)." },
            { key: "default.tsx", value: "Fallback for parallel route slots when no matching URL segment exists." },
            { key: "middleware.ts", value: "Runs on the Edge before every matched request. Must be at project root." },
            { key: "opengraph-image.tsx", value: "Dynamically generates OG images at build time or on-demand." },
            { key: "sitemap.ts", value: "Generates sitemap.xml programmatically." },
            { key: "robots.ts", value: "Generates robots.txt programmatically." },
          ]}
        />
      </SubSection>

      <SubSection id="component-hierarchy" title="Component Hierarchy">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          When Next.js renders a route, it assembles the component tree in a precise order.
          Understanding this hierarchy is critical for knowing where to place your logic.
        </p>
        <CodeBlock
          filename="Rendering Order"
          language="tsx"
          code={`// The actual nesting order Next.js creates:

<Layout>               {/* layout.tsx - persistent shell */}
  <Template>           {/* template.tsx - re-mounts on nav */}
    <ErrorBoundary      {/* error.tsx - catches errors */}
      fallback={<Error />}
    >
      <Suspense          {/* loading.tsx - streaming fallback */}
        fallback={<Loading />}
      >
        <Page />         {/* page.tsx - your actual content */}
      </Suspense>
    </ErrorBoundary>
  </Template>
</Layout>

// Key insight: Layouts at the same level DO NOT re-render
// when navigating between sibling routes. This is why
// layout state persists — it's never unmounted.`}
          highlights={[3, 4, 5, 8, 11, 15]}
        />
        <Callout type="info">
          Layouts are NOT re-rendered on navigation. They receive new children but the
          layout component itself stays mounted. This means <InlineCode>useState</InlineCode> inside a layout
          persists across child route changes. Use <InlineCode>template.tsx</InlineCode> when you need re-mounting behavior.
        </Callout>
      </SubSection>
    </section>
  )
}
