import { CodeBlock, InlineCode } from "../code-block"
import { SectionHeader, SubSection, Callout, KeyValueGrid } from "../section-header"

export function ApiLayerSection() {
  return (
    <section>
      <SectionHeader
        id="api"
        title="API Layer"
        description="Route Handlers for building APIs, Middleware for request interception, and advanced patterns for webhooks, streaming, and edge computing."
        badge="CHAPTER 05"
      />

      <SubSection id="route-handlers" title="Route Handlers">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Route Handlers are the API endpoints of your Next.js app. They export functions named after
          HTTP methods and run on the server. They replace the old <InlineCode>pages/api</InlineCode> pattern.
        </p>
        <CodeBlock
          filename="app/api/users/route.ts"
          language="tsx"
          code={`import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'

// GET /api/users
export async function GET(request: NextRequest) {
  const { searchParams } = request.nextUrl
  const page = Number(searchParams.get('page')) || 1
  const limit = Number(searchParams.get('limit')) || 20

  const users = await db.user.findMany({
    skip: (page - 1) * limit,
    take: limit,
  })

  return NextResponse.json({
    data: users,
    pagination: { page, limit, total: await db.user.count() },
  })
}

// POST /api/users
const CreateUserSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
})

export async function POST(request: NextRequest) {
  const body = await request.json()
  const validated = CreateUserSchema.safeParse(body)

  if (!validated.success) {
    return NextResponse.json(
      { error: validated.error.flatten() },
      { status: 400 }
    )
  }

  const user = await db.user.create({ data: validated.data })
  return NextResponse.json(user, { status: 201 })
}

// Dynamic route: app/api/users/[id]/route.ts
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params  // Must await in Next.js 15+
  const body = await request.json()
  const user = await db.user.update({ where: { id }, data: body })
  return NextResponse.json(user)
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  await db.user.delete({ where: { id } })
  return new NextResponse(null, { status: 204 })
}

// === Advanced: Streaming response ===
export async function GET() {
  const encoder = new TextEncoder()
  const stream = new ReadableStream({
    async start(controller) {
      for await (const chunk of generateLargeDataset()) {
        controller.enqueue(encoder.encode(JSON.stringify(chunk) + '\\n'))
      }
      controller.close()
    },
  })

  return new Response(stream, {
    headers: { 'Content-Type': 'application/x-ndjson' },
  })
}

// === CORS headers ===
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  })
}`}
          highlights={[4, 21, 43, 44, 46, 62, 79]}
        />
        <KeyValueGrid
          items={[
            { key: "GET", value: "Cached by default unless using Request object, dynamic functions, or other dynamic APIs." },
            { key: "POST", value: "Never cached. Always runs on every request." },
            { key: "PUT/PATCH/DELETE", value: "Never cached. Used for data mutations." },
            { key: "HEAD", value: "Returns only headers. Auto-generated from GET if not defined." },
            { key: "OPTIONS", value: "CORS preflight. Must be explicitly defined for cross-origin requests." },
          ]}
        />
      </SubSection>

      <SubSection id="middleware" title="Middleware">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Middleware runs on the Edge before every matched request. Use it for authentication, redirects,
          rewrites, headers, A/B testing, and geo-routing. It must be at the project root.
        </p>
        <CodeBlock
          filename="middleware.ts"
          language="tsx"
          code={`import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export function middleware(request: NextRequest) {
  const { pathname, searchParams } = request.nextUrl
  const token = request.cookies.get('session-token')?.value

  // === Authentication gate ===
  const protectedPaths = ['/dashboard', '/settings', '/api/private']
  const isProtected = protectedPaths.some(p => pathname.startsWith(p))

  if (isProtected && !token) {
    const loginUrl = new URL('/login', request.url)
    loginUrl.searchParams.set('redirect', pathname)
    return NextResponse.redirect(loginUrl)
  }

  // === Geo-based routing ===
  const country = request.geo?.country ?? 'US'
  if (pathname === '/' && country === 'DE') {
    return NextResponse.rewrite(new URL('/de', request.url))
  }

  // === A/B Testing with cookies ===
  if (pathname === '/pricing') {
    const variant = request.cookies.get('ab-variant')?.value
    if (!variant) {
      const newVariant = Math.random() < 0.5 ? 'control' : 'treatment'
      const response = NextResponse.rewrite(
        new URL(\`/pricing/\${newVariant}\`, request.url)
      )
      response.cookies.set('ab-variant', newVariant, { maxAge: 60 * 60 * 24 * 30 })
      return response
    }
    return NextResponse.rewrite(new URL(\`/pricing/\${variant}\`, request.url))
  }

  // === Security headers ===
  const response = NextResponse.next()
  response.headers.set('X-Frame-Options', 'DENY')
  response.headers.set('X-Content-Type-Options', 'nosniff')
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin')
  return response
}

// Matcher: Only run middleware on specific paths
export const config = {
  matcher: [
    // Match all paths except static files and images
    '/((?!_next/static|_next/image|favicon.ico|.*\\\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}`}
          highlights={[4, 8, 9, 18, 24, 38, 46, 47]}
        />
        <Callout type="warning">
          Middleware runs on the Edge Runtime, which has limitations: no Node.js APIs, no filesystem access,
          limited package support. Keep middleware lightweight. For heavy computation, use Route Handlers
          or Server Components instead.
        </Callout>
      </SubSection>

      <SubSection id="api-patterns" title="Advanced API Patterns">
        <CodeBlock
          filename="Webhook Handler with Signature Verification"
          language="tsx"
          code={`// app/api/webhook/stripe/route.ts
import { headers } from 'next/headers'
import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!)

export async function POST(request: NextRequest) {
  const body = await request.text() // Raw body for signature
  const headersList = await headers()
  const signature = headersList.get('stripe-signature')!

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    )
  } catch (err) {
    return NextResponse.json(
      { error: 'Invalid signature' },
      { status: 400 }
    )
  }

  // Handle the event
  switch (event.type) {
    case 'checkout.session.completed':
      const session = event.data.object
      await fulfillOrder(session)
      break
    case 'customer.subscription.updated':
      await updateSubscription(event.data.object)
      break
  }

  return NextResponse.json({ received: true })
}

// Route segment config for webhooks
export const runtime = 'nodejs'  // Use Node.js runtime (not Edge)
export const maxDuration = 30    // Allow up to 30s for processing`}
          highlights={[8, 9, 15, 16, 17, 42, 43]}
        />
        <CodeBlock
          filename="Rate-Limited API with Edge Config"
          language="tsx"
          code={`// app/api/ai/route.ts
import { NextRequest, NextResponse } from 'next/server'

// Simple in-memory rate limiter (use Redis in production)
const rateLimit = new Map<string, { count: number; resetAt: number }>()

export async function POST(request: NextRequest) {
  // Rate limiting
  const ip = request.headers.get('x-forwarded-for') ?? 'anonymous'
  const now = Date.now()
  const windowMs = 60_000 // 1 minute window
  const maxRequests = 10

  const entry = rateLimit.get(ip)
  if (entry && entry.resetAt > now && entry.count >= maxRequests) {
    return NextResponse.json(
      { error: 'Rate limit exceeded' },
      {
        status: 429,
        headers: {
          'Retry-After': String(Math.ceil((entry.resetAt - now) / 1000)),
          'X-RateLimit-Limit': String(maxRequests),
          'X-RateLimit-Remaining': '0',
        },
      }
    )
  }

  if (!entry || entry.resetAt <= now) {
    rateLimit.set(ip, { count: 1, resetAt: now + windowMs })
  } else {
    entry.count++
  }

  // Process the actual request...
  const body = await request.json()
  const result = await processRequest(body)
  return NextResponse.json(result)
}`}
          highlights={[8, 9, 15]}
        />
      </SubSection>
    </section>
  )
}
