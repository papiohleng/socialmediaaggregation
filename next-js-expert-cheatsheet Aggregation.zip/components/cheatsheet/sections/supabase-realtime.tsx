import { CodeBlock, InlineCode } from "../code-block"
import { SectionHeader, SubSection, Callout, KeyValueGrid } from "../section-header"

export function SupabaseRealtimeSection() {
  return (
    <section>
      <SectionHeader
        id="supabase-realtime"
        title="Real-Time Updates"
        description="Supabase Realtime pushes database changes to connected clients over WebSockets. Build live dashboards, collaborative editors, chat apps, and notification systems with zero polling. This is the definitive guide to every Realtime pattern."
        badge="CHAPTER 13"
      />

      <SubSection id="realtime-concepts" title="Core Concepts">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Supabase Realtime offers three channel types. Understanding when to use each is the difference
          between a sluggish app and a lightning-fast collaborative experience.
        </p>

        <KeyValueGrid items={[
          { key: "Postgres Changes", value: "Listen to INSERT, UPDATE, DELETE on specific tables. Data flows from DB -> client. Most common pattern." },
          { key: "Broadcast", value: "Pub/sub messaging between clients via server. No database involved. Perfect for cursor positions, typing indicators." },
          { key: "Presence", value: "Track which users are online and share ephemeral state. Built-in join/leave events. Powers 'who is online' features." },
        ]} />

        <Callout type="warning">
          Realtime requires you to enable it per-table in your Supabase project settings.
          RLS policies also apply to Realtime — users only receive changes they are authorized to see.
          If a user&apos;s RLS policy blocks SELECT, they won&apos;t receive Realtime events for that row.
        </Callout>
      </SubSection>

      <SubSection id="realtime-postgres" title="Postgres Changes (Database Listeners)">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          The most powerful pattern. Subscribe to table changes and your UI updates instantly
          when any client (or server) modifies data.
        </p>

        <CodeBlock
          filename="hooks/use-realtime-posts.ts"
          language="ts"
          code={`'use client'

import { createClient } from '@/lib/supabase/client'
import { useEffect } from 'react'
import useSWR from 'swr'

interface Post {
  id: string
  title: string
  content: string
  user_id: string
  created_at: string
}

export function useRealtimePosts() {
  const supabase = createClient()

  // Initial fetch + cache with SWR
  const { data: posts, mutate } = useSWR<Post[]>(
    'posts',
    async () => {
      const { data, error } = await supabase
        .from('posts')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) throw error
      return data
    }
  )

  useEffect(() => {
    // Subscribe to ALL changes on the posts table
    const channel = supabase
      .channel('posts-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',        // Listen to INSERT, UPDATE, DELETE
          schema: 'public',
          table: 'posts',
        },
        (payload) => {
          // Optimistically update the local cache
          mutate((current) => {
            if (!current) return current

            switch (payload.eventType) {
              case 'INSERT':
                return [payload.new as Post, ...current]

              case 'UPDATE':
                return current.map((post) =>
                  post.id === (payload.new as Post).id
                    ? (payload.new as Post)
                    : post
                )

              case 'DELETE':
                return current.filter(
                  (post) => post.id !== (payload.old as Post).id
                )

              default:
                return current
            }
          }, false) // false = don't revalidate from server
        }
      )
      .subscribe()

    // CRITICAL: Unsubscribe on unmount to prevent memory leaks
    return () => {
      supabase.removeChannel(channel)
    }
  }, [supabase, mutate])

  return {
    posts: posts ?? [],
    isLoading: posts === undefined,
  }
}`}
          highlights={[34, 35, 36, 37, 38, 39, 40, 44, 45, 49, 50, 53, 54, 60, 61, 67, 72, 73]}
        />

        <Callout type="tip">
          The <InlineCode>false</InlineCode> argument to <InlineCode>mutate()</InlineCode> prevents SWR from
          revalidating with the server. Since the Realtime payload already contains the latest data,
          re-fetching would be redundant and wasteful. This gives you instant updates with zero extra network requests.
        </Callout>
      </SubSection>

      <SubSection id="realtime-filtered" title="Filtered Subscriptions">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          You don&apos;t have to listen to every change. Filter by event type, specific columns,
          or row-level conditions to receive only the changes you care about.
        </p>

        <CodeBlock
          filename="Filtered channel patterns"
          language="ts"
          code={`// Listen to only INSERTs on a specific table
const channel = supabase
  .channel('new-messages')
  .on(
    'postgres_changes',
    {
      event: 'INSERT',      // Only new rows
      schema: 'public',
      table: 'messages',
      filter: 'room_id=eq.room-123',  // Only this room
    },
    (payload) => {
      addMessage(payload.new)
    }
  )
  .subscribe()

// Listen to UPDATEs on a specific column
const statusChannel = supabase
  .channel('order-status')
  .on(
    'postgres_changes',
    {
      event: 'UPDATE',
      schema: 'public',
      table: 'orders',
      filter: \`user_id=eq.\${userId}\`,  // Only my orders
    },
    (payload) => {
      // Check if the status column actually changed
      if (payload.old.status !== payload.new.status) {
        showNotification(\`Order \${payload.new.id}: \${payload.new.status}\`)
      }
    }
  )
  .subscribe()

// Multiple listeners on one channel (efficient!)
const multiChannel = supabase
  .channel('dashboard')
  .on('postgres_changes',
    { event: 'INSERT', schema: 'public', table: 'orders' },
    handleNewOrder
  )
  .on('postgres_changes',
    { event: 'UPDATE', schema: 'public', table: 'inventory' },
    handleInventoryChange
  )
  .on('postgres_changes',
    { event: '*', schema: 'public', table: 'notifications' },
    handleNotification
  )
  .subscribe()`}
          highlights={[7, 10, 25, 28, 31, 39, 40, 41, 42, 44, 45, 48, 49]}
        />
      </SubSection>

      <SubSection id="realtime-broadcast" title="Broadcast (Client-to-Client Messaging)">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Broadcast sends ephemeral messages between clients — no database writes. Sub-millisecond
          latency. Perfect for cursor positions, typing indicators, collaborative selections, and
          any state that doesn&apos;t need persistence.
        </p>

        <CodeBlock
          filename="Collaborative cursors"
          language="tsx"
          code={`'use client'

import { createClient } from '@/lib/supabase/client'
import { useEffect, useRef, useCallback } from 'react'
import useSWR from 'swr'

interface CursorPosition {
  userId: string
  name: string
  x: number
  y: number
  color: string
}

export function useCollaborativeCursors(roomId: string, currentUser: {
  id: string; name: string; color: string
}) {
  const supabase = createClient()
  const { data: cursors, mutate } = useSWR<Record<string, CursorPosition>>(
    \`cursors-\${roomId}\`,
    () => ({})  // Start with empty map
  )

  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null)

  useEffect(() => {
    const channel = supabase.channel(\`room-\${roomId}\`)

    channel
      .on('broadcast', { event: 'cursor-move' }, ({ payload }) => {
        mutate((prev) => ({
          ...prev,
          [payload.userId]: payload as CursorPosition,
        }), false)
      })
      .on('broadcast', { event: 'cursor-leave' }, ({ payload }) => {
        mutate((prev) => {
          const next = { ...prev }
          delete next[payload.userId]
          return next
        }, false)
      })
      .subscribe()

    channelRef.current = channel

    return () => {
      // Notify others that this cursor is leaving
      channel.send({
        type: 'broadcast',
        event: 'cursor-leave',
        payload: { userId: currentUser.id },
      })
      supabase.removeChannel(channel)
    }
  }, [supabase, roomId, currentUser.id, mutate])

  // Throttled cursor broadcast
  const broadcastCursor = useCallback(
    (x: number, y: number) => {
      channelRef.current?.send({
        type: 'broadcast',
        event: 'cursor-move',
        payload: {
          userId: currentUser.id,
          name: currentUser.name,
          x,
          y,
          color: currentUser.color,
        },
      })
    },
    [currentUser]
  )

  return { cursors: cursors ?? {}, broadcastCursor }
}`}
          highlights={[27, 30, 31, 37, 49, 50, 51, 52, 61, 62, 63]}
        />
      </SubSection>

      <SubSection id="realtime-presence" title="Presence (Online Users)">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Presence tracks which users are currently connected and shares ephemeral state
          about each user. Built-in join/leave events handle user lifecycle automatically.
        </p>

        <CodeBlock
          filename="hooks/use-online-users.ts"
          language="ts"
          code={`'use client'

import { createClient } from '@/lib/supabase/client'
import { useEffect } from 'react'
import useSWR from 'swr'

interface OnlineUser {
  userId: string
  name: string
  avatar: string
  status: 'online' | 'away' | 'busy'
  lastSeen: string
}

export function useOnlineUsers(roomId: string, currentUser: OnlineUser) {
  const supabase = createClient()
  const { data: onlineUsers, mutate } = useSWR<OnlineUser[]>(
    \`presence-\${roomId}\`,
    () => []
  )

  useEffect(() => {
    const channel = supabase.channel(\`presence-\${roomId}\`, {
      config: {
        presence: {
          key: currentUser.userId,  // Unique key per user
        },
      },
    })

    channel
      .on('presence', { event: 'sync' }, () => {
        // Full state sync — fires on initial load and every change
        const state = channel.presenceState<OnlineUser>()
        const users = Object.values(state).flatMap(
          (presences) => presences
        )
        mutate(users, false)
      })
      .on('presence', { event: 'join' }, ({ newPresences }) => {
        console.log('Users joined:', newPresences)
      })
      .on('presence', { event: 'leave' }, ({ leftPresences }) => {
        console.log('Users left:', leftPresences)
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          // Track this user's presence
          await channel.track({
            userId: currentUser.userId,
            name: currentUser.name,
            avatar: currentUser.avatar,
            status: currentUser.status,
            lastSeen: new Date().toISOString(),
          })
        }
      })

    return () => {
      channel.untrack()
      supabase.removeChannel(channel)
    }
  }, [supabase, roomId, currentUser, mutate])

  // Update status (e.g., when user goes idle)
  const updateStatus = async (status: OnlineUser['status']) => {
    const channel = supabase.channel(\`presence-\${roomId}\`)
    await channel.track({
      ...currentUser,
      status,
      lastSeen: new Date().toISOString(),
    })
  }

  return {
    onlineUsers: onlineUsers ?? [],
    onlineCount: onlineUsers?.length ?? 0,
    updateStatus,
  }
}`}
          highlights={[24, 27, 32, 33, 34, 35, 40, 41, 47, 48, 49, 50, 51, 52, 58, 59]}
        />
      </SubSection>

      <SubSection id="realtime-component" title="Full-Stack Real-Time Component">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Putting it all together — a complete Server Component page that fetches initial data on the
          server and a Client Component that keeps it live with Realtime.
        </p>

        <CodeBlock
          filename="app/chat/page.tsx (Server Component)"
          language="tsx"
          code={`import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { ChatRoom } from './chat-room'

export default async function ChatPage() {
  const supabase = await createClient()

  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  // Fetch initial messages on the server (fast, SEO-friendly)
  const { data: messages } = await supabase
    .from('messages')
    .select('*, profiles(display_name, avatar_url)')
    .order('created_at', { ascending: true })
    .limit(50)

  return (
    <ChatRoom
      initialMessages={messages ?? []}
      currentUser={user}
    />
  )
}`}
          highlights={[8, 9, 12, 13, 14]}
        />

        <CodeBlock
          filename="app/chat/chat-room.tsx (Client Component)"
          language="tsx"
          code={`'use client'

import { createClient } from '@/lib/supabase/client'
import { useEffect, useRef, useState } from 'react'
import type { User } from '@supabase/supabase-js'

interface Message {
  id: string
  content: string
  user_id: string
  created_at: string
  profiles: { display_name: string; avatar_url: string }
}

export function ChatRoom({
  initialMessages,
  currentUser,
}: {
  initialMessages: Message[]
  currentUser: User
}) {
  const supabase = createClient()
  const [messages, setMessages] = useState(initialMessages)
  const [input, setInput] = useState('')
  const bottomRef = useRef<HTMLDivElement>(null)

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('chat')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages' },
        async (payload) => {
          // Fetch the full message with joined profile data
          const { data } = await supabase
            .from('messages')
            .select('*, profiles(display_name, avatar_url)')
            .eq('id', payload.new.id)
            .single()

          if (data) {
            setMessages((prev) => [...prev, data])
          }
        }
      )
      .subscribe()

    return () => { supabase.removeChannel(channel) }
  }, [supabase])

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    const { error } = await supabase.from('messages').insert({
      content: input.trim(),
      user_id: currentUser.id,
    })

    if (!error) setInput('')
    // No need to update local state — Realtime handles it!
  }

  return (
    <div className="flex flex-col h-screen">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div key={msg.id} className="flex gap-3">
            <span className="font-medium">
              {msg.profiles.display_name}
            </span>
            <p>{msg.content}</p>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
      <form onSubmit={sendMessage} className="p-4 border-t">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type a message..."
        />
        <button type="submit">Send</button>
      </form>
    </div>
  )
}`}
          highlights={[23, 29, 30, 31, 32, 33, 34, 35, 36, 37, 62, 63, 66]}
        />

        <Callout type="tip">
          Notice line 66: we don&apos;t manually update <InlineCode>messages</InlineCode> state after insert.
          The Realtime subscription on line 29 will fire automatically with the new message, keeping
          all connected clients in sync. This is the canonical Supabase Realtime pattern.
        </Callout>
      </SubSection>

      <SubSection id="realtime-cleanup" title="Cleanup & Performance">
        <KeyValueGrid items={[
          { key: "removeChannel()", value: "Always call in useEffect cleanup. Prevents WebSocket memory leaks and ghost subscriptions." },
          { key: "untrack()", value: "Call before removeChannel() for Presence channels. Notifies others the user left." },
          { key: "Channel naming", value: "Use descriptive, unique names. Same name = same channel. Avoid collisions across components." },
          { key: "Throttle broadcasts", value: "For high-frequency events (cursors), throttle to 30-60fps. Don't send on every mousemove." },
          { key: "filter parameter", value: "Always filter server-side when possible. Reduces WebSocket traffic and client processing." },
          { key: "mutate(_, false)", value: "Pass false to SWR mutate to skip server revalidation. Realtime data is already fresh." },
        ]} />
      </SubSection>
    </section>
  )
}
