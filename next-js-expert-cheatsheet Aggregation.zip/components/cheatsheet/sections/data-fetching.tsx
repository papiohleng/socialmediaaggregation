import { CodeBlock, InlineCode } from "../code-block"
import { SectionHeader, SubSection, Callout, KeyValueGrid } from "../section-header"

export function DataFetchingSection() {
  return (
    <section>
      <SectionHeader
        id="data"
        title="Data Fetching"
        description="From server-side fetching to caching, revalidation, Server Actions, and the new 'use cache' directive. This is the engine room of every Next.js application."
        badge="CHAPTER 04"
      />

      <SubSection id="server-fetch" title="Server-Side Fetching">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          In Server Components, you fetch data directly. No <InlineCode>useEffect</InlineCode>. No loading states to manage manually.
          No API routes to build just to proxy data. Just async/await at the component level.
        </p>
        <CodeBlock
          filename="Data Fetching Patterns"
          language="tsx"
          code={`// Pattern 1: Direct database access
async function AnalyticsView() {
  const metrics = await db.metrics.aggregate({
    _sum: { revenue: true, orders: true },
    where: { date: { gte: thirtyDaysAgo } },
  })
  return <Dashboard metrics={metrics} />
}

// Pattern 2: Fetch API with revalidation
async function PricingTable() {
  const res = await fetch('https://api.stripe.com/v1/prices', {
    headers: { Authorization: \`Bearer \${process.env.STRIPE_SECRET}\` },
    next: {
      revalidate: 3600,      // Revalidate every hour
      tags: ['pricing'],      // Tag for on-demand revalidation
    },
  })
  const prices = await res.json()
  return <PriceGrid prices={prices} />
}

// Pattern 3: Parallel data fetching (CRITICAL for performance)
async function DashboardPage() {
  // ❌ SLOW: Sequential — each waits for the previous
  const user = await getUser()
  const posts = await getPosts()
  const analytics = await getAnalytics()
  // Total time: user(200ms) + posts(500ms) + analytics(300ms) = 1000ms

  // ✅ FAST: Parallel — all fetch simultaneously
  const [user2, posts2, analytics2] = await Promise.all([
    getUser(),
    getPosts(),
    getAnalytics(),
  ])
  // Total time: max(200ms, 500ms, 300ms) = 500ms

  return <Dashboard user={user2} posts={posts2} analytics={analytics2} />
}

// Pattern 4: Preloading data
// lib/data.ts
import { cache } from 'react'

export const getUser = cache(async (id: string) => {
  return db.user.findUnique({ where: { id } })
})

export const preloadUser = (id: string) => {
  void getUser(id) // Fire and forget — starts fetch early
}

// In a layout, preload data for child pages:
export default function Layout({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  preloadUser(id) // Child page's getUser() hits warm cache
  return <div>{children}</div>
}`}
          highlights={[24, 25, 31, 32, 36, 43, 47, 48, 52]}
        />
        <Callout type="tip">
          React's <InlineCode>cache()</InlineCode> function deduplicates requests within a single render pass.
          If multiple components call <InlineCode>getUser(id)</InlineCode> with the same argument during one request,
          the database is hit only once. This is automatic request deduplication.
        </Callout>
      </SubSection>

      <SubSection id="caching-revalidation" title="Caching & Revalidation">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Next.js has a multi-layered caching system. Understanding each layer and how to control them
          is the difference between a blazing fast app and a stale nightmare.
        </p>
        <KeyValueGrid
          items={[
            { key: "Request Memoization", value: "React cache() deduplicates identical requests within a single render pass. Automatic." },
            { key: "Data Cache", value: "Server-side cache for fetch() results. Persists across requests and deployments." },
            { key: "Full Route Cache", value: "Pre-rendered HTML and RSC Payload cached at build time for static routes." },
            { key: "Router Cache", value: "Client-side cache of visited routes for instant back/forward navigation." },
          ]}
        />
        <CodeBlock
          filename="Revalidation Strategies"
          language="tsx"
          code={`// === TIME-BASED REVALIDATION ===

// Per-fetch revalidation
const data = await fetch('https://api.example.com/data', {
  next: { revalidate: 60 }, // Revalidate every 60 seconds
})

// Per-route revalidation (applies to all fetches in the route)
export const revalidate = 3600 // Revalidate entire page every hour

// === ON-DEMAND REVALIDATION ===

// By path — revalidate specific routes
import { revalidatePath } from 'next/cache'
revalidatePath('/blog')          // Revalidate the blog listing page
revalidatePath('/blog/[slug]', 'page')  // Revalidate all blog posts

// By tag — surgical revalidation (Next.js 16)
import { revalidateTag } from 'next/cache'
revalidateTag('blog-posts', 'max')  // Requires cacheLife profile in Next.js 16

// First, tag your fetches:
const posts = await fetch('https://api.example.com/posts', {
  next: { tags: ['blog-posts'] },  // Tag this fetch
})
// Then revalidate by tag in a Server Action:
revalidateTag('blog-posts', 'max')  // Only this tagged data refetches

// === OPTING OUT OF CACHING ===
const freshData = await fetch('https://api.example.com/live', {
  cache: 'no-store',  // Always fetch fresh
})

// Or at the route level:
export const dynamic = 'force-dynamic'  // Entire page is dynamic
export const revalidate = 0             // Equivalent to no-store

// === updateTag (Next.js 16 — Server Actions only) ===
import { updateTag } from 'next/cache'

// Read-your-writes semantics: the UI immediately reflects the update
async function updateProfile(formData: FormData) {
  'use server'
  await db.user.update({ ... })
  updateTag(\`user-\${userId}\`)  // Caller sees fresh data immediately
}

// === refresh() (Next.js 16 — Server Actions only) ===
import { refresh } from 'next/cache'

// Refreshes UNCACHED data only. Does not touch the cache.
async function checkNewNotifications() {
  'use server'
  refresh()  // Re-runs dynamic data fetches without busting cache
}`}
          highlights={[4, 5, 8, 19, 20, 23, 30, 34, 35, 41, 42, 50, 51]}
        />
      </SubSection>

      <SubSection id="server-actions" title="Server Actions">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Server Actions are async functions that run on the server, called directly from client or server components.
          They replace traditional API routes for mutations. Think of them as RPC endpoints that Next.js
          manages for you.
        </p>
        <CodeBlock
          filename="app/actions.ts"
          language="tsx"
          code={`'use server'
// This file exports ONLY server functions.
// Each export becomes a POST endpoint under the hood.

import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { z } from 'zod'

// Schema validation (always validate on the server!)
const CreatePostSchema = z.object({
  title: z.string().min(1).max(200),
  content: z.string().min(10),
  published: z.boolean().default(false),
})

// Type-safe server action with validation
export async function createPost(formData: FormData) {
  // 1. Validate input
  const validated = CreatePostSchema.safeParse({
    title: formData.get('title'),
    content: formData.get('content'),
    published: formData.get('published') === 'on',
  })

  if (!validated.success) {
    return { error: validated.error.flatten().fieldErrors }
  }

  // 2. Auth check
  const session = await getSession()
  if (!session) {
    return { error: { _form: ['Unauthorized'] } }
  }

  // 3. Mutate data
  const post = await db.post.create({
    data: {
      ...validated.data,
      authorId: session.userId,
    },
  })

  // 4. Revalidate and redirect
  revalidatePath('/blog')
  redirect(\`/blog/\${post.slug}\`)
}

// === Using Server Actions ===

// Pattern 1: Progressive enhancement with <form>
// Works even WITHOUT JavaScript (form submits normally)
function CreatePostForm() {
  return (
    <form action={createPost}>
      <input name="title" required />
      <textarea name="content" required />
      <button type="submit">Publish</button>
    </form>
  )
}

// Pattern 2: With useActionState for loading/error states
'use client'
import { useActionState } from 'react'

function EnhancedForm() {
  const [state, formAction, isPending] = useActionState(createPost, null)

  return (
    <form action={formAction}>
      <input name="title" required />
      {state?.error?.title && (
        <p className="text-red-500">{state.error.title}</p>
      )}
      <button disabled={isPending}>
        {isPending ? 'Publishing...' : 'Publish'}
      </button>
    </form>
  )
}

// Pattern 3: Optimistic updates
import { useOptimistic } from 'react'

function LikeButton({ likes, postId }: { likes: number; postId: string }) {
  const [optimisticLikes, addOptimistic] = useOptimistic(
    likes,
    (current, _) => current + 1
  )

  return (
    <form action={async () => {
      addOptimistic(null)         // Optimistic: instant UI update
      await likePost(postId)      // Server: actual mutation
    }}>
      <button>{optimisticLikes} Likes</button>
    </form>
  )
}`}
          highlights={[1, 2, 10, 11, 12, 13, 17, 50, 51, 65, 68, 84, 85, 86]}
        />
        <Callout type="danger">
          Always validate inputs in Server Actions. They are publicly accessible POST endpoints.
          Anyone can call them with arbitrary data. Use Zod or similar for runtime validation.
          Never trust the client.
        </Callout>
      </SubSection>

      <SubSection id="use-cache" title="'use cache' Directive">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          The <InlineCode>{"'use cache'"}</InlineCode> directive is the next evolution of caching in Next.js.
          It uses the compiler to automatically generate cache keys and can be applied at the page, component, or function level.
        </p>
        <CodeBlock
          filename="Cache Components (Next.js 16)"
          language="tsx"
          code={`// Enable in next.config.mjs:
// { cacheComponents: true }

// === File-level caching ===
'use cache'

export default async function StaticPage() {
  const data = await fetch('https://api.example.com/data')
  return <div>{data}</div>
}
// Entire page is cached. Compiler auto-generates cache key.

// === Component-level caching ===
export async function PricingTable() {
  'use cache'
  const prices = await getStripePrices()
  return (
    <table>
      {prices.map(p => <tr key={p.id}><td>{p.name}</td></tr>)}
    </table>
  )
}
// Only this component is cached. Parent can be dynamic.

// === Function-level caching ===
export async function getGlobalConfig() {
  'use cache'
  const config = await db.config.findFirst()
  return config
}
// Return value is cached and reused across requests.

// === Combining with cacheLife ===
import { cacheLife } from 'next/cache'

export async function RealtimeMetrics() {
  'use cache'
  cacheLife('seconds')  // Built-in profiles: seconds, minutes, hours, days, max

  const metrics = await getMetrics()
  return <MetricsDisplay data={metrics} />
}

// === Combining with cacheTag ===
import { cacheTag } from 'next/cache'

export async function UserProfile({ userId }: { userId: string }) {
  'use cache'
  cacheTag(\`user-\${userId}\`)  // Tag for targeted revalidation

  const user = await getUser(userId)
  return <Profile user={user} />
}

// In a Server Action:
// revalidateTag(\`user-\${userId}\`, 'max')  // Only this user's cache busts`}
          highlights={[4, 5, 15, 27, 37, 38, 48, 49]}
        />
        <Callout type="tip">
          <InlineCode>{"'use cache'"}</InlineCode> is the inverse of <InlineCode>{"'use client'"}</InlineCode>.
          While <InlineCode>{"'use client'"}</InlineCode> says "this needs the browser," <InlineCode>{"'use cache'"}</InlineCode> says
          "this can be cached." The compiler handles cache key generation automatically based on the function's parameters.
        </Callout>
      </SubSection>
    </section>
  )
}
