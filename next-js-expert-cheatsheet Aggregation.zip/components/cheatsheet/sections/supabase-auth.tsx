import { CodeBlock, InlineCode } from "../code-block"
import { SectionHeader, SubSection, Callout, KeyValueGrid } from "../section-header"

export function SupabaseAuthSection() {
  return (
    <section>
      <SectionHeader
        id="supabase-auth"
        title="Supabase Auth"
        description="Complete authentication system — sign up, login, logout, password reset, OAuth providers, email confirmation, and session management. Every pattern you need for production auth with zero third-party dependencies."
        badge="CHAPTER 12"
      />

      <SubSection id="auth-signup" title="Sign Up Flow">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Supabase Auth handles user registration with email confirmation by default. After calling
          <InlineCode>signUp()</InlineCode>, users receive a confirmation email. Until confirmed,
          <InlineCode>auth.uid()</InlineCode> returns <InlineCode>null</InlineCode> in RLS policies,
          blocking all protected writes. This is by design.
        </p>

        <CodeBlock
          filename="app/auth/sign-up/page.tsx"
          language="tsx"
          code={`'use client'

import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'
import { useState } from 'react'

export default function SignUpPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    if (password !== confirmPassword) {
      setError('Passwords do not match')
      return
    }

    setLoading(true)
    setError(null)
    const supabase = createClient()

    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        // REQUIRED: Where to redirect after email confirmation
        emailRedirectTo:
          process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL ||
          \`\${window.location.origin}/protected\`,
        // Optional: Attach metadata to the user
        data: {
          display_name: email.split('@')[0],
        },
      },
    })

    if (error) {
      setError(error.message)
    } else {
      router.push('/auth/sign-up-success')
    }
    setLoading(false)
  }

  return (
    <form onSubmit={handleSignUp}>
      <input type="email" value={email}
        onChange={(e) => setEmail(e.target.value)} required />
      <input type="password" value={password}
        onChange={(e) => setPassword(e.target.value)} required />
      <input type="password" value={confirmPassword}
        onChange={(e) => setConfirmPassword(e.target.value)} required />
      {error && <p className="text-destructive">{error}</p>}
      <button type="submit" disabled={loading}>
        {loading ? 'Creating account...' : 'Sign Up'}
      </button>
    </form>
  )
}`}
          highlights={[25, 26, 30, 31, 32, 33, 35, 36, 37, 44]}
        />

        <Callout type="danger" title="The #1 Supabase Auth Mistake">
          Never try to insert into RLS-protected tables immediately after <InlineCode>signUp()</InlineCode>.
          There is no active session until the user confirms their email. Use a database trigger
          with <InlineCode>SECURITY DEFINER</InlineCode> to auto-create profile rows on signup instead.
        </Callout>
      </SubSection>

      <SubSection id="auth-login" title="Login Flow">
        <CodeBlock
          filename="app/auth/login/page.tsx"
          language="tsx"
          code={`'use client'

import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'
import { useState } from 'react'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    const supabase = createClient()

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      setError(error.message)
    } else {
      router.push('/protected')
      router.refresh() // Refresh server components with new session
    }
    setLoading(false)
  }

  return (
    <form onSubmit={handleLogin}>
      <input type="email" value={email}
        onChange={(e) => setEmail(e.target.value)} required />
      <input type="password" value={password}
        onChange={(e) => setPassword(e.target.value)} required />
      {error && <p className="text-destructive">{error}</p>}
      <button type="submit" disabled={loading}>
        {loading ? 'Signing in...' : 'Sign In'}
      </button>
    </form>
  )
}`}
          highlights={[20, 21, 22, 28, 29]}
        />

        <Callout type="tip">
          Always call <InlineCode>router.refresh()</InlineCode> after login. This forces all Server Components
          to re-render with the new session, ensuring protected data appears immediately without
          a full page reload.
        </Callout>
      </SubSection>

      <SubSection id="auth-logout" title="Logout">
        <CodeBlock
          filename="components/logout-button.tsx"
          language="tsx"
          code={`'use client'

import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

export function LogoutButton() {
  const router = useRouter()

  const handleLogout = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push('/auth/login')
    router.refresh()
  }

  return (
    <button onClick={handleLogout}>
      Sign Out
    </button>
  )
}`}
          highlights={[10, 11, 12]}
        />
      </SubSection>

      <SubSection id="auth-server-guard" title="Server-Side Auth Guards">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Protect Server Components and Server Actions by reading the session from the server client.
          This is the definitive pattern for auth-gated pages.
        </p>

        <CodeBlock
          filename="app/protected/page.tsx"
          language="tsx"
          code={`import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'

export default async function ProtectedPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  // If no user, redirect to login
  if (!user) {
    redirect('/auth/login')
  }

  // Fetch user-specific data (RLS enforces ownership automatically)
  const { data: posts } = await supabase
    .from('posts')
    .select('*')
    .order('created_at', { ascending: false })

  return (
    <main>
      <h1>Welcome, {user.email}</h1>
      <p>User ID: {user.id}</p>
      {posts?.map(post => (
        <article key={post.id}>
          <h2>{post.title}</h2>
          <p>{post.content}</p>
        </article>
      ))}
    </main>
  )
}`}
          highlights={[5, 7, 8, 12, 13, 17, 18, 19]}
        />

        <Callout type="warning">
          Always use <InlineCode>getUser()</InlineCode>, never <InlineCode>getSession()</InlineCode>, for
          server-side auth checks. <InlineCode>getUser()</InlineCode> validates the JWT with Supabase&apos;s servers.
          <InlineCode>getSession()</InlineCode> only reads the local JWT without validation —
          a tampered token would pass.
        </Callout>
      </SubSection>

      <SubSection id="auth-server-actions" title="Auth in Server Actions">
        <CodeBlock
          filename="app/actions/posts.ts"
          language="ts"
          code={`'use server'

import { createClient } from '@/lib/supabase/server'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

export async function createPost(formData: FormData) {
  const supabase = await createClient()

  // Verify the user is authenticated
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect('/auth/login')
  }

  const title = formData.get('title') as string
  const content = formData.get('content') as string

  // Validate inputs
  if (!title?.trim() || !content?.trim()) {
    return { error: 'Title and content are required' }
  }

  // Insert with user_id — RLS validates this matches auth.uid()
  const { error } = await supabase.from('posts').insert({
    title: title.trim(),
    content: content.trim(),
    user_id: user.id,   // MUST match auth.uid() for RLS
  })

  if (error) {
    return { error: error.message }
  }

  revalidatePath('/protected')
  return { success: true }
}

export async function deletePost(postId: string) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect('/auth/login')
  }

  // RLS ensures only the owner can delete their own post
  const { error } = await supabase
    .from('posts')
    .delete()
    .eq('id', postId)

  if (error) {
    return { error: error.message }
  }

  revalidatePath('/protected')
  return { success: true }
}`}
          highlights={[8, 11, 12, 15, 16, 28, 29, 30, 31, 38, 54, 55, 56]}
        />
      </SubSection>

      <SubSection id="auth-oauth" title="OAuth Providers">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Supabase supports 20+ OAuth providers (Google, GitHub, Apple, Discord, etc.).
          The flow redirects users to the provider, then back to a callback route that exchanges
          the code for a session.
        </p>

        <CodeBlock
          filename="OAuth sign-in"
          language="tsx"
          code={`'use client'

import { createClient } from '@/lib/supabase/client'

export function OAuthButtons() {
  const handleOAuth = async (provider: 'google' | 'github' | 'apple') => {
    const supabase = createClient()

    const { error } = await supabase.auth.signInWithOAuth({
      provider,
      options: {
        redirectTo: \`\${window.location.origin}/auth/callback\`,
        // Request specific scopes
        scopes: provider === 'github' ? 'read:user user:email' : undefined,
      },
    })

    if (error) console.error('OAuth error:', error.message)
  }

  return (
    <div className="flex flex-col gap-2">
      <button onClick={() => handleOAuth('google')}>
        Continue with Google
      </button>
      <button onClick={() => handleOAuth('github')}>
        Continue with GitHub
      </button>
    </div>
  )
}`}
          highlights={[9, 10, 11, 12, 14]}
        />

        <CodeBlock
          filename="app/auth/callback/route.ts"
          language="ts"
          code={`import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url)
  const code = searchParams.get('code')
  const next = searchParams.get('next') ?? '/protected'

  if (code) {
    const supabase = await createClient()
    const { error } = await supabase.auth.exchangeCodeForSession(code)

    if (!error) {
      return NextResponse.redirect(\`\${origin}\${next}\`)
    }
  }

  // OAuth error — redirect to error page
  return NextResponse.redirect(\`\${origin}/auth/error\`)
}`}
          highlights={[6, 7, 10, 11, 14]}
        />
      </SubSection>

      <SubSection id="auth-password-reset" title="Password Reset">
        <CodeBlock
          filename="Password reset flow"
          language="tsx"
          code={`// Step 1: Request reset email
async function requestPasswordReset(email: string) {
  const supabase = createClient()
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: \`\${window.location.origin}/auth/update-password\`,
  })
  return { error }
}

// Step 2: Handle the redirect and update password
// app/auth/update-password/page.tsx
'use client'
export default function UpdatePasswordPage() {
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    const supabase = createClient()

    const { error } = await supabase.auth.updateUser({
      password,
    })

    if (error) {
      alert(error.message)
    } else {
      router.push('/protected')
    }
    setLoading(false)
  }

  return (
    <form onSubmit={handleUpdate}>
      <input type="password" value={password}
        onChange={e => setPassword(e.target.value)} />
      <button type="submit" disabled={loading}>
        Update Password
      </button>
    </form>
  )
}`}
          highlights={[4, 5, 23, 24]}
        />
      </SubSection>

      <SubSection id="auth-user-metadata" title="User Metadata">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Supabase stores custom data on users via <InlineCode>raw_user_meta_data</InlineCode> on the
          <InlineCode>auth.users</InlineCode> table. Set it during signup or update it later.
        </p>

        <CodeBlock
          filename="User metadata patterns"
          language="ts"
          code={`// Set metadata during signup
const { data, error } = await supabase.auth.signUp({
  email: 'user@example.com',
  password: 'secure-password',
  options: {
    data: {
      display_name: 'John Doe',
      avatar_url: 'https://example.com/avatar.jpg',
      role: 'user',        // Custom role field
      onboarded: false,     // Track onboarding state
    },
  },
})

// Read metadata from the user object
const { data: { user } } = await supabase.auth.getUser()
const displayName = user?.user_metadata?.display_name
const role = user?.user_metadata?.role

// Update metadata later
const { data, error } = await supabase.auth.updateUser({
  data: {
    onboarded: true,
    display_name: 'Jane Doe',
  },
})`}
          highlights={[6, 7, 8, 9, 10, 17, 18, 22, 23, 24]}
        />
      </SubSection>

      <SubSection id="auth-auto-profile" title="Auto-Create Profile on Signup">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Since you cannot write to RLS-protected tables before email confirmation, use a Postgres trigger
          to automatically create a profile row when a user signs up. This runs with <InlineCode>SECURITY DEFINER</InlineCode>
          privileges, bypassing RLS.
        </p>

        <CodeBlock
          filename="scripts/create_profile_trigger.sql"
          language="sql"
          code={`-- 1. Create the profiles table
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT,
  avatar_url TEXT,
  bio TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- 2. RLS policies for profiles
CREATE POLICY "Anyone can view profiles"
  ON public.profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

-- 3. Trigger function: auto-create profile on auth.users insert
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER              -- Bypasses RLS
SET search_path = public      -- Security best practice
AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'display_name', NEW.email),
    COALESCE(NEW.raw_user_meta_data ->> 'avatar_url', NULL)
  )
  ON CONFLICT (id) DO NOTHING;  -- Idempotent: safe to retry

  RETURN NEW;
END;
$$;

-- 4. Wire the trigger to auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();`}
          highlights={[3, 10, 26, 27, 30, 31, 32, 33, 36, 44, 45, 46]}
        />

        <Callout type="tip">
          The <InlineCode>ON CONFLICT DO NOTHING</InlineCode> makes this trigger idempotent. If the profile
          already exists (e.g., from a retry), it silently skips. The <InlineCode>ON DELETE CASCADE</InlineCode>
          on the foreign key ensures deleting a user automatically deletes their profile.
        </Callout>
      </SubSection>

      <SubSection id="auth-onchange" title="Auth State Listener">
        <CodeBlock
          filename="hooks/use-auth.ts"
          language="ts"
          code={`'use client'

import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'
import { useEffect } from 'react'
import type { User } from '@supabase/supabase-js'
import useSWR from 'swr'

export function useAuth() {
  const router = useRouter()
  const supabase = createClient()

  const { data: user, mutate } = useSWR<User | null>(
    'auth-user',
    async () => {
      const { data: { user } } = await supabase.auth.getUser()
      return user
    }
  )

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        // Re-fetch user on any auth event
        mutate()

        if (event === 'SIGNED_OUT') {
          router.push('/auth/login')
          router.refresh()
        }

        if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
          router.refresh() // Re-render server components
        }

        if (event === 'PASSWORD_RECOVERY') {
          router.push('/auth/update-password')
        }
      }
    )

    return () => subscription.unsubscribe()
  }, [supabase, router, mutate])

  return {
    user: user ?? null,
    isLoading: user === undefined,
    isAuthenticated: !!user,
  }
}`}
          highlights={[13, 14, 15, 16, 22, 25, 27, 28, 32, 33, 36, 37]}
        />
      </SubSection>
    </section>
  )
}
