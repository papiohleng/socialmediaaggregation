import { CodeBlock, InlineCode } from "../code-block"
import { SectionHeader, SubSection, Callout, KeyValueGrid } from "../section-header"

export function AuthSecuritySection() {
  return (
    <section>
      <SectionHeader
        id="auth-security"
        title="Auth & Security"
        description="Authentication patterns, authorization strategies, and security hardening. Getting auth wrong is the fastest path to a breach. Get it right the first time."
        badge="CHAPTER 07"
      />

      <SubSection id="authentication" title="Authentication">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Next.js does not include authentication out of the box. You integrate with providers
          like NextAuth.js (Auth.js), Clerk, Supabase Auth, or build your own with JWTs and sessions.
        </p>
        <CodeBlock
          filename="Middleware Auth Gate"
          language="tsx"
          code={`// middleware.ts — runs on Edge, before every request
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { verifyToken } from '@/lib/auth'

export async function middleware(request: NextRequest) {
  const token = request.cookies.get('session')?.value

  // Public routes that don't need auth
  const publicPaths = ['/login', '/register', '/api/auth', '/']
  const isPublic = publicPaths.some(p => request.nextUrl.pathname.startsWith(p))

  if (isPublic) return NextResponse.next()

  // Verify the session token
  if (!token) {
    return NextResponse.redirect(new URL('/login', request.url))
  }

  try {
    const payload = await verifyToken(token)

    // Add user info to headers for downstream use
    const response = NextResponse.next()
    response.headers.set('x-user-id', payload.userId)
    response.headers.set('x-user-role', payload.role)
    return response
  } catch {
    // Invalid token — clear cookie and redirect
    const response = NextResponse.redirect(new URL('/login', request.url))
    response.cookies.delete('session')
    return response
  }
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
}`}
          highlights={[1, 6, 7, 16, 20, 23, 24]}
        />
        <CodeBlock
          filename="Server-Side Session Helper"
          language="tsx"
          code={`// lib/auth.ts
import { cookies } from 'next/headers'
import { SignJWT, jwtVerify } from 'jose'

const secret = new TextEncoder().encode(process.env.JWT_SECRET!)

export async function createSession(userId: string, role: string) {
  const token = await new SignJWT({ userId, role })
    .setProtectedHeader({ alg: 'HS256' })
    .setExpirationTime('7d')
    .setIssuedAt()
    .sign(secret)

  const cookieStore = await cookies()
  cookieStore.set('session', token, {
    httpOnly: true,     // Not accessible via JavaScript
    secure: true,       // HTTPS only
    sameSite: 'lax',    // CSRF protection
    maxAge: 60 * 60 * 24 * 7, // 7 days
    path: '/',
  })
}

export async function getSession() {
  const cookieStore = await cookies()
  const token = cookieStore.get('session')?.value
  if (!token) return null

  try {
    const { payload } = await jwtVerify(token, secret)
    return payload as { userId: string; role: string }
  } catch {
    return null
  }
}

export async function requireSession() {
  const session = await getSession()
  if (!session) redirect('/login')
  return session
}

// Use in any Server Component or Server Action:
export default async function DashboardPage() {
  const session = await requireSession() // Redirects if not auth'd
  const user = await getUser(session.userId)
  return <Dashboard user={user} />
}`}
          highlights={[15, 16, 17, 18, 25, 37, 38, 44]}
        />
      </SubSection>

      <SubSection id="authorization" title="Authorization">
        <CodeBlock
          filename="Role-Based Access Control"
          language="tsx"
          code={`// lib/authorization.ts
type Role = 'user' | 'editor' | 'admin' | 'super_admin'

const ROLE_HIERARCHY: Record<Role, number> = {
  user: 0,
  editor: 1,
  admin: 2,
  super_admin: 3,
}

export function hasRole(userRole: Role, requiredRole: Role): boolean {
  return ROLE_HIERARCHY[userRole] >= ROLE_HIERARCHY[requiredRole]
}

// Reusable auth guard for Server Components
export async function withAuth<T>(
  requiredRole: Role,
  fn: (session: Session) => Promise<T>
): Promise<T> {
  const session = await requireSession()

  if (!hasRole(session.role as Role, requiredRole)) {
    throw new Error('Forbidden')
  }

  return fn(session)
}

// Usage in a page:
export default async function AdminPage() {
  return withAuth('admin', async (session) => {
    const stats = await getAdminStats()
    return <AdminDashboard stats={stats} user={session} />
  })
}

// Server Action authorization:
export async function deleteUser(userId: string) {
  'use server'
  const session = await requireSession()

  if (!hasRole(session.role as Role, 'admin')) {
    throw new Error('Forbidden: Admin access required')
  }

  // Only admins reach this point
  await db.user.delete({ where: { id: userId } })
  revalidatePath('/admin/users')
}`}
          highlights={[4, 5, 6, 7, 16, 17, 18, 38, 39, 42]}
        />
      </SubSection>

      <SubSection id="security-headers" title="Security Headers">
        <CodeBlock
          filename="next.config.mjs"
          language="tsx"
          code={`/** @type {import('next').NextConfig} */
const nextConfig = {
  // Security headers applied to all routes
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'DENY',                            // Prevent clickjacking
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',                          // Prevent MIME sniffing
          },
          {
            key: 'Referrer-Policy',
            value: 'strict-origin-when-cross-origin',  // Control referer info
          },
          {
            key: 'Permissions-Policy',
            value: 'camera=(), microphone=(), geolocation=()',  // Disable APIs
          },
          {
            key: 'Strict-Transport-Security',
            value: 'max-age=63072000; includeSubDomains; preload', // Force HTTPS
          },
          {
            key: 'Content-Security-Policy',
            value: [
              "default-src 'self'",
              "script-src 'self' 'unsafe-eval' 'unsafe-inline'",
              "style-src 'self' 'unsafe-inline'",
              "img-src 'self' data: https:",
              "font-src 'self'",
              "connect-src 'self' https:",
            ].join('; '),
          },
        ],
      },
    ]
  },
}

export default nextConfig`}
          highlights={[10, 11, 14, 15, 18, 19, 22, 23, 26, 27, 30, 31]}
        />
        <Callout type="danger">
          Never expose secrets in client-side code. Environment variables without the <InlineCode>NEXT_PUBLIC_</InlineCode> prefix
          are server-only. If you see a secret in your browser's network tab, you have a critical security vulnerability.
          Use <InlineCode>server-only</InlineCode> package to guarantee modules cannot be imported in Client Components.
        </Callout>
      </SubSection>
    </section>
  )
}
