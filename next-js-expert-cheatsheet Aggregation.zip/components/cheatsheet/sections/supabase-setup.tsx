'use client';

import { CodeBlock, InlineCode } from "../code-block"
import { SectionHeader, SubSection, Callout, KeyValueGrid } from "../section-header"

export function SupabaseSetupSection() {
  return (
    <section>
      <SectionHeader
        id="supabase-integration"
        title="Supabase Integration"
        description="Supabase is an open-source Firebase alternative providing a Postgres database, authentication, real-time subscriptions, edge functions, and storage. This chapter covers the definitive integration with Next.js — from client creation to type-safe queries."
        badge="CHAPTER 11"
      />

      <SubSection id="supabase-architecture" title="Architecture Overview">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Supabase uses the <InlineCode>@supabase/ssr</InlineCode> package to create framework-agnostic clients.
          In Next.js, you maintain <strong>two separate client factories</strong> — one for the browser and one for the server.
          The middleware layer refreshes auth tokens on every request. This is non-negotiable architecture.
        </p>

        <KeyValueGrid items={[
          { key: "lib/supabase/client.ts", value: "Browser client — uses createBrowserClient, singleton per tab" },
          { key: "lib/supabase/server.ts", value: "Server client — uses createServerClient with cookies(), created per-request" },
          { key: "lib/supabase/middleware.ts", value: "Middleware client — refreshes sessions, syncs cookies between request/response" },
          { key: "middleware.ts", value: "Root middleware — invokes updateSession() on every matched route" },
          { key: "NEXT_PUBLIC_SUPABASE_URL", value: "Your project URL — safe to expose publicly" },
          { key: "NEXT_PUBLIC_SUPABASE_ANON_KEY", value: "Anonymous key — safe to expose, RLS enforces security" },
        ]} />

        <Callout type="tip">
          The anon key is <strong>designed</strong> to be public. It can only access data that your Row Level Security policies allow.
          Your database is protected by RLS, not by hiding the key. This is a fundamental Supabase security model.
        </Callout>
      </SubSection>

      <SubSection id="supabase-client-setup" title="Client Setup">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          The browser client is a singleton — it reuses the same instance across re-renders. Never put this
          in a <InlineCode>useState</InlineCode> or <InlineCode>useRef</InlineCode>. Just call the factory.
        </p>

        <CodeBlock
          filename="lib/supabase/client.ts"
          language="ts"
          code={`import { createBrowserClient } from '@supabase/ssr'

export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )
}

// Usage in any Client Component:
// import { createClient } from '@/lib/supabase/client'
// const supabase = createClient()
// const { data } = await supabase.from('posts').select('*')`}
          highlights={[3, 4, 5, 6]}
        />

        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          The server client is different — it reads cookies from the incoming request and must be
          created <strong>fresh on every request</strong>. With Fluid Compute, never store this in a global variable.
        </p>

        <CodeBlock
          filename="lib/supabase/server.ts"
          language="ts"
          code={`import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'

export async function createClient() {
  const cookieStore = await cookies()

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll()
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            )
          } catch {
            // setAll called from a Server Component.
            // Safe to ignore if middleware refreshes sessions.
          }
        },
      },
    }
  )
}

// Usage in any Server Component or Server Action:
// import { createClient } from '@/lib/supabase/server'
// const supabase = await createClient()
// const { data } = await supabase.from('posts').select('*')`}
          highlights={[4, 5, 7, 8, 9, 12, 13, 15, 16]}
        />

        <Callout type="danger">
          Never call <InlineCode>cookies()</InlineCode> outside of a request context. The server client
          factory is <InlineCode>async</InlineCode> because <InlineCode>cookies()</InlineCode> must be awaited in Next.js 16.
          If you forget the <InlineCode>await</InlineCode>, you will get a cryptic runtime error.
        </Callout>
      </SubSection>

      <SubSection id="supabase-middleware-setup" title="Middleware Session Refresh">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          This is the most critical piece of the Supabase + Next.js integration. The middleware intercepts
          every request, creates a Supabase client with cookie access, calls <InlineCode>getUser()</InlineCode> to
          refresh the session, and ensures cookies are synchronized between the request and response objects.
          If you skip this, users will be randomly logged out.
        </p>

        <CodeBlock
          filename="lib/supabase/middleware.ts"
          language="ts"
          code={`import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

export async function updateSession(request: NextRequest) {
  let supabaseResponse = NextResponse.next({ request })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll()
        },
        setAll(cookiesToSet) {
          // 1. Set cookies on the request (for downstream Server Components)
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value)
          )
          // 2. Clone the response with updated request
          supabaseResponse = NextResponse.next({ request })
          // 3. Set cookies on the response (for the browser)
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          )
        },
      },
    }
  )

  // CRITICAL: Do not run ANY code between createServerClient
  // and supabase.auth.getUser(). Any error here causes random logouts.

  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Protect routes — redirect unauthenticated users
  if (!user && request.nextUrl.pathname.startsWith('/protected')) {
    const url = request.nextUrl.clone()
    url.pathname = '/auth/login'
    return NextResponse.redirect(url)
  }

  // CRITICAL: Always return supabaseResponse — never a new NextResponse.
  // The cookies on this object keep browser and server in sync.
  return supabaseResponse
}`}
          highlights={[5, 7, 8, 9, 16, 17, 21, 23, 24, 31, 32, 34, 35, 39, 40, 45]}
        />

        <CodeBlock
          filename="middleware.ts (root)"
          language="ts"
          code={`import { updateSession } from '@/lib/supabase/middleware'
import { type NextRequest } from 'next/server'

export async function middleware(request: NextRequest) {
  return await updateSession(request)
}

export const config = {
  matcher: [
    // Match all paths except static files and images
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}`}
          highlights={[1, 4, 5, 11]}
        />

        <Callout type="warning">
          The three-step cookie sync in <InlineCode>setAll</InlineCode> is not optional.
          Step 1 updates the request so downstream Server Components read fresh cookies.
          Step 2 clones the response with the updated request.
          Step 3 sets cookies on the response so the browser stores them.
          Skip any step and your auth will break silently.
        </Callout>
      </SubSection>

      <SubSection id="supabase-typegen" title="Type-Safe Database Queries">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Supabase generates TypeScript types directly from your database schema. This gives you full
          autocomplete on table names, column names, and query results. Generate types with the CLI
          and pass them as a generic to your client factories.
        </p>

        <CodeBlock
          filename="Generate types"
          language="bash"
          code={`# Install the Supabase CLI
npx supabase login
npx supabase gen types typescript \\
  --project-id your-project-id \\
  --schema public \\
  > lib/database.types.ts`}
        />

        <CodeBlock
          filename="lib/supabase/client.ts (typed)"
          language="ts"
          code={`import { createBrowserClient } from '@supabase/ssr'
import type { Database } from '@/lib/database.types'

export function createClient() {
  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )
}

// Now you get full autocomplete:
// supabase.from('posts')     <-- table names autocomplete
//   .select('id, title')     <-- column names autocomplete
//   .eq('status', 'published') <-- value types are enforced`}
          highlights={[2, 5]}
        />

        <CodeBlock
          filename="Type-safe query patterns"
          language="ts"
          code={`import type { Database } from '@/lib/database.types'

// Extract row types for use across your app
type Post = Database['public']['Tables']['posts']['Row']
type PostInsert = Database['public']['Tables']['posts']['Insert']
type PostUpdate = Database['public']['Tables']['posts']['Update']

// Use in components with full type safety
async function getPosts(): Promise<Post[]> {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('posts')
    .select('*')
    .order('created_at', { ascending: false })

  if (error) throw error
  return data
}

// Insert with type checking
async function createPost(post: PostInsert) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('posts')
    .insert(post)
    .select()
    .single()

  if (error) throw error
  return data
}`}
          highlights={[3, 4, 5, 9, 21]}
        />
      </SubSection>

      <SubSection id="supabase-directory" title="Directory Structure">
        <CodeBlock
          filename="Recommended project structure"
          language="text"
          code={`your-app/
├── middleware.ts                    # Root middleware (session refresh)
├── lib/
│   ├── database.types.ts           # Generated types (npx supabase gen types)
│   └── supabase/
│       ├── client.ts               # Browser client factory
│       ├── server.ts               # Server client factory
│       └── middleware.ts           # Session update logic
├── app/
│   ├── layout.tsx
│   ├── page.tsx
│   ├── auth/
│   │   ├── login/page.tsx          # Login form
│   │   ├── sign-up/page.tsx        # Registration form
│   │   ├── sign-up-success/page.tsx # Email confirmation notice
│   │   └── error/page.tsx          # Auth error handler
│   ├── protected/
│   │   └── page.tsx                # Auth-gated content
│   └── api/
│       └── ...                     # Route Handlers
└── scripts/
    ├── 001_create_tables.sql       # Schema migrations
    └── 002_seed_data.sql           # Seed data`}
        />
      </SubSection>
    </section>
  )
}
