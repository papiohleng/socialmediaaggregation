import { CodeBlock, InlineCode } from "../code-block"
import { SectionHeader, SubSection, Callout, KeyValueGrid } from "../section-header"

export function SupabaseRlsSection() {
  return (
    <section>
      <SectionHeader
        id="supabase-rls"
        title="Row Level Security"
        description="RLS is not optional. It is the firewall between your users and your data. Every table that stores user data MUST have RLS enabled with explicit policies. This chapter covers every policy pattern from basic ownership to multi-tenant RBAC."
        badge="CHAPTER 14"
      />

      <SubSection id="rls-fundamentals" title="RLS Fundamentals">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Row Level Security is a Postgres feature that restricts which rows a user can access at the
          database level. With RLS enabled, a table with <strong>no policies</strong> blocks all access.
          You explicitly grant access via policies. This is deny-by-default security — the gold standard.
        </p>

        <KeyValueGrid items={[
          { key: "auth.uid()", value: "Returns the UUID of the currently authenticated user from the JWT. The foundation of every policy." },
          { key: "auth.jwt()", value: "Returns the full JWT payload. Use to read claims like role, email, or custom metadata." },
          { key: "USING (expr)", value: "Row-level filter for SELECT, UPDATE, DELETE. The row is visible only if expr returns true." },
          { key: "WITH CHECK (expr)", value: "Validates new data on INSERT and UPDATE. The write succeeds only if expr returns true." },
          { key: "SECURITY DEFINER", value: "Function runs with the privileges of its creator, bypassing RLS. Use for triggers and admin operations." },
          { key: "SECURITY INVOKER", value: "Function runs with the caller's privileges. Default behavior. RLS applies normally." },
        ]} />

        <CodeBlock
          filename="RLS basics"
          language="sql"
          code={`-- Step 1: Enable RLS on the table (REQUIRED)
ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;

-- Without policies, the table is now completely locked.
-- Even the table owner can't read it through the API.

-- Step 2: Create policies to grant access
-- Syntax: CREATE POLICY "name" ON table FOR operation USING/WITH CHECK (expression);

-- The four operations:
-- SELECT  → USING clause    → "Can this user SEE this row?"
-- INSERT  → WITH CHECK      → "Can this user CREATE this row?"
-- UPDATE  → USING + CHECK   → "Can this user MODIFY this row, and is the new data valid?"
-- DELETE  → USING clause    → "Can this user REMOVE this row?"`}
          highlights={[2, 10, 11, 12, 13]}
        />

        <Callout type="danger">
          If you enable RLS on a table and forget to add policies, <strong>all API access is blocked</strong>.
          This is intentional. It is infinitely safer to accidentally block access than to accidentally expose data.
          Always test your policies after enabling RLS.
        </Callout>
      </SubSection>

      <SubSection id="rls-ownership" title="Pattern 1: User Ownership">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          The most common pattern. Each row has a <InlineCode>user_id</InlineCode> column. Users can only
          access rows where <InlineCode>user_id</InlineCode> matches their authenticated identity.
        </p>

        <CodeBlock
          filename="Ownership policies"
          language="sql"
          code={`-- Table: posts belong to users
CREATE TABLE public.posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;

-- SELECT: Users see only their own posts
CREATE POLICY "Users can view own posts"
  ON public.posts FOR SELECT
  USING (auth.uid() = user_id);

-- INSERT: Users can only create posts as themselves
CREATE POLICY "Users can create own posts"
  ON public.posts FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- UPDATE: Users can only edit their own posts
CREATE POLICY "Users can update own posts"
  ON public.posts FOR UPDATE
  USING (auth.uid() = user_id)        -- Can only target own rows
  WITH CHECK (auth.uid() = user_id);  -- New data must still be owned by them

-- DELETE: Users can only delete their own posts
CREATE POLICY "Users can delete own posts"
  ON public.posts FOR DELETE
  USING (auth.uid() = user_id);`}
          highlights={[6, 12, 17, 22, 27, 28, 33]}
        />

        <Callout type="tip">
          The UPDATE policy has <strong>both</strong> USING and WITH CHECK. USING controls which rows
          you can target. WITH CHECK validates the new data after the update. Without WITH CHECK,
          a user could update their own post and change <InlineCode>user_id</InlineCode> to someone
          else&apos;s UUID, effectively transferring ownership.
        </Callout>
      </SubSection>

      <SubSection id="rls-public-private" title="Pattern 2: Public + Private Data">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Common for social apps, blogs, and marketplaces where some data is publicly readable
          but only the owner can modify it.
        </p>

        <CodeBlock
          filename="Public read, private write"
          language="sql"
          code={`-- Anyone can read published posts (even anonymous users)
CREATE POLICY "Published posts are public"
  ON public.posts FOR SELECT
  USING (status = 'published');

-- Authors can see all their own posts (including drafts)
CREATE POLICY "Authors see own posts"
  ON public.posts FOR SELECT
  USING (auth.uid() = user_id);

-- Only the author can modify their posts
CREATE POLICY "Authors update own posts"
  ON public.posts FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Profiles: everyone can view, only owner can edit
CREATE POLICY "Public profiles"
  ON public.profiles FOR SELECT
  USING (true);   -- true = no restriction on SELECT

CREATE POLICY "Own profile update"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

-- Note: Multiple SELECT policies combine with OR logic.
-- If ANY SELECT policy returns true, the row is visible.`}
          highlights={[4, 9, 14, 15, 20, 26, 27]}
        />
      </SubSection>

      <SubSection id="rls-rbac" title="Pattern 3: Role-Based Access (RBAC)">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Use JWT claims or a roles table to implement role-based access. Supabase stores user metadata
          in the JWT, accessible via <InlineCode>auth.jwt()</InlineCode>.
        </p>

        <CodeBlock
          filename="RBAC with JWT claims"
          language="sql"
          code={`-- Approach 1: Read role from user metadata in JWT
-- (Set during signUp with options.data.role)

-- Admins can read everything
CREATE POLICY "Admins read all"
  ON public.posts FOR SELECT
  USING (
    (auth.jwt() -> 'user_metadata' ->> 'role') = 'admin'
  );

-- Admins can delete any post
CREATE POLICY "Admins delete all"
  ON public.posts FOR DELETE
  USING (
    (auth.jwt() -> 'user_metadata' ->> 'role') = 'admin'
  );

-- Approach 2: Use a separate roles table (more flexible)
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('user', 'editor', 'admin', 'super_admin')),
  UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Helper function to check roles (reusable across policies)
CREATE OR REPLACE FUNCTION public.has_role(required_role TEXT)
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = auth.uid()
      AND role = required_role
  );
$$;

-- Use the helper in policies
CREATE POLICY "Editors can update any post"
  ON public.posts FOR UPDATE
  USING (public.has_role('editor') OR auth.uid() = user_id)
  WITH CHECK (true);

CREATE POLICY "Admins have full access"
  ON public.posts FOR ALL
  USING (public.has_role('admin'));`}
          highlights={[8, 15, 28, 29, 32, 36, 37, 44, 45, 49, 50]}
        />

        <Callout type="warning">
          JWT metadata is set at token creation and cached for the session lifetime. If you change a
          user&apos;s role in the database, it won&apos;t take effect until they re-authenticate. For immediate
          role changes, use Approach 2 (roles table) which checks the database on every query.
        </Callout>
      </SubSection>

      <SubSection id="rls-multi-tenant" title="Pattern 4: Multi-Tenant Isolation">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          For SaaS applications where data is isolated per organization/team. Each row belongs to a
          tenant, and users can only access data within their tenant.
        </p>

        <CodeBlock
          filename="Multi-tenant RLS"
          language="sql"
          code={`-- Organizations table
CREATE TABLE public.organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Membership join table
CREATE TABLE public.org_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('member', 'admin', 'owner')),
  UNIQUE (org_id, user_id)
);

-- Tenant-scoped data table
CREATE TABLE public.projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id)
);

ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.org_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

-- Helper: Is the user a member of this org?
CREATE OR REPLACE FUNCTION public.is_org_member(org UUID)
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.org_members
    WHERE org_id = org AND user_id = auth.uid()
  );
$$;

-- Helper: Is the user an admin of this org?
CREATE OR REPLACE FUNCTION public.is_org_admin(org UUID)
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.org_members
    WHERE org_id = org
      AND user_id = auth.uid()
      AND role IN ('admin', 'owner')
  );
$$;

-- Policies: Members see org data, admins can modify
CREATE POLICY "Members view projects"
  ON public.projects FOR SELECT
  USING (public.is_org_member(org_id));

CREATE POLICY "Members create projects"
  ON public.projects FOR INSERT
  WITH CHECK (public.is_org_member(org_id) AND auth.uid() = created_by);

CREATE POLICY "Admins manage projects"
  ON public.projects FOR UPDATE
  USING (public.is_org_admin(org_id));

CREATE POLICY "Admins delete projects"
  ON public.projects FOR DELETE
  USING (public.is_org_admin(org_id));`}
          highlights={[12, 13, 14, 21, 27, 28, 29, 32, 33, 45, 46, 60, 61, 64, 65, 68, 69]}
        />
      </SubSection>

      <SubSection id="rls-service-role" title="Bypassing RLS (Admin / Service Role)">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Some operations need to bypass RLS entirely — admin panels, cron jobs, webhooks, analytics.
          Use the <InlineCode>service_role</InlineCode> key (server-side only, never expose to clients)
          or <InlineCode>SECURITY DEFINER</InlineCode> functions.
        </p>

        <CodeBlock
          filename="Server-side admin client"
          language="ts"
          code={`// lib/supabase/admin.ts — NEVER import this in client code
import { createClient } from '@supabase/supabase-js'

// The service_role key bypasses ALL RLS policies.
// This key must NEVER be exposed to the browser.
export function createAdminClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,   // Server-only env var
    {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    }
  )
}

// Usage in Server Actions or Route Handlers only:
export async function adminDeleteUser(userId: string) {
  'use server'

  const supabase = createAdminClient()

  // This bypasses RLS — deletes any user regardless of policies
  const { error } = await supabase.auth.admin.deleteUser(userId)
  if (error) throw error

  // Also delete from public tables (CASCADE should handle this)
  await supabase.from('profiles').delete().eq('id', userId)
}`}
          highlights={[1, 4, 5, 9, 12, 13, 24, 26]}
        />

        <Callout type="danger">
          The <InlineCode>SUPABASE_SERVICE_ROLE_KEY</InlineCode> is your database&apos;s master key. It bypasses
          every RLS policy. If this key leaks to the client, your entire database is exposed. Store it
          in server-only environment variables (no <InlineCode>NEXT_PUBLIC_</InlineCode> prefix). Use it
          exclusively in Server Actions, Route Handlers, and server-side scripts.
        </Callout>
      </SubSection>

      <SubSection id="rls-testing" title="Testing RLS Policies">
        <CodeBlock
          filename="Policy testing strategies"
          language="sql"
          code={`-- Test 1: Verify RLS is enabled
SELECT tablename, rowsecurity
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY tablename;

-- Test 2: List all policies on a table
SELECT policyname, cmd, qual, with_check
FROM pg_policies
WHERE tablename = 'posts';

-- Test 3: Simulate a user query
-- Set the JWT claim to mimic a specific user
SET request.jwt.claim.sub = 'user-uuid-here';
SET request.jwt.claims = '{"role": "authenticated", "sub": "user-uuid-here"}';

-- Now SELECT as that user — only matching rows should return
SELECT * FROM public.posts;

-- Test 4: Verify INSERT policy
-- This should FAIL if user_id doesn't match the JWT sub
INSERT INTO public.posts (title, content, user_id)
VALUES ('Test', 'Content', 'different-user-uuid');

-- Test 5: Reset
RESET request.jwt.claim.sub;
RESET request.jwt.claims;`}
          highlights={[2, 3, 8, 9, 14, 15, 18, 22, 23]}
        />
      </SubSection>

      <SubSection id="rls-best-practices" title="RLS Best Practices Checklist">
        <KeyValueGrid items={[
          { key: "1. Enable on every table", value: "ALTER TABLE ... ENABLE ROW LEVEL SECURITY; — No exceptions for tables with user data." },
          { key: "2. Deny by default", value: "RLS with no policies = total lockdown. This is correct. Add policies explicitly for each operation." },
          { key: "3. Always use auth.uid()", value: "Never trust client-sent user IDs. Compare against auth.uid() which is cryptographically verified." },
          { key: "4. WITH CHECK on INSERT", value: "Prevent users from inserting rows with someone else's user_id. Always: WITH CHECK (auth.uid() = user_id)." },
          { key: "5. WITH CHECK on UPDATE", value: "Prevent ownership transfer. Users shouldn't be able to change user_id to someone else's UUID." },
          { key: "6. Indexes on policy columns", value: "RLS checks run on every query. Add indexes on user_id, org_id, and any column used in USING/WITH CHECK." },
          { key: "7. SECURITY DEFINER sparingly", value: "Only for triggers and admin functions. Always SET search_path = public to prevent search_path attacks." },
          { key: "8. Test with multiple users", value: "Create 2-3 test users and verify they can't access each other's data. Automate this in CI." },
          { key: "9. service_role is God mode", value: "Never expose to clients. Use only in server-side code. Treat like your database root password." },
          { key: "10. Combine with app-level checks", value: "RLS is your last line of defense. Also validate in Server Actions and API routes for defense in depth." },
        ]} />

        <Callout type="tip">
          RLS policies that reference <InlineCode>auth.uid()</InlineCode> can use a B-tree index on
          the <InlineCode>user_id</InlineCode> column. Without this index, Postgres does a sequential scan
          on every query — which becomes catastrophic at scale. Always: <InlineCode>CREATE INDEX idx_posts_user_id ON public.posts(user_id);</InlineCode>
        </Callout>
      </SubSection>

      <SubSection id="rls-complete-schema" title="Complete Production Schema">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          A battle-tested schema combining everything: profiles with auto-creation triggers,
          user-owned posts with public/private visibility, comments with nested ownership, and
          proper indexes for RLS performance.
        </p>

        <CodeBlock
          filename="scripts/production_schema.sql"
          language="sql"
          code={`-- ============================================
-- PRODUCTION SCHEMA: Full-Stack App with RLS
-- ============================================

-- 1. PROFILES (auto-created via trigger)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL DEFAULT '',
  avatar_url TEXT,
  bio TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public profiles" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Create own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- 2. POSTS (user-owned, public/draft visibility)
CREATE TABLE IF NOT EXISTS public.posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL CHECK (char_length(title) > 0),
  content TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_posts_user_id ON public.posts(user_id);
CREATE INDEX idx_posts_status ON public.posts(status);

CREATE POLICY "Published posts public" ON public.posts
  FOR SELECT USING (status = 'published');
CREATE POLICY "Own posts visible" ON public.posts
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Create own posts" ON public.posts
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Edit own posts" ON public.posts
  FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Delete own posts" ON public.posts
  FOR DELETE USING (auth.uid() = user_id);

-- 3. COMMENTS (linked to posts and users)
CREATE TABLE IF NOT EXISTS public.comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content TEXT NOT NULL CHECK (char_length(content) > 0),
  created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_comments_post_id ON public.comments(post_id);
CREATE INDEX idx_comments_user_id ON public.comments(user_id);

CREATE POLICY "Comments visible on published posts" ON public.comments
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.posts
      WHERE posts.id = comments.post_id
        AND (posts.status = 'published' OR posts.user_id = auth.uid())
    )
  );
CREATE POLICY "Authenticated users create comments" ON public.comments
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Own comments deletable" ON public.comments
  FOR DELETE USING (auth.uid() = user_id);

-- 4. LIKES (unique per user per post)
CREATE TABLE IF NOT EXISTS public.likes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE (post_id, user_id)
);
ALTER TABLE public.likes ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_likes_post_id ON public.likes(post_id);
CREATE INDEX idx_likes_user_id ON public.likes(user_id);

CREATE POLICY "Likes visible" ON public.likes FOR SELECT USING (true);
CREATE POLICY "Own likes" ON public.likes
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Unlike own" ON public.likes
  FOR DELETE USING (auth.uid() = user_id);

-- 5. AUTO-CREATE PROFILE TRIGGER
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER
SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'display_name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data ->> 'avatar_url', NULL)
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 6. UPDATED_AT AUTO-UPDATE
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER posts_updated_at BEFORE UPDATE ON public.posts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();
CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- 7. ENABLE REALTIME (for live updates)
ALTER PUBLICATION supabase_realtime ADD TABLE public.posts;
ALTER PUBLICATION supabase_realtime ADD TABLE public.comments;
ALTER PUBLICATION supabase_realtime ADD TABLE public.likes;`}
          highlights={[7, 14, 15, 16, 17, 22, 30, 31, 54, 55, 56, 79, 80, 82, 83, 88, 89, 91, 92, 93, 97, 104, 105, 115, 116, 117]}
        />
      </SubSection>
    </section>
  )
}
