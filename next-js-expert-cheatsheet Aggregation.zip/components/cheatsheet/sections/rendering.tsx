import { CodeBlock, InlineCode } from "../code-block"
import { SectionHeader, SubSection, Callout } from "../section-header"

export function RenderingSection() {
  return (
    <section>
      <SectionHeader
        id="rendering"
        title="Rendering"
        description="Server Components, Client Components, and the composition model that eliminates the tradeoffs between performance and interactivity. This is where Next.js fundamentally changes how you think about React."
        badge="CHAPTER 03"
      />

      <SubSection id="server-components" title="Server Components">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Server Components run exclusively on the server. They never ship JavaScript to the client.
          They can directly access databases, filesystems, and server-only APIs. This is the default in the App Router.
        </p>
        <CodeBlock
          filename="app/products/page.tsx"
          language="tsx"
          code={`// Server Component — the default. No directive needed.
// Zero client-side JavaScript for this component.

import { db } from '@/lib/db'
import { ProductCard } from '@/components/product-card'

export default async function ProductsPage() {
  // Direct database access — no API layer needed
  const products = await db.product.findMany({
    where: { published: true },
    include: { category: true },
    orderBy: { createdAt: 'desc' },
  })

  // Access server-only APIs
  const { headers } = await import('next/headers')
  const headersList = await headers()
  const country = headersList.get('x-vercel-ip-country') ?? 'US'

  // Filter by geo
  const localProducts = products.filter(
    p => p.availableIn.includes(country)
  )

  return (
    <section>
      <h1>Products available in {country}</h1>
      <div className="grid grid-cols-3 gap-4">
        {localProducts.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  )
}

// What you CANNOT do in Server Components:
// ✗ useState, useEffect, useRef (no React hooks with state/effects)
// ✗ onClick, onChange (no event handlers)
// ✗ Browser APIs (window, document, localStorage)
// ✗ Custom hooks that use the above
// ✗ React Context (no useContext)

// What you CAN do:
// ✓ async/await
// ✓ Direct database queries
// ✓ File system access (fs)
// ✓ Server-only APIs (headers, cookies)
// ✓ Import server-only packages
// ✓ Render Client Components as children`}
          highlights={[1, 8, 16, 17, 36, 37, 38, 39, 40, 43, 44, 45, 46, 47, 48]}
        />
      </SubSection>

      <SubSection id="client-components" title="Client Components">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Client Components opt into client-side interactivity. They are pre-rendered on the server (SSR)
          and then hydrated on the client. Use them sparingly and push them to the leaves of your component tree.
        </p>
        <CodeBlock
          filename="components/add-to-cart.tsx"
          language="tsx"
          code={`'use client'
// This directive marks the BOUNDARY. Everything imported
// into this file becomes part of the client bundle.

import { useState, useTransition } from 'react'
import { addToCart } from '@/app/actions'

export function AddToCartButton({ productId }: { productId: string }) {
  const [quantity, setQuantity] = useState(1)
  const [isPending, startTransition] = useTransition()

  return (
    <div>
      <select
        value={quantity}
        onChange={(e) => setQuantity(Number(e.target.value))}
      >
        {[1, 2, 3, 4, 5].map(n => (
          <option key={n} value={n}>{n}</option>
        ))}
      </select>

      <button
        disabled={isPending}
        onClick={() => {
          startTransition(async () => {
            await addToCart(productId, quantity)
          })
        }}
      >
        {isPending ? 'Adding...' : 'Add to Cart'}
      </button>
    </div>
  )
}

// 'use client' does NOT mean "client-only rendering."
// It means "this component needs hydration."
// The component is STILL server-rendered (SSR) first,
// then hydrated on the client for interactivity.`}
          highlights={[1, 2, 3, 37, 38, 39, 40]}
        />
        <Callout type="warning">
          <InlineCode>{"'use client'"}</InlineCode> creates a boundary. Every module imported into a Client Component
          also becomes a Client Component. This is why you should keep Client Components small and at the leaves
          of your tree, importing them INTO Server Components rather than the other way around.
        </Callout>
      </SubSection>

      <SubSection id="composition-patterns" title="Composition Patterns">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          The key to high-performance Next.js apps is the composition pattern: Server Components as the data-fetching
          shell, Client Components as interactive islands. Master this pattern.
        </p>
        <CodeBlock
          filename="The Composition Model"
          language="tsx"
          code={`// ✅ CORRECT: Server Component passes data to Client Component
// Server Component (default)
import { getUser } from '@/lib/db'
import { UserProfile } from '@/components/user-profile' // Client Component

export default async function ProfilePage() {
  const user = await getUser()  // Server-side data fetching

  return (
    <div>
      <h1>Profile</h1>
      {/* Pass serializable data to Client Component */}
      <UserProfile user={user} />
    </div>
  )
}

// ✅ CORRECT: Server Component as child of Client Component
// This works because children is a React node, not an import
import { Sidebar } from '@/components/sidebar'  // Client Component
import { NavigationItems } from './nav-items'    // Server Component

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <Sidebar>
      {/* Server Component rendered as children slot */}
      <NavigationItems />
      {children}
    </Sidebar>
  )
}

// ❌ WRONG: Importing Server Component into Client Component
// 'use client'
// import { ServerComponent } from './server-comp' // This becomes client!

// ✅ PATTERN: "Donut" component — client wrapper, server center
// The Client Component creates the interactive shell
// Children (Server Components) fill the center
function InteractiveCard({ children }: { children: React.ReactNode }) {
  'use client'
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div onClick={() => setIsOpen(!isOpen)}>
      {isOpen && children} {/* Server-rendered content */}
    </div>
  )
}`}
          highlights={[1, 18, 19, 33, 36, 37, 38]}
        />
        <Callout type="tip">
          Think of Server Components as the skeleton and Client Components as the muscles. The skeleton
          (data, structure, layout) is rendered on the server. The muscles (interactivity, animations, user input)
          are hydrated on the client. The less muscle you need, the faster your app.
        </Callout>
      </SubSection>

      <SubSection id="streaming" title="Streaming & Suspense">
        <CodeBlock
          filename="Streaming Architecture"
          language="tsx"
          code={`import { Suspense } from 'react'

// Each Suspense boundary creates an independent streaming chunk.
// The shell renders immediately, content streams in as it resolves.

export default function DashboardPage() {
  return (
    <div className="grid grid-cols-2 gap-4">
      {/* These all stream independently and in parallel */}
      <Suspense fallback={<CardSkeleton />}>
        <RevenueChart />     {/* Slow: 2s DB query */}
      </Suspense>

      <Suspense fallback={<CardSkeleton />}>
        <ActiveUsers />      {/* Fast: 200ms cache hit */}
      </Suspense>

      <Suspense fallback={<TableSkeleton />}>
        <RecentOrders />     {/* Medium: 800ms API call */}
      </Suspense>
    </div>
  )
}

// ActiveUsers renders first (200ms)
// RecentOrders streams in next (800ms)
// RevenueChart arrives last (2s)
// User sees progressive content, never a blank page.

// Advanced: Nested Suspense boundaries
async function RevenueChart() {
  const revenue = await getRevenue() // 2s

  return (
    <div>
      <h2>Revenue: \${revenue.total}</h2>
      {/* Nested suspense: chart details stream after header */}
      <Suspense fallback={<ChartSkeleton />}>
        <RevenueBreakdown revenue={revenue} />
      </Suspense>
    </div>
  )
}`}
          highlights={[3, 4, 10, 14, 18, 25, 26, 27, 28, 38]}
        />
        <Callout type="info">
          Streaming is automatic with <InlineCode>loading.tsx</InlineCode>, but <InlineCode>{"<Suspense>"}</InlineCode> gives you fine-grained
          control. Each boundary is an independent streaming unit. Place them strategically around slow data fetches
          to maximize perceived performance. The shell should render in under 100ms.
        </Callout>
      </SubSection>
    </section>
  )
}
