import { CodeBlock, InlineCode } from "../code-block"
import { SectionHeader, SubSection, Callout, KeyValueGrid } from "../section-header"

export function SeoMasterySection() {
  return (
    <section>
      <SectionHeader
        id="seo-mastery"
        title="SEO Mastery"
        description="Every technique to make search engines love your Next.js application. Metadata, structured data, sitemaps, robots, canonical URLs, OG images, JSON-LD, Core Web Vitals, and crawl optimization. Maximum indexability, maximum visibility."
        badge="CHAPTER 15"
      />

      {/* ====== 15.1 THE METADATA API ====== */}
      <SubSection id="seo-metadata-api" title="The Metadata API (Static + Dynamic)">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Next.js has a first-class <InlineCode>Metadata</InlineCode> API that generates the correct{" "}
          <InlineCode>{"<head>"}</InlineCode> tags for every page. Use <InlineCode>export const metadata</InlineCode>{" "}
          for static pages and <InlineCode>generateMetadata()</InlineCode> for dynamic routes.
          Next.js automatically deduplicates and merges metadata from layouts and pages.
        </p>
        <CodeBlock
          filename="app/layout.tsx — Root Metadata (inherited by all pages)"
          language="tsx"
          code={`import type { Metadata } from 'next'

export const metadata: Metadata = {
  // --- Base URL for all relative OG/metadata URLs ---
  metadataBase: new URL('https://yoursite.com'),

  // --- Core Tags ---
  title: {
    default: 'Your Site — Tagline Here',       // Fallback title
    template: '%s | Your Site',                 // Dynamic pages: "Blog | Your Site"
  },
  description: 'The most compelling 155-char description for Google snippets.',

  // --- Crawl Control ---
  robots: {
    index: true,
    follow: true,
    nocache: false,
    googleBot: {
      index: true,
      follow: true,
      noimageindex: false,
      'max-video-preview': -1,           // Unlimited video preview
      'max-image-preview': 'large',      // Full-size image in results
      'max-snippet': -1,                 // Unlimited text snippet
    },
  },

  // --- Open Graph (Facebook, LinkedIn, iMessage, Slack, Discord) ---
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://yoursite.com',
    siteName: 'Your Site',
    title: 'Your Site — Tagline Here',
    description: 'Same or extended description for social cards.',
    images: [
      {
        url: '/og-image.png',            // 1200x630 recommended
        width: 1200,
        height: 630,
        alt: 'Your Site preview image',
      },
    ],
  },

  // --- Twitter Card ---
  twitter: {
    card: 'summary_large_image',
    site: '@yourhandle',
    creator: '@yourhandle',
    title: 'Your Site — Tagline Here',
    description: 'Compelling description for Twitter/X.',
    images: ['/og-image.png'],
  },

  // --- Canonical & Alternates ---
  alternates: {
    canonical: 'https://yoursite.com',
    languages: {
      'en-US': 'https://yoursite.com/en-US',
      'es-ES': 'https://yoursite.com/es-ES',
      'fr-FR': 'https://yoursite.com/fr-FR',
    },
    types: {
      'application/rss+xml': 'https://yoursite.com/feed.xml',
    },
  },

  // --- Verification ---
  verification: {
    google: 'your-google-verification-code',
    yandex: 'your-yandex-verification-code',
    yahoo: 'your-yahoo-verification-code',
    other: {
      'msvalidate.01': 'your-bing-verification-code',
      'facebook-domain-verification': 'your-fb-code',
    },
  },

  // --- Icons ---
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon-16x16.png',
    apple: '/apple-touch-icon.png',
    other: [
      { rel: 'icon', url: '/favicon-32x32.png', sizes: '32x32', type: 'image/png' },
      { rel: 'mask-icon', url: '/safari-pinned-tab.svg', color: '#5bbad5' },
    ],
  },

  // --- App Manifest ---
  manifest: '/site.webmanifest',

  // --- Category ---
  category: 'technology',

  // --- Other ---
  other: {
    'theme-color': '#0f1117',
    'color-scheme': 'dark',
    'apple-mobile-web-app-capable': 'yes',
    'apple-mobile-web-app-status-bar-style': 'black-translucent',
  },
}`}
          highlights={[4, 8, 9, 10, 11, 14, 15, 16, 22, 23, 24, 31, 32, 53, 54, 57, 58, 70, 71, 72, 73]}
        />
        <Callout type="tip" title="The Title Template Pattern">
          Set <InlineCode>{"title.template"}</InlineCode> in your root layout and then each page just exports{" "}
          <InlineCode>{"title: 'Blog'"}</InlineCode>. Next.js auto-generates{" "}
          <InlineCode>{"<title>Blog | Your Site</title>"}</InlineCode>. Never hardcode the full title on every page.
        </Callout>
      </SubSection>

      {/* ====== 15.2 DYNAMIC METADATA ====== */}
      <SubSection id="seo-dynamic-metadata" title="Dynamic Metadata with generateMetadata()">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          For dynamic routes (<InlineCode>/blog/[slug]</InlineCode>, <InlineCode>/products/[id]</InlineCode>), use{" "}
          <InlineCode>generateMetadata()</InlineCode>. Next.js <strong>deduplicates</strong> fetch requests
          between <InlineCode>generateMetadata</InlineCode> and the page component automatically via{" "}
          <InlineCode>React.cache()</InlineCode>.
        </p>
        <CodeBlock
          filename="app/blog/[slug]/page.tsx"
          language="tsx"
          code={`import type { Metadata } from 'next'
import { notFound } from 'next/navigation'

interface Props {
  params: { slug: string }
}

// The page component — fetch is deduplicated with generateMetadata
export default async function BlogPost({ params }: Props) {
  const { slug } = params
  const post = await getPost(slug) // Same fetch, cached by React.cache()

  if (!post) notFound()

  return <article>{/* render post */}</article>
}`}
          highlights={[9, 10, 11, 16, 21, 24, 25, 40, 41, 48, 49, 53, 54]}
        />
        <Callout type="info">
          <InlineCode>generateMetadata</InlineCode> runs on the server and the result is streamed to the client
          as <InlineCode>{"<head>"}</InlineCode> tags. The page will <strong>not</strong> render until metadata is resolved.
          Never use <InlineCode>{"'use client'"}</InlineCode> in a file that exports metadata.
        </Callout>
      </SubSection>

      {/* ====== 15.3 STRUCTURED DATA / JSON-LD ====== */}
      <SubSection id="seo-json-ld" title="Structured Data (JSON-LD)">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          JSON-LD tells Google <em>what</em> your content is, enabling rich results: FAQ accordions,
          breadcrumbs, star ratings, product cards, how-to carousels, and more. Place a{" "}
          <InlineCode>{"<script type=\"application/ld+json\">"}</InlineCode> in your page body (not head).
        </p>
        <CodeBlock
          filename="components/json-ld.tsx — Reusable JSON-LD Component"
          language="tsx"
          code={`// Type-safe JSON-LD injection component
export function JsonLd<T extends Record<string, unknown>>({ data }: { data: T }) {
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  )
}`}
          highlights={[2, 5, 6]}
        />
        <CodeBlock
          filename="app/page.tsx — Organization + WebSite Schema"
          language="tsx"
          code={`import { JsonLd } from '@/components/json-ld'

export default function Home() {
  return (
    <>
      {/* Organization Schema — tells Google who you are */}
      <JsonLd data={{
        '@context': 'https://schema.org',
        '@type': 'Organization',
        name: 'Your Company',
        url: 'https://yoursite.com',
        logo: 'https://yoursite.com/logo.png',
        sameAs: [
          'https://twitter.com/yourhandle',
          'https://github.com/yourorg',
          'https://linkedin.com/company/yourco',
        ],
        contactPoint: {
          '@type': 'ContactPoint',
          email: 'support@yoursite.com',
          contactType: 'customer support',
        },
      }} />

      {/* WebSite Schema — enables Google Sitelinks Search Box */}
      <JsonLd data={{
        '@context': 'https://schema.org',
        '@type': 'WebSite',
        name: 'Your Site',
        url: 'https://yoursite.com',
        potentialAction: {
          '@type': 'SearchAction',
          target: {
            '@type': 'EntryPoint',
            urlTemplate: 'https://yoursite.com/search?q={search_term_string}',
          },
          'query-input': 'required name=search_term_string',
        },
      }} />

      <main>{/* Page content */}</main>
    </>
  )
}`}
          highlights={[7, 8, 9, 25, 26, 27, 31, 32, 33, 34]}
        />
        <CodeBlock
          filename="app/blog/[slug]/page.tsx — Article Schema"
          language="tsx"
          code={`import { JsonLd } from '@/components/json-ld'

interface Props {
  params: { slug: string }
}

export default async function BlogPost({ params }: Props) {
  const { slug } = params
  const post = await getPost(slug)
  if (!post) notFound()

  return (
    <>
      <JsonLd data={{
        '@context': 'https://schema.org',
        '@type': 'Article',
        headline: post.title,
        description: post.excerpt,
        image: post.ogImage,
        datePublished: post.publishedAt,
        dateModified: post.updatedAt,
        author: {
          '@type': 'Person',
          name: post.author.name,
          url: post.author.url,
        },
        publisher: {
          '@type': 'Organization',
          name: 'Your Site',
          logo: {
            '@type': 'ImageObject',
            url: 'https://yoursite.com/logo.png',
          },
        },
        mainEntityOfPage: {
          '@type': 'WebPage',
          '@id': \`https://yoursite.com/blog/\${slug}\`,
        },
      }} />
      <article>{/* render */}</article>
    </>
  )
}`}
          highlights={[10, 11, 12, 13, 14, 15, 16, 17, 18, 19]}
        />
        <Callout type="tip" title="Maximum Rich Results">
          Combine multiple schemas on a single page. A product page can have{" "}
          <InlineCode>Product</InlineCode>, <InlineCode>BreadcrumbList</InlineCode>,{" "}
          <InlineCode>FAQPage</InlineCode>, and <InlineCode>AggregateRating</InlineCode>{" "}
          schemas simultaneously. Google merges them all.
        </Callout>
      </SubSection>

      {/* ====== 15.4 FAQ SCHEMA ====== */}
      <SubSection id="seo-faq-schema" title="FAQ Schema (Rich Accordion in Google)">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          FAQ schema gives you expandable Q&A dropdowns directly in Google search results.
          This can double or triple your SERP real estate. Place the schema alongside
          visible FAQ content on your page.
        </p>
        <CodeBlock
          filename="components/faq-section.tsx"
          language="tsx"
          code={`import { JsonLd } from '@/components/json-ld'

interface FAQ {
  question: string
  answer: string
}

export function FAQSection({ faqs }: { faqs: FAQ[] }) {
  return (
    <>
      {/* JSON-LD for Google rich results */}
      <JsonLd data={{
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: faqs.map(faq => ({
          '@type': 'Question',
          name: faq.question,
          acceptedAnswer: {
            '@type': 'Answer',
            text: faq.answer,
          },
        })),
      }} />

      {/* Visible FAQ — Google requires the content to be visible on the page */}
      <section aria-labelledby="faq-heading">
        <h2 id="faq-heading" className="text-2xl font-bold">
          Frequently Asked Questions
        </h2>
        <dl className="mt-6 space-y-4">
          {faqs.map((faq) => (
            <details key={faq.question} className="group border-b pb-4">
              <summary className="cursor-pointer font-medium list-none flex justify-between">
                <dt>{faq.question}</dt>
                <span className="group-open:rotate-180 transition-transform">
                  &#9660;
                </span>
              </summary>
              <dd className="mt-2 text-muted-foreground">{faq.answer}</dd>
            </details>
          ))}
        </dl>
      </section>
    </>
  )
}

// Usage:
// <FAQSection faqs={[
//   { question: 'What is Next.js?', answer: 'A React framework for production...' },
//   { question: 'Is Next.js free?', answer: 'Yes, Next.js is open source...' },
// ]} />`}
          highlights={[12, 13, 14, 15, 16, 17, 25, 26, 32]}
        />
        <Callout type="warning">
          Google requires FAQ content to be <strong>visible</strong> on the page (not hidden by CSS).
          Using <InlineCode>{"<details>"}</InlineCode> elements is fine because the content is accessible.
          But <InlineCode>display: none</InlineCode> or <InlineCode>visibility: hidden</InlineCode> will disqualify it.
        </Callout>
      </SubSection>

      {/* ====== 15.5 BREADCRUMB SCHEMA ====== */}
      <SubSection id="seo-breadcrumbs" title="Breadcrumb Schema + Component">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Breadcrumbs improve navigation and give Google a clear hierarchy of your site structure.
          With JSON-LD, Google renders clickable breadcrumb trails in search results.
        </p>
        <CodeBlock
          filename="components/breadcrumbs.tsx"
          language="tsx"
          code={`import Link from 'next/link'
import { JsonLd } from '@/components/json-ld'

interface Crumb {
  label: string
  href: string
}

export function Breadcrumbs({ crumbs }: { crumbs: Crumb[] }) {
  return (
    <>
      <JsonLd data={{
        '@context': 'https://schema.org',
        '@type': 'BreadcrumbList',
        itemListElement: crumbs.map((crumb, i) => ({
          '@type': 'ListItem',
          position: i + 1,
          name: crumb.label,
          item: \`https://yoursite.com\${crumb.href}\`,
        })),
      }} />

      <nav aria-label="Breadcrumb" className="text-sm text-muted-foreground">
        <ol className="flex items-center gap-1.5">
          {crumbs.map((crumb, i) => (
            <li key={crumb.href} className="flex items-center gap-1.5">
              {i > 0 && <span aria-hidden="true">/</span>}
              {i === crumbs.length - 1 ? (
                <span aria-current="page" className="text-foreground font-medium">
                  {crumb.label}
                </span>
              ) : (
                <Link href={crumb.href} className="hover:text-foreground transition-colors">
                  {crumb.label}
                </Link>
              )}
            </li>
          ))}
        </ol>
      </nav>
    </>
  )
}

// Usage in any page:
// <Breadcrumbs crumbs={[
//   { label: 'Home', href: '/' },
//   { label: 'Blog', href: '/blog' },
//   { label: 'How to Master SEO', href: '/blog/seo-mastery' },
// ]} />`}
          highlights={[12, 13, 14, 15, 16, 23, 29, 30]}
        />
      </SubSection>

      {/* ====== 15.6 SITEMAP ====== */}
      <SubSection id="seo-sitemap" title="Sitemap Generation">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          A sitemap tells search engines about every page on your site, their priority, and how often
          they change. Next.js supports both static and dynamic sitemaps using the{" "}
          <InlineCode>sitemap.ts</InlineCode> file convention.
        </p>
        <CodeBlock
          filename="app/sitemap.ts — Dynamic Sitemap"
          language="tsx"
          code={`import type { MetadataRoute } from 'next'

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = 'https://yoursite.com'

  // Static pages
  const staticPages: MetadataRoute.Sitemap = [
    {
      url: baseUrl,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 1.0,
    },
    {
      url: \`\${baseUrl}/about\`,
      lastModified: new Date(),
      changeFrequency: 'monthly',
      priority: 0.8,
    },
    {
      url: \`\${baseUrl}/blog\`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.9,
    },
    {
      url: \`\${baseUrl}/pricing\`,
      lastModified: new Date(),
      changeFrequency: 'weekly',
      priority: 0.8,
    },
  ]

  // Dynamic pages — fetch all slugs from your CMS/database
  const posts = await getAllPosts()
  const postPages: MetadataRoute.Sitemap = posts.map((post) => ({
    url: \`\${baseUrl}/blog/\${post.slug}\`,
    lastModified: new Date(post.updatedAt),
    changeFrequency: 'weekly' as const,
    priority: 0.7,
  }))

  const products = await getAllProducts()
  const productPages: MetadataRoute.Sitemap = products.map((p) => ({
    url: \`\${baseUrl}/products/\${p.slug}\`,
    lastModified: new Date(p.updatedAt),
    changeFrequency: 'daily' as const,
    priority: 0.8,
  }))

  return [...staticPages, ...postPages, ...productPages]
}`}
          highlights={[3, 10, 11, 12, 22, 23, 35, 36, 37, 38, 39, 40]}
        />
        <CodeBlock
          filename="Large Sites — Sitemap Index (50,000+ URLs)"
          language="tsx"
          code={`// app/sitemap.ts — returns a sitemap index
import type { MetadataRoute } from 'next'

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    { url: 'https://yoursite.com/sitemaps/static.xml', lastModified: new Date() },
    { url: 'https://yoursite.com/sitemaps/blog.xml', lastModified: new Date() },
    { url: 'https://yoursite.com/sitemaps/products.xml', lastModified: new Date() },
  ]
}

// For truly large sites (100k+ pages), generate multiple sitemaps
// using generateSitemaps():
export async function generateSitemaps() {
  const totalProducts = await getProductCount()
  const sitemapCount = Math.ceil(totalProducts / 50000)

  return Array.from({ length: sitemapCount }, (_, i) => ({ id: i }))
}

// Each sitemap is then accessible at /sitemap/[id].xml`}
          highlights={[14, 15, 16, 18]}
        />
        <Callout type="tip">
          Submit your sitemap to Google Search Console, Bing Webmaster Tools, and Yandex Webmaster.
          Also reference it in your <InlineCode>robots.txt</InlineCode>:{" "}
          <InlineCode>{"Sitemap: https://yoursite.com/sitemap.xml"}</InlineCode>
        </Callout>
      </SubSection>

      {/* ====== 15.7 ROBOTS.TXT ====== */}
      <SubSection id="seo-robots" title="robots.txt Configuration">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Use the <InlineCode>robots.ts</InlineCode> file convention to control which pages crawlers
          can access. This prevents indexing of admin panels, API routes, and internal pages.
        </p>
        <CodeBlock
          filename="app/robots.ts"
          language="tsx"
          code={`import type { MetadataRoute } from 'next'

export default function robots(): MetadataRoute.Robots {
  const baseUrl = 'https://yoursite.com'

  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: [
          '/api/',           // Never index API routes
          '/admin/',         // Admin panel
          '/dashboard/',     // Authenticated pages
          '/auth/',          // Login/signup pages
          '/_next/',         // Next.js internals
          '/private/',       // Private content
        ],
      },
      {
        // Block AI training crawlers (optional)
        userAgent: ['GPTBot', 'ChatGPT-User', 'CCBot', 'anthropic-ai'],
        disallow: ['/'],
      },
      {
        // Allow Google specific crawlers full access
        userAgent: 'Googlebot',
        allow: '/',
        disallow: ['/api/', '/admin/'],
      },
    ],
    sitemap: \`\${baseUrl}/sitemap.xml\`,
    host: baseUrl,
  }
}`}
          highlights={[10, 11, 12, 13, 14, 15, 21, 22, 23, 31, 32]}
        />
        <KeyValueGrid
          items={[
            { key: "User-agent: *", value: "Rules for all crawlers. The baseline." },
            { key: "Disallow: /api/", value: "Never let bots index your API endpoints." },
            { key: "Disallow: /admin/", value: "Hide authenticated/internal pages from search." },
            { key: "GPTBot", value: "OpenAI's crawler. Block if you don't want AI training on your content." },
            { key: "Sitemap:", value: "Always include. Helps crawlers discover all your pages faster." },
          ]}
        />
      </SubSection>

      {/* ====== 15.8 OG IMAGE GENERATION ====== */}
      <SubSection id="seo-og-images" title="Dynamic OG Image Generation">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Next.js can generate Open Graph images on-the-fly using the <InlineCode>ImageResponse</InlineCode> API.
          Create unique, branded preview images for every page without maintaining thousands of static images.
        </p>
        <CodeBlock
          filename="app/blog/[slug]/opengraph-image.tsx"
          language="tsx"
          code={`import { ImageResponse } from 'next/og'

export const runtime = 'edge'
export const alt = 'Blog post preview'
export const size = { width: 1200, height: 630 }
export const contentType = 'image/png'

export default async function Image({
  params,
}: {
  params: { slug: string }
}) {
  const { slug } = params
  const post = await getPost(slug)

  return new ImageResponse(
    (
      <div
        style={{
          height: '100%',
          width: '100%',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          padding: '60px',
          background: 'linear-gradient(135deg, #0f1117 0%, #1a1b23 100%)',
          color: 'white',
          fontFamily: 'Inter',
        }}
      >
        {/* Site badge */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '24px' }}>
          <div style={{
            width: '32px', height: '32px', borderRadius: '6px',
            background: '#3b82f6', display: 'flex', alignItems: 'center',
            justifyContent: 'center', fontSize: '14px', fontWeight: 700,
          }}>N</div>
          <span style={{ fontSize: '14px', opacity: 0.6, letterSpacing: '0.1em' }}>
            YOURSITE.COM
          </span>
        </div>

        {/* Title */}
        <h1 style={{
          fontSize: '48px',
          fontWeight: 800,
          lineHeight: 1.2,
          maxWidth: '800px',
          margin: 0,
        }}>
          {post?.title ?? 'Blog Post'}
        </h1>

        {/* Author + Date */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: '12px',
          marginTop: '24px', fontSize: '18px', opacity: 0.7,
        }}>
          <span>{post?.author?.name}</span>
          <span>·</span>
          <span>{new Date(post?.publishedAt ?? Date.now()).toLocaleDateString()}</span>
        </div>
      </div>
    ),
    { ...size }
  )
}`}
          highlights={[3, 4, 5, 6, 8, 16, 26, 43, 44, 45]}
        />
        <Callout type="tip" title="File Convention = Zero Config">
          Name the file <InlineCode>opengraph-image.tsx</InlineCode> or{" "}
          <InlineCode>twitter-image.tsx</InlineCode> inside any route folder. Next.js automatically
          sets the correct <InlineCode>{"<meta property=\"og:image\">"}</InlineCode> tag.
          No need to manually add it in your metadata object.
        </Callout>
      </SubSection>

      {/* ====== 15.9 CANONICAL URLs ====== */}
      <SubSection id="seo-canonical" title="Canonical URLs & Duplicate Content">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Canonicals tell search engines which version of a URL is the &quot;true&quot; one. This prevents
          duplicate content penalties from query params, trailing slashes, HTTP vs HTTPS, and www vs non-www.
        </p>
        <CodeBlock
          filename="Per-page canonical configuration"
          language="tsx"
          code={`// --- Static page canonical ---
export const metadata: Metadata = {
  alternates: {
    canonical: 'https://yoursite.com/pricing',
  },
}

// --- Trailing slash normalization (next.config.mjs) ---
// trailingSlash: false   // /about (not /about/)
// This ensures Google treats them as the same URL.

// --- Force HTTPS + www redirect (middleware.ts) ---
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export function middleware(request: NextRequest) {
  const url = request.nextUrl.clone()

  // Redirect HTTP to HTTPS
  if (url.protocol === 'http:') {
    url.protocol = 'https:'
    return NextResponse.redirect(url, 301)
  }

  // Redirect www to non-www (or vice versa)
  if (url.hostname.startsWith('www.')) {
    url.hostname = url.hostname.replace('www.', '')
    return NextResponse.redirect(url, 301)
  }

  return NextResponse.next()
}`}
          highlights={[3, 4, 12, 13, 30, 31, 36, 37]}
        />
        <Callout type="danger">
          Never have the same content accessible at multiple URLs without a canonical.
          Google treats <InlineCode>/blog/seo</InlineCode>, <InlineCode>/blog/seo/</InlineCode>,{" "}
          <InlineCode>/blog/seo?ref=twitter</InlineCode> as <strong>three separate pages</strong> without canonicals.
        </Callout>
      </SubSection>

      {/* ====== 15.10 GENERATESTATICPARAMS ====== */}
      <SubSection id="seo-static-params" title="generateStaticParams for Pre-Rendering">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Pre-render all important dynamic pages at build time for instant loading and maximum
          crawlability. Search engines love static HTML.
        </p>
        <CodeBlock
          filename="app/blog/[slug]/page.tsx"
          language="tsx"
          code={`// Pre-render all blog posts at build time
export async function generateStaticParams() {
  const posts = await getAllPosts()

  return posts.map((post) => ({
    slug: post.slug,
  }))
}

// Combined with dynamic metadata + JSON-LD, each pre-rendered page has:
// 1. Full HTML content (instant load, perfect for crawlers)
// 2. Complete <head> tags (title, description, OG, Twitter)
// 3. Structured data (JSON-LD article schema)
// 4. Canonical URL
// 5. Breadcrumbs schema
// = MAXIMUM search engine visibility

// Control behavior for params NOT in generateStaticParams:
export const dynamicParams = true  // true = render on-demand (ISR)
                                   // false = return 404`}
          highlights={[2, 5, 6, 18, 19]}
        />
      </SubSection>

      {/* ====== 15.11 CORE WEB VITALS ====== */}
      <SubSection id="seo-core-web-vitals" title="Core Web Vitals SEO Checklist">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Google uses Core Web Vitals as a ranking signal. Next.js gives you the tools to ace every metric.
          Here is the complete optimization playbook.
        </p>
        <KeyValueGrid
          items={[
            { key: "LCP < 2.5s", value: "Largest Contentful Paint. Use priority on hero images, preload fonts, avoid layout shifts. Server Components + streaming help dramatically." },
            { key: "INP < 200ms", value: "Interaction to Next Paint. Keep client JS minimal. Use Server Components by default. Lazy-load heavy interactive widgets with next/dynamic." },
            { key: "CLS < 0.1", value: "Cumulative Layout Shift. Always set width/height on images. Use font display: swap. Reserve space for dynamic content with min-height." },
            { key: "FCP < 1.8s", value: "First Contentful Paint. Use streaming + Suspense to show content progressively. Avoid blocking renders on slow data fetches." },
            { key: "TTFB < 800ms", value: "Time to First Byte. Use edge runtime for global performance. Cache aggressively with ISR. Use CDN for static assets." },
          ]}
        />
        <CodeBlock
          filename="Performance-first component patterns"
          language="tsx"
          code={`// 1. Server Components by default = zero client JS
export default async function Page() {
  const data = await getData() // No useEffect, no loading state
  return <div>{/* Rendered HTML, zero JS shipped */}</div>
}

// 2. Streaming heavy content
import { Suspense } from 'react'

export default function Page() {
  return (
    <main>
      <h1>Instant header</h1>  {/* Streams immediately */}
      <Suspense fallback={<CommentsSkeleton />}>
        <Comments />              {/* Streams when ready */}
      </Suspense>
    </main>
  )
}

// 3. Preload critical resources
import { preload } from 'react-dom'

export default function Layout({ children }: { children: React.ReactNode }) {
  preload('/fonts/Inter-Bold.woff2', { as: 'font', type: 'font/woff2', crossOrigin: 'anonymous' })
  preload('/hero-image.webp', { as: 'image' })
  return <>{children}</>
}

// 4. Prevent CLS with explicit dimensions
import Image from 'next/image'

function Hero() {
  return (
    <Image
      src="/hero.webp"
      alt="Hero"
      width={1200}
      height={600}
      priority        // Preload = faster LCP
      sizes="100vw"
    />
  )
}

// 5. Lazy-load below-the-fold content
import dynamic from 'next/dynamic'

const HeavyChart = dynamic(() => import('@/components/chart'), {
  loading: () => <div className="h-96 animate-pulse bg-muted rounded" />,
  ssr: false,
})`}
          highlights={[2, 13, 14, 15, 24, 25, 35, 36, 37, 38, 46, 47, 48]}
        />
      </SubSection>

      {/* ====== 15.12 SEMANTIC HTML ====== */}
      <SubSection id="seo-semantic-html" title="Semantic HTML for SEO">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Search engines understand the <em>structure</em> of your page through semantic HTML.
          Proper heading hierarchy, landmarks, and ARIA attributes improve both SEO and accessibility.
        </p>
        <CodeBlock
          filename="Semantic page structure"
          language="html"
          code={`<!-- CORRECT heading hierarchy — ONE h1 per page -->
<main>
  <article>
    <header>
      <h1>The Complete Guide to Next.js SEO</h1>  <!-- ONE h1 per page -->
      <p>Published on <time datetime="2026-01-15">January 15, 2026</time></p>
    </header>

    <nav aria-label="Table of contents">
      <ol>
        <li><a href="#metadata">Metadata API</a></li>
        <li><a href="#structured-data">Structured Data</a></li>
      </ol>
    </nav>

    <section id="metadata" aria-labelledby="metadata-heading">
      <h2 id="metadata-heading">Metadata API</h2>    <!-- h2 under h1 -->
      <p>Content here...</p>

      <h3>Static Metadata</h3>                        <!-- h3 under h2 -->
      <p>More content...</p>
    </section>

    <section id="structured-data" aria-labelledby="sd-heading">
      <h2 id="sd-heading">Structured Data</h2>
      <p>Content...</p>
    </section>

    <footer>
      <p>Written by <address><a href="/author/john">John Doe</a></address></p>
    </footer>
  </article>

  <aside aria-label="Related posts">
    <h2>Related Articles</h2>
    <!-- Sidebar content -->
  </aside>
</main>`}
          highlights={[2, 3, 5, 6, 9, 16, 17, 20, 24, 29, 33]}
        />
        <KeyValueGrid
          items={[
            { key: "<main>", value: "One per page. The primary content area. Crawlers prioritize content inside <main>." },
            { key: "<article>", value: "Self-contained content (blog posts, news articles). Can be independently distributed." },
            { key: "<section>", value: "Thematic grouping with a heading. Use aria-labelledby to link to its heading." },
            { key: "<nav>", value: "Navigation blocks. Use aria-label to distinguish multiple <nav> elements." },
            { key: "<time>", value: "Machine-readable dates. Always include the datetime attribute for search engines." },
            { key: "<address>", value: "Contact information for the author. Used by Google for author attribution." },
          ]}
        />
      </SubSection>

      {/* ====== 15.13 INTERNATIONAL SEO ====== */}
      <SubSection id="seo-international" title="International SEO (hreflang)">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Tell search engines which language and region each page targets. This prevents duplicate
          content issues across localized versions and ensures users find the right language.
        </p>
        <CodeBlock
          filename="app/[locale]/layout.tsx — Locale-aware metadata"
          language="tsx"
          code={`import type { Metadata } from 'next'

const locales = ['en', 'es', 'fr', 'de', 'ja'] as const

export async function generateMetadata({
  params,
}: {
  params: { locale: string }
}): Promise<Metadata> {
  const { locale } = params

  return {
    alternates: {
      canonical: \`https://yoursite.com/\${locale}\`,
      languages: Object.fromEntries(
        locales.map((l) => [l, \`https://yoursite.com/\${l}\`])
      ),
    },
  }
}

// This generates:
// <link rel="alternate" hreflang="en" href="https://yoursite.com/en" />
// <link rel="alternate" hreflang="es" href="https://yoursite.com/es" />
// <link rel="alternate" hreflang="fr" href="https://yoursite.com/fr" />
// <link rel="alternate" hreflang="de" href="https://yoursite.com/de" />
// <link rel="alternate" hreflang="ja" href="https://yoursite.com/ja" />

// Also add x-default for language selection pages:
// <link rel="alternate" hreflang="x-default" href="https://yoursite.com" />`}
          highlights={[13, 14, 15, 16, 17]}
        />
      </SubSection>

      {/* ====== 15.14 RSS FEED ====== */}
      <SubSection id="seo-rss-feed" title="RSS Feed Generation">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          RSS feeds make your content discoverable by feed readers, aggregators, and some search engines.
          Generate them dynamically via a Route Handler.
        </p>
        <CodeBlock
          filename="app/feed.xml/route.ts"
          language="tsx"
          code={`export async function GET() {
  const posts = await getAllPosts()
  const baseUrl = 'https://yoursite.com'

  const rss = \`<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>Your Site Blog</title>
    <link>\${baseUrl}</link>
    <description>Latest articles from Your Site</description>
    <language>en-us</language>
    <lastBuildDate>\${new Date().toUTCString()}</lastBuildDate>
    <atom:link href="\${baseUrl}/feed.xml" rel="self" type="application/rss+xml"/>
    \${posts.map(post => \`
    <item>
      <title><![CDATA[\${post.title}]]></title>
      <link>\${baseUrl}/blog/\${post.slug}</link>
      <guid isPermaLink="true">\${baseUrl}/blog/\${post.slug}</guid>
      <description><![CDATA[\${post.excerpt}]]></description>
      <pubDate>\${new Date(post.publishedAt).toUTCString()}</pubDate>
      <author>\${post.author.email} (\${post.author.name})</author>
    </item>\`).join('')}
  </channel>
</rss>\`

  return new Response(rss.trim(), {
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'public, max-age=3600, s-maxage=3600',
    },
  })
}`}
          highlights={[1, 5, 6, 13, 25, 26, 27, 28]}
        />
      </SubSection>

      {/* ====== 15.15 SEO AUDIT CHECKLIST ====== */}
      <SubSection id="seo-checklist" title="The Ultimate SEO Audit Checklist">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Run through this before every deployment. Every item directly impacts search rankings.
        </p>
        <div className="my-4 grid gap-3">
          {[
            { category: "Metadata", items: [
              "Every page has a unique <title> (50-60 chars)",
              "Every page has a unique <meta description> (150-160 chars)",
              "Title template is set in root layout",
              "metadataBase is set to your production URL",
              "All pages have canonical URLs",
              "hreflang tags for multi-language sites",
            ]},
            { category: "Social Cards", items: [
              "Every page has og:title, og:description, og:image",
              "OG images are 1200x630px",
              "Twitter card type is set (summary_large_image)",
              "Dynamic OG images for blog/product pages",
              "Test with Facebook Sharing Debugger + Twitter Card Validator",
            ]},
            { category: "Structured Data", items: [
              "Organization schema on homepage",
              "WebSite schema with SearchAction",
              "Article schema on blog posts",
              "BreadcrumbList on all pages",
              "FAQPage schema where applicable",
              "Product schema on product pages",
              "Validate with Google Rich Results Test",
            ]},
            { category: "Crawlability", items: [
              "sitemap.xml is generated and submitted",
              "robots.txt allows important pages, blocks /api/ and /admin/",
              "No orphan pages (every page is linked from another)",
              "Internal linking strategy is implemented",
              "301 redirects for old/moved URLs",
              "Custom 404 page with navigation back to site",
            ]},
            { category: "Performance (CWV)", items: [
              "LCP < 2.5s (hero image has priority)",
              "INP < 200ms (minimal client JS)",
              "CLS < 0.1 (all images have dimensions)",
              "Fonts use display: swap and are self-hosted",
              "Heavy components use next/dynamic",
              "Streaming with Suspense for slow data",
            ]},
            { category: "Content", items: [
              "One <h1> per page",
              "Heading hierarchy is correct (h1 > h2 > h3)",
              "Images have descriptive alt text",
              "Internal links use <Link> (not <a>)",
              "All links have descriptive anchor text",
              "<time> elements have datetime attributes",
            ]},
          ].map((group) => (
            <div key={group.category} className="rounded-lg border border-border bg-card overflow-hidden">
              <div className="px-4 py-2.5 bg-secondary/50 border-b border-border">
                <h4 className="text-sm font-semibold text-foreground">{group.category}</h4>
              </div>
              <ul className="p-4 space-y-2">
                {group.items.map((item) => (
                  <li key={item} className="flex items-start gap-2.5 text-sm text-muted-foreground">
                    <span className="mt-1 h-4 w-4 shrink-0 rounded border border-border bg-secondary/30" />
                    <span className="leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </SubSection>

      {/* ====== 15.16 COMMON MISTAKES ====== */}
      <SubSection id="seo-mistakes" title="SEO Mistakes That Kill Rankings">
        <div className="my-4 space-y-3">
          {[
            {
              bad: "Using 'use client' on pages that export metadata",
              fix: "Metadata only works in Server Components. Never mix 'use client' with metadata exports.",
            },
            {
              bad: "Client-side rendering for content pages",
              fix: "Google can render JS but deprioritizes it. Use Server Components for content that must be indexed.",
            },
            {
              bad: "Forgetting metadataBase",
              fix: "Without metadataBase, relative OG image URLs won't resolve. Set it in your root layout.",
            },
            {
              bad: "Same title/description on every page",
              fix: "Each page needs unique metadata. Use generateMetadata() for dynamic routes.",
            },
            {
              bad: "Not setting image dimensions",
              fix: "Missing width/height causes CLS. Always use the Next.js Image component with explicit dimensions.",
            },
            {
              bad: "Blocking crawlers from CSS/JS",
              fix: "Google needs CSS/JS to render your page. Never disallow /_next/ static assets in robots.txt.",
            },
            {
              bad: "No internal linking strategy",
              fix: "Orphan pages won't get crawled. Link every page from at least 2-3 other pages.",
            },
            {
              bad: "Using onClick for navigation",
              fix: "Search engines can't follow onClick handlers. Always use <Link href='...'> for navigation.",
            },
          ].map((mistake) => (
            <div key={mistake.bad} className="rounded-lg border border-destructive/20 bg-destructive/5 p-4">
              <p className="text-sm font-medium text-destructive mb-1">{mistake.bad}</p>
              <p className="text-sm text-foreground/70 leading-relaxed">{mistake.fix}</p>
            </div>
          ))}
        </div>
      </SubSection>

      {/* ====== 15.17 SEO UTILITIES ====== */}
      <SubSection id="seo-utilities" title="Production SEO Utilities">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Copy-paste these utility functions into your codebase for production-grade SEO.
        </p>
        <CodeBlock
          filename="lib/seo.ts — SEO helper utilities"
          language="tsx"
          code={`import type { Metadata } from 'next'

const BASE_URL = 'https://yoursite.com'
const SITE_NAME = 'Your Site'

// Construct consistent metadata for any page
export function constructMetadata({
  title,
  description,
  image = '/og-image.png',
  path = '/',
  type = 'website',
  publishedTime,
  modifiedTime,
  authors,
  tags,
}: {
  title: string
  description: string
  image?: string
  path?: string
  type?: 'website' | 'article'
  publishedTime?: string
  modifiedTime?: string
  authors?: string[]
  tags?: string[]
}): Metadata {
  const url = \`\${BASE_URL}\${path}\`
  const imageUrl = image.startsWith('http') ? image : \`\${BASE_URL}\${image}\`

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      url,
      siteName: SITE_NAME,
      type,
      ...(publishedTime && { publishedTime }),
      ...(modifiedTime && { modifiedTime }),
      ...(authors && { authors }),
      ...(tags && { tags }),
      images: [{ url: imageUrl, width: 1200, height: 630, alt: title }],
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
      images: [imageUrl],
    },
    alternates: {
      canonical: url,
    },
  }
}

// Usage in any page:
// export const metadata = constructMetadata({
//   title: 'Pricing',
//   description: 'Simple, transparent pricing.',
//   path: '/pricing',
// })

// Truncate text to SEO-safe length
export function seoTruncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text
  return text.slice(0, maxLength - 3).trimEnd() + '...'
}

// Generate absolute URL from path
export function absoluteUrl(path: string): string {
  return \`\${BASE_URL}\${path.startsWith('/') ? path : '/\' + path}\`
}

// Strip HTML for meta descriptions
export function stripHtml(html: string): string {
  return html.replace(/<[^>]*>/g, '').replace(/\\s+/g, ' ').trim()
}`}
          highlights={[7, 8, 9, 10, 11, 27, 28, 30, 31, 32, 33, 34, 64, 65, 66, 70]}
        />
        <Callout type="tip" title="One Function to Rule Them All">
          Use <InlineCode>constructMetadata()</InlineCode> across your entire codebase.
          It enforces consistent OG images, canonical URLs, and Twitter cards on every single page.
          Never manually build metadata objects again.
        </Callout>
      </SubSection>
    </section>
  )
}

async function getPost(slug: string) {
  // Mock implementation
  return {
    title: 'Blog Post Title',
    excerpt: 'Blog post excerpt.',
    ogImage: '/og-image.png',
    publishedAt: '2023-01-01',
    updatedAt: '2023-01-02',
    author: {
      name: 'John Doe',
      url: '/author/john',
    },
    tags: ['tag1', 'tag2'],
  }
}

async function getAllPosts() {
  // Mock implementation
  return [
    { slug: 'post1', updatedAt: '2023-01-01' },
    { slug: 'post2', updatedAt: '2023-01-02' },
  ]
}

async function getAllProducts() {
  // Mock implementation
  return [
    { slug: 'product1', updatedAt: '2023-01-01' },
    { slug: 'product2', updatedAt: '2023-01-02' },
  ]
}

async function getProductCount() {
  // Mock implementation
  return 100000
}
