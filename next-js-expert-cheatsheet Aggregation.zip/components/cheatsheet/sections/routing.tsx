import { CodeBlock, InlineCode } from "../code-block"
import { SectionHeader, SubSection, Callout, KeyValueGrid } from "../section-header"

export function RoutingSection() {
  return (
    <section>
      <SectionHeader
        id="routing"
        title="Routing"
        description="The file-system based router is the backbone of Next.js. Master every routing primitive: dynamic segments, catch-all routes, parallel slots, intercepting patterns, and navigation APIs."
        badge="CHAPTER 02"
      />

      <SubSection id="app-router" title="App Router">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          The App Router is built on React Server Components and supports layouts, nested routing, loading states,
          error handling, and more. Every folder in <InlineCode>app/</InlineCode> represents a route segment.
        </p>
        <CodeBlock
          filename="app/page.tsx"
          language="tsx"
          code={`// This is a Server Component by default
// It can be async, fetch data directly, and access server-only APIs

export default async function HomePage() {
  // Direct database/API access — no API route needed
  const posts = await db.post.findMany({
    orderBy: { createdAt: 'desc' },
    take: 10,
  })

  return (
    <main>
      <h1>Latest Posts</h1>
      {posts.map(post => (
        <article key={post.id}>
          <h2>{post.title}</h2>
          <p>{post.excerpt}</p>
        </article>
      ))}
    </main>
  )
}`}
          highlights={[1, 2, 6, 7, 8]}
        />

        <h4 className="text-sm font-semibold text-foreground mt-6 mb-3">Navigation APIs</h4>
        <CodeBlock
          filename="components/nav.tsx"
          language="tsx"
          code={`'use client'
import Link from 'next/link'
import { useRouter, usePathname, useSearchParams } from 'next/navigation'

// ✅ Declarative navigation (preferred)
<Link href="/dashboard">Dashboard</Link>

// ✅ With prefetching control
<Link href="/heavy-page" prefetch={false}>Heavy Page</Link>

// ✅ Replace instead of push (no back button entry)
<Link href="/login" replace>Login</Link>

// ✅ Programmatic navigation
export function NavigateButton() {
  const router = useRouter()
  const pathname = usePathname()         // Current path
  const searchParams = useSearchParams() // Query string params

  function handleClick() {
    router.push('/dashboard')       // Navigate
    router.replace('/login')        // Replace history entry
    router.refresh()                // Re-fetch server components
    router.back()                   // Go back
    router.forward()                // Go forward
    router.prefetch('/settings')    // Prefetch a route
  }

  return <button onClick={handleClick}>Navigate</button>
}`}
          highlights={[6, 17, 18]}
        />
        <Callout type="warning">
          <InlineCode>useRouter</InlineCode>, <InlineCode>usePathname</InlineCode>, and <InlineCode>useSearchParams</InlineCode> are
          Client Component hooks. You must add <InlineCode>{"'use client'"}</InlineCode> at the top of any component that uses them.
          In Server Components, use the <InlineCode>params</InlineCode> and <InlineCode>searchParams</InlineCode> props instead (they must be awaited in Next.js 15+).
        </Callout>
      </SubSection>

      <SubSection id="dynamic-routes" title="Dynamic Routes">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Dynamic segments let you create routes from dynamic data. Brackets denote dynamic segments,
          and Next.js provides three levels of dynamism.
        </p>
        <KeyValueGrid
          items={[
            { key: "[slug]", value: "Single dynamic segment. Matches /blog/hello, /blog/world." },
            { key: "[...slug]", value: "Catch-all. Matches /blog/a, /blog/a/b, /blog/a/b/c." },
            { key: "[[...slug]]", value: "Optional catch-all. Also matches /blog (the root)." },
          ]}
        />
        <CodeBlock
          filename="app/blog/[slug]/page.tsx"
          language="tsx"
          code={`// Next.js 15+: params is a Promise and MUST be awaited

interface PageProps {
  params: Promise<{ slug: string }>
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}

export default async function BlogPost({ params, searchParams }: PageProps) {
  const { slug } = await params
  const { sort } = await searchParams

  const post = await getPost(slug)
  if (!post) notFound() // Triggers not-found.tsx

  return <article>{post.content}</article>
}

// Generate static paths at build time (SSG)
export async function generateStaticParams() {
  const posts = await getAllPosts()
  return posts.map((post) => ({
    slug: post.slug, // Must match the [slug] segment name
  }))
}

// Dynamic metadata for SEO
export async function generateMetadata({ params }: PageProps) {
  const { slug } = await params
  const post = await getPost(slug)
  return {
    title: post?.title ?? 'Not Found',
    description: post?.excerpt,
    openGraph: {
      title: post?.title,
      images: [{ url: post?.image }],
    },
  }
}`}
          highlights={[2, 3, 4, 9, 10, 19]}
        />
        <Callout type="danger">
          In Next.js 15+, <InlineCode>params</InlineCode> and <InlineCode>searchParams</InlineCode> are Promises.
          You must <InlineCode>await</InlineCode> them before accessing properties. Failing to await will throw a runtime error.
          This also applies to <InlineCode>headers()</InlineCode> and <InlineCode>cookies()</InlineCode>.
        </Callout>
      </SubSection>

      <SubSection id="route-groups" title="Route Groups">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Route groups let you organize routes without affecting the URL path. Parentheses in folder names
          create organizational groups. This is essential for complex applications.
        </p>
        <CodeBlock
          filename="Route Group Architecture"
          language="text"
          code={`app/
├── (marketing)/           # Route group — NOT in URL
│   ├── layout.tsx         # Shared marketing layout
│   ├── page.tsx           # / (home page)
│   ├── about/page.tsx     # /about
│   └── pricing/page.tsx   # /pricing
│
├── (dashboard)/           # Separate group with its own layout
│   ├── layout.tsx         # Dashboard layout (sidebar, nav)
│   ├── overview/page.tsx  # /overview
│   ├── analytics/page.tsx # /analytics
│   └── settings/page.tsx  # /settings
│
├── (auth)/                # Auth pages with minimal layout
│   ├── layout.tsx         # Centered card layout
│   ├── login/page.tsx     # /login
│   └── register/page.tsx  # /register
│
└── layout.tsx             # Root layout (shared by all groups)`}
          highlights={[2, 8, 14]}
        />
        <Callout type="tip">
          Route groups solve the "multiple root layouts" problem. Each group can have its own layout,
          so your marketing site can have a completely different shell than your dashboard without nested URL segments.
        </Callout>
      </SubSection>

      <SubSection id="parallel-routes" title="Parallel & Intercepting Routes">
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          Parallel routes render multiple pages simultaneously in the same layout.
          Intercepting routes let you show a route within the context of another (e.g., a modal overlay).
        </p>
        <CodeBlock
          filename="Parallel Routes: app/dashboard/layout.tsx"
          language="tsx"
          code={`// @folder convention creates named "slots"
// Each slot renders independently and simultaneously

// File structure:
// app/dashboard/@analytics/page.tsx
// app/dashboard/@team/page.tsx
// app/dashboard/layout.tsx

export default function DashboardLayout({
  children,     // Default slot (app/dashboard/page.tsx)
  analytics,    // @analytics slot
  team,         // @team slot
}: {
  children: React.ReactNode
  analytics: React.ReactNode
  team: React.ReactNode
}) {
  return (
    <div className="grid grid-cols-2 gap-4">
      <div>{children}</div>
      <div>{analytics}</div>
      <div className="col-span-2">{team}</div>
    </div>
  )
}

// Each slot can have its own loading.tsx and error.tsx!
// Slots are independently streamed and error-bounded.`}
          highlights={[10, 11, 12, 27]}
        />
        <CodeBlock
          filename="Intercepting Routes: Modal Pattern"
          language="tsx"
          code={`// File structure for photo modal intercept:
// app/
// ├── feed/
// │   └── page.tsx              → /feed (the list)
// ├── photo/[id]/
// │   └── page.tsx              → /photo/123 (full page)
// └── @modal/
//     └── (.)photo/[id]/
//         └── page.tsx          → Intercepts /photo/123 as modal

// Interception conventions:
// (.)   → Same level
// (..)  → One level up
// (..)(..) → Two levels up
// (...) → From root

// @modal/(.)photo/[id]/page.tsx
export default async function PhotoModal({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const photo = await getPhoto(id)

  return (
    <Dialog>
      <img src={photo.url || "/placeholder.svg"} alt={photo.alt} />
      <p>{photo.description}</p>
    </Dialog>
  )
}

// When clicking a Link to /photo/123 from /feed:
//   → Modal shows (intercepted)
// When directly navigating to /photo/123:
//   → Full page shows (not intercepted)`}
          highlights={[8, 11, 12, 13, 14]}
        />
      </SubSection>

      <SubSection id="loading-error" title="Loading & Error States">
        <CodeBlock
          filename="app/dashboard/loading.tsx"
          language="tsx"
          code={`// Automatic Suspense boundary — shows while page streams
export default function Loading() {
  return (
    <div className="animate-pulse space-y-4">
      <div className="h-8 bg-muted rounded w-1/3" />
      <div className="h-4 bg-muted rounded w-2/3" />
      <div className="h-4 bg-muted rounded w-1/2" />
    </div>
  )
}`}
        />
        <CodeBlock
          filename="app/dashboard/error.tsx"
          language="tsx"
          code={`'use client' // Error components MUST be Client Components

import { useEffect } from 'react'

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    // Log to error reporting service
    console.error(error)
  }, [error])

  return (
    <div role="alert">
      <h2>Something went wrong!</h2>
      <p>{error.message}</p>
      {/* Attempt to recover by re-rendering the segment */}
      <button onClick={() => reset()}>Try again</button>
    </div>
  )
}

// error.tsx catches errors in its CHILD segments.
// It does NOT catch errors in its own layout.tsx.
// For that, you need the PARENT's error.tsx or global-error.tsx.`}
          highlights={[1, 10, 22, 27, 28, 29]}
        />
      </SubSection>
    </section>
  )
}
