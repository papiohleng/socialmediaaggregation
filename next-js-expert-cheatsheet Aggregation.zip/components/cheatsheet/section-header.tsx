import React from "react"
interface SectionHeaderProps {
  id: string
  title: string
  description: string
  badge?: string
}

export function SectionHeader({ id, title, description, badge }: SectionHeaderProps) {
  return (
    <div id={id} className="mb-6 scroll-mt-20">
      <div className="flex items-center gap-3 mb-2">
        {badge && (
          <span className="rounded-full bg-primary/10 px-3 py-0.5 text-xs font-mono font-medium text-primary border border-primary/20">
            {badge}
          </span>
        )}
      </div>
      <h2 className="text-2xl font-bold tracking-tight text-foreground lg:text-3xl text-balance">
        {title}
      </h2>
      <p className="mt-2 text-base text-muted-foreground leading-relaxed max-w-2xl">
        {description}
      </p>
    </div>
  )
}

interface SubSectionProps {
  id: string
  title: string
  children: React.ReactNode
}

export function SubSection({ id, title, children }: SubSectionProps) {
  return (
    <section id={id} className="mb-12 scroll-mt-20">
      <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
        <span className="h-px flex-1 bg-border max-w-8" />
        {title}
      </h3>
      {children}
    </section>
  )
}

export function Callout({ type = "info", title, children }: { type?: "info" | "warning" | "tip" | "danger"; title?: string; children: React.ReactNode }) {
  const styles = {
    info: "border-chart-2/30 bg-chart-2/5 text-chart-2",
    warning: "border-chart-3/30 bg-chart-3/5 text-chart-3",
    tip: "border-primary/30 bg-primary/5 text-primary",
    danger: "border-destructive/30 bg-destructive/5 text-destructive",
  }
  const labels = { info: "Note", warning: "Warning", tip: "Pro Tip", danger: "Danger" }

  return (
    <div className={`my-4 rounded-lg border p-4 ${styles[type]}`}>
      <p className="text-xs font-mono font-semibold uppercase tracking-wider mb-1">{title || labels[type]}</p>
      <div className="text-sm text-foreground/80 leading-relaxed">{children}</div>
    </div>
  )
}

export function KeyValueGrid({ items }: { items: { key: string; value: string }[] }) {
  return (
    <div className="my-4 grid gap-2">
      {items.map((item) => (
        <div key={item.key} className="flex gap-3 rounded-md border border-border bg-card p-3">
          <code className="shrink-0 font-mono text-[13px] text-primary font-medium">{item.key}</code>
          <span className="text-sm text-muted-foreground">{item.value}</span>
        </div>
      ))}
    </div>
  )
}
