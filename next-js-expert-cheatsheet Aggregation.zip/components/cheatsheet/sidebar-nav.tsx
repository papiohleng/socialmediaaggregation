"use client"

import React from "react"

import { useState, useMemo } from "react"
import { Search, ChevronRight, X, Layers, Route, Server, Database, Shield, Zap, Globe, Settings, FileCode, BookOpen, ArrowRight, Cable, Lock, Radio, KeyRound, SearchCheck } from "lucide-react"

export interface NavSection {
  id: string
  title: string
  icon: React.ReactNode
  items: { id: string; title: string }[]
}

const NAV_SECTIONS: NavSection[] = [
  {
    id: "fundamentals",
    title: "Fundamentals",
    icon: <BookOpen className="h-4 w-4" />,
    items: [
      { id: "project-structure", title: "Project Structure" },
      { id: "file-conventions", title: "File Conventions" },
      { id: "component-hierarchy", title: "Component Hierarchy" },
    ],
  },
  {
    id: "routing",
    title: "Routing",
    icon: <Route className="h-4 w-4" />,
    items: [
      { id: "app-router", title: "App Router" },
      { id: "dynamic-routes", title: "Dynamic Routes" },
      { id: "route-groups", title: "Route Groups" },
      { id: "parallel-routes", title: "Parallel & Intercepting" },
      { id: "loading-error", title: "Loading & Error States" },
    ],
  },
  {
    id: "rendering",
    title: "Rendering",
    icon: <Layers className="h-4 w-4" />,
    items: [
      { id: "server-components", title: "Server Components" },
      { id: "client-components", title: "Client Components" },
      { id: "composition-patterns", title: "Composition Patterns" },
      { id: "streaming", title: "Streaming & Suspense" },
    ],
  },
  {
    id: "data",
    title: "Data Fetching",
    icon: <Database className="h-4 w-4" />,
    items: [
      { id: "server-fetch", title: "Server-Side Fetching" },
      { id: "caching-revalidation", title: "Caching & Revalidation" },
      { id: "server-actions", title: "Server Actions" },
      { id: "use-cache", title: "use cache Directive" },
    ],
  },
  {
    id: "api",
    title: "API Layer",
    icon: <Server className="h-4 w-4" />,
    items: [
      { id: "route-handlers", title: "Route Handlers" },
      { id: "middleware", title: "Middleware" },
      { id: "api-patterns", title: "Advanced API Patterns" },
    ],
  },
  {
    id: "optimization",
    title: "Optimization",
    icon: <Zap className="h-4 w-4" />,
    items: [
      { id: "image-optimization", title: "Image Optimization" },
      { id: "font-optimization", title: "Font Optimization" },
      { id: "script-optimization", title: "Script & Metadata" },
      { id: "bundle-analysis", title: "Bundle Analysis" },
    ],
  },
  {
    id: "auth-security",
    title: "Auth & Security",
    icon: <Shield className="h-4 w-4" />,
    items: [
      { id: "authentication", title: "Authentication" },
      { id: "authorization", title: "Authorization" },
      { id: "security-headers", title: "Security Headers" },
    ],
  },
  {
    id: "styling",
    title: "Styling",
    icon: <FileCode className="h-4 w-4" />,
    items: [
      { id: "css-modules", title: "CSS & Modules" },
      { id: "tailwind-css", title: "Tailwind CSS" },
      { id: "css-in-js", title: "CSS-in-JS & Strategies" },
    ],
  },
  {
    id: "deployment",
    title: "Deployment",
    icon: <Globe className="h-4 w-4" />,
    items: [
      { id: "vercel-deploy", title: "Vercel Deployment" },
      { id: "self-hosting", title: "Self-Hosting" },
      { id: "env-variables", title: "Environment Variables" },
    ],
  },
  {
    id: "advanced",
    title: "Advanced Patterns",
    icon: <Settings className="h-4 w-4" />,
    items: [
      { id: "architecture", title: "Architecture Patterns" },
      { id: "testing", title: "Testing Strategies" },
      { id: "internationalization", title: "Internationalization" },
      { id: "performance", title: "Performance Playbook" },
    ],
  },
  {
    id: "seo-mastery",
    title: "SEO Mastery",
    icon: <SearchCheck className="h-4 w-4" />,
    items: [
      { id: "seo-metadata-api", title: "Metadata API" },
      { id: "seo-dynamic-metadata", title: "Dynamic Metadata" },
      { id: "seo-json-ld", title: "Structured Data (JSON-LD)" },
      { id: "seo-faq-schema", title: "FAQ Schema" },
      { id: "seo-breadcrumbs", title: "Breadcrumb Schema" },
      { id: "seo-sitemap", title: "Sitemap Generation" },
      { id: "seo-robots", title: "robots.txt" },
      { id: "seo-og-images", title: "OG Image Generation" },
      { id: "seo-canonical", title: "Canonical URLs" },
      { id: "seo-static-params", title: "Static Pre-Rendering" },
      { id: "seo-core-web-vitals", title: "Core Web Vitals" },
      { id: "seo-semantic-html", title: "Semantic HTML" },
      { id: "seo-international", title: "International SEO" },
      { id: "seo-rss-feed", title: "RSS Feed" },
      { id: "seo-checklist", title: "Audit Checklist" },
      { id: "seo-mistakes", title: "Common Mistakes" },
      { id: "seo-utilities", title: "SEO Utilities" },
    ],
  },
  {
    id: "supabase-integration",
    title: "Supabase Setup",
    icon: <Cable className="h-4 w-4" />,
    items: [
      { id: "supabase-architecture", title: "Architecture Overview" },
      { id: "supabase-client-setup", title: "Client Setup" },
      { id: "supabase-middleware-setup", title: "Middleware Session" },
      { id: "supabase-typegen", title: "Type-Safe Queries" },
      { id: "supabase-directory", title: "Directory Structure" },
    ],
  },
  {
    id: "supabase-auth",
    title: "Supabase Auth",
    icon: <KeyRound className="h-4 w-4" />,
    items: [
      { id: "auth-signup", title: "Sign Up Flow" },
      { id: "auth-login", title: "Login Flow" },
      { id: "auth-logout", title: "Logout" },
      { id: "auth-server-guard", title: "Server Auth Guards" },
      { id: "auth-server-actions", title: "Auth in Server Actions" },
      { id: "auth-oauth", title: "OAuth Providers" },
      { id: "auth-password-reset", title: "Password Reset" },
      { id: "auth-user-metadata", title: "User Metadata" },
      { id: "auth-auto-profile", title: "Auto-Create Profile" },
      { id: "auth-onchange", title: "Auth State Listener" },
    ],
  },
  {
    id: "supabase-realtime",
    title: "Real-Time Updates",
    icon: <Radio className="h-4 w-4" />,
    items: [
      { id: "realtime-concepts", title: "Core Concepts" },
      { id: "realtime-postgres", title: "Postgres Changes" },
      { id: "realtime-filtered", title: "Filtered Subscriptions" },
      { id: "realtime-broadcast", title: "Broadcast Messaging" },
      { id: "realtime-presence", title: "Presence (Online)" },
      { id: "realtime-component", title: "Full-Stack Component" },
      { id: "realtime-cleanup", title: "Cleanup & Performance" },
    ],
  },
  {
    id: "supabase-rls",
    title: "Row Level Security",
    icon: <Lock className="h-4 w-4" />,
    items: [
      { id: "rls-fundamentals", title: "RLS Fundamentals" },
      { id: "rls-ownership", title: "User Ownership" },
      { id: "rls-public-private", title: "Public + Private" },
      { id: "rls-rbac", title: "Role-Based Access" },
      { id: "rls-multi-tenant", title: "Multi-Tenant" },
      { id: "rls-service-role", title: "Bypassing RLS" },
      { id: "rls-testing", title: "Testing Policies" },
      { id: "rls-best-practices", title: "Best Practices" },
      { id: "rls-complete-schema", title: "Production Schema" },
    ],
  },
]

interface SidebarNavProps {
  activeSection: string
  onNavigate: (id: string) => void
}

export function SidebarNav({ activeSection, onNavigate }: SidebarNavProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [expandedSections, setExpandedSections] = useState<string[]>(
    NAV_SECTIONS.map((s) => s.id)
  )

  const filteredSections = useMemo(() => {
    if (!searchQuery) return NAV_SECTIONS
    const q = searchQuery.toLowerCase()
    return NAV_SECTIONS.map((section) => ({
      ...section,
      items: section.items.filter(
        (item) =>
          item.title.toLowerCase().includes(q) ||
          section.title.toLowerCase().includes(q)
      ),
    })).filter((section) => section.items.length > 0)
  }, [searchQuery])

  const toggleSection = (id: string) => {
    setExpandedSections((prev) =>
      prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]
    )
  }

  return (
    <nav className="flex h-full flex-col" aria-label="Documentation navigation">
      {/* Search */}
      <div className="p-4 pb-2">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            type="search"
            placeholder="Search sections..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full rounded-md border border-border bg-secondary/50 py-2 pl-9 pr-8 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              aria-label="Clear search"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Nav items */}
      <div className="flex-1 overflow-y-auto px-2 pb-4">
        {filteredSections.map((section) => {
          const isExpanded = expandedSections.includes(section.id)
          return (
            <div key={section.id} className="mb-1">
              <button
                onClick={() => toggleSection(section.id)}
                className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-sm font-medium text-foreground/80 hover:bg-secondary hover:text-foreground transition-colors"
              >
                <span className="text-muted-foreground">{section.icon}</span>
                <span className="flex-1 text-left">{section.title}</span>
                <ChevronRight
                  className={`h-3.5 w-3.5 text-muted-foreground transition-transform ${
                    isExpanded ? "rotate-90" : ""
                  }`}
                />
              </button>
              {isExpanded && (
                <div className="ml-4 mt-0.5 border-l border-border pl-2">
                  {section.items.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => onNavigate(item.id)}
                      className={`flex w-full items-center gap-1.5 rounded-md px-2 py-1 text-[13px] transition-colors ${
                        activeSection === item.id
                          ? "text-primary font-medium bg-primary/5"
                          : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                      }`}
                    >
                      {activeSection === item.id && (
                        <ArrowRight className="h-3 w-3 shrink-0" />
                      )}
                      <span>{item.title}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </nav>
  )
}

export { NAV_SECTIONS }
