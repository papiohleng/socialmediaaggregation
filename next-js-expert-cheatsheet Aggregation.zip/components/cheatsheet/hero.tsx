"use client"

import { useState, useEffect } from "react"
import { ChevronDown } from "lucide-react"

const NEXT_FACTS = [
  "Server Components ship zero client JS",
  "Layouts persist state across navigations",
  "Streaming renders progressively, not all-or-nothing",
  "Middleware runs at the edge in < 1ms",
  "Route Handlers replace API routes",
  "'use cache' is the inverse of 'use client'",
  "Parallel routes render multiple pages simultaneously",
  "React cache() deduplicates within a render pass",
  "Supabase RLS enforces auth at the database layer",
  "Real-time subscriptions push changes without polling",
  "auth.uid() in RLS policies = zero-trust by default",
  "Supabase Presence tracks live online users instantly",
  "Broadcast lets clients talk without touching the DB",
  "security definer functions bypass RLS safely",
  "JSON-LD structured data unlocks Google rich results",
  "generateMetadata() deduplicates fetches automatically",
  "opengraph-image.tsx generates OG images on the fly",
  "sitemap.ts auto-generates your XML sitemap at build",
]

export function Hero() {
  const [factIndex, setFactIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setFactIndex((prev) => (prev + 1) % NEXT_FACTS.length)
    }, 4000)
    return () => clearInterval(interval)
  }, [])

  return (
    <header className="relative border-b border-border bg-card">
      <div className="mx-auto max-w-5xl px-6 py-16 lg:py-24">
        <div className="flex flex-col gap-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 border border-primary/20">
              <span className="font-mono text-sm font-bold text-primary">N</span>
            </div>
            <span className="text-xs font-mono text-muted-foreground tracking-widest uppercase">
              The Definitive Reference
            </span>
          </div>

          <h1 className="text-4xl font-bold tracking-tight text-foreground lg:text-6xl text-balance">
            The Next.js Codex
          </h1>

          <p className="max-w-2xl text-lg text-muted-foreground leading-relaxed lg:text-xl">
            Every concept, pattern, and API in Next.js + Supabase — from first principles to production full-stack architecture.
            15 chapters. Auth, real-time, RLS, SEO. Complete mastery.
          </p>

          <div className="mt-2 flex items-center gap-2 rounded-md border border-border bg-background px-4 py-2.5 max-w-lg">
            <span className="text-xs font-mono text-primary shrink-0">{">"}</span>
            <p className="text-sm font-mono text-foreground/70 transition-all duration-500" key={factIndex}>
              {NEXT_FACTS[factIndex]}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-muted-foreground mt-2">
            <span className="rounded-full bg-secondary px-3 py-1">Next.js 16</span>
            <span className="rounded-full bg-secondary px-3 py-1">React 19</span>
            <span className="rounded-full bg-secondary px-3 py-1">App Router</span>
            <span className="rounded-full bg-secondary px-3 py-1">TypeScript</span>
            <span className="rounded-full bg-secondary px-3 py-1">Turbopack</span>
            <span className="rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-3 py-1">Supabase</span>
            <span className="rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-3 py-1">Real-Time</span>
            <span className="rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-3 py-1">RLS</span>
            <span className="rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/20 px-3 py-1">SEO</span>
          </div>
        </div>
      </div>

      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 animate-bounce">
        <ChevronDown className="h-5 w-5 text-muted-foreground/50" />
      </div>
    </header>
  )
}
