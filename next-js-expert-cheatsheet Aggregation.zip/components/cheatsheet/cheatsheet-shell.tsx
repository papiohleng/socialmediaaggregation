"use client"

import { useState, useCallback } from "react"
import { Menu, X } from "lucide-react"
import { SidebarNav } from "./sidebar-nav"
import { Hero } from "./hero"
import { TableOfContents } from "./table-of-contents"
import { FundamentalsSection } from "./sections/fundamentals"
import { RoutingSection } from "./sections/routing"
import { RenderingSection } from "./sections/rendering"
import { DataFetchingSection } from "./sections/data-fetching"
import { ApiLayerSection } from "./sections/api-layer"
import { OptimizationSection } from "./sections/optimization"
import { AuthSecuritySection } from "./sections/auth-security"
import { StylingSection } from "./sections/styling"
import { DeploymentSection } from "./sections/deployment"
import { AdvancedSection } from "./sections/advanced"
import { SeoMasterySection } from "./sections/seo-mastery"
import { SupabaseSetupSection } from "./sections/supabase-setup"
import { SupabaseAuthSection } from "./sections/supabase-auth"
import { SupabaseRealtimeSection } from "./sections/supabase-realtime"
import { SupabaseRlsSection } from "./sections/supabase-rls"

export function CheatsheetShell() {
  const [activeSection, setActiveSection] = useState("project-structure")
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const handleNavigate = useCallback((id: string) => {
    setActiveSection(id)
    setSidebarOpen(false)
    const el = document.getElementById(id)
    if (el) {
      el.scrollIntoView({ behavior: "smooth" })
    }
  }, [])

  return (
    <div className="min-h-screen bg-background">
      <Hero />

      {/* Mobile sidebar toggle */}
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="fixed bottom-6 right-6 z-50 flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg lg:hidden"
        aria-label={sidebarOpen ? "Close navigation" : "Open navigation"}
      >
        {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </button>

      <div className="mx-auto flex max-w-[1440px]">
        {/* Sidebar */}
        <aside
          className={`fixed inset-y-0 left-0 z-40 w-72 border-r border-border bg-card transition-transform lg:sticky lg:top-0 lg:h-screen lg:translate-x-0 ${
            sidebarOpen ? "translate-x-0" : "-translate-x-full"
          }`}
        >
          <div className="flex h-full flex-col pt-4">
            <div className="px-4 pb-3 border-b border-border mb-2">
              <p className="text-xs font-mono text-muted-foreground uppercase tracking-widest">
                Navigation
              </p>
            </div>
            <SidebarNav activeSection={activeSection} onNavigate={handleNavigate} />
          </div>
        </aside>

        {/* Mobile overlay */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-30 bg-background/80 backdrop-blur-sm lg:hidden"
            onClick={() => setSidebarOpen(false)}
            onKeyDown={(e) => e.key === "Escape" && setSidebarOpen(false)}
            role="button"
            tabIndex={0}
            aria-label="Close navigation"
          />
        )}

        {/* Main content */}
        <main className="flex-1 min-w-0">
          <div className="flex">
            <div className="flex-1 min-w-0 px-6 py-12 lg:px-12 lg:py-16 max-w-4xl">
              <div className="space-y-20">
                <FundamentalsSection />
                <div className="h-px bg-border" />
                <RoutingSection />
                <div className="h-px bg-border" />
                <RenderingSection />
                <div className="h-px bg-border" />
                <DataFetchingSection />
                <div className="h-px bg-border" />
                <ApiLayerSection />
                <div className="h-px bg-border" />
                <OptimizationSection />
                <div className="h-px bg-border" />
                <AuthSecuritySection />
                <div className="h-px bg-border" />
                <StylingSection />
                <div className="h-px bg-border" />
                <DeploymentSection />
                <div className="h-px bg-border" />
                <AdvancedSection />

                {/* SEO Mastery Chapter */}
                <div className="relative mt-10">
                  <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-sky-500/50 to-transparent" />
                  <div className="pt-10 pb-4">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-md bg-sky-500/10 border border-sky-500/20">
                        <span className="font-mono text-xs font-bold text-sky-400">S</span>
                      </div>
                      <span className="text-xs font-mono text-sky-400/80 tracking-widest uppercase">
                        Search Engine Optimization
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground max-w-xl leading-relaxed">
                      Every technique to achieve maximum search visibility. Metadata, structured data, sitemaps, OG images, Core Web Vitals, and the complete SEO audit checklist.
                    </p>
                  </div>
                </div>
                <SeoMasterySection />

                {/* Supabase Full-Stack Chapters */}
                <div className="relative mt-10">
                  <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-emerald-500/50 to-transparent" />
                  <div className="pt-10 pb-4">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-md bg-emerald-500/10 border border-emerald-500/20">
                        <span className="font-mono text-xs font-bold text-emerald-400">S</span>
                      </div>
                      <span className="text-xs font-mono text-emerald-400/80 tracking-widest uppercase">
                        Supabase Full-Stack Integration
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground max-w-xl leading-relaxed">
                      Four chapters covering everything from Supabase client setup to production Row Level Security. Build complete, real-time, authenticated full-stack applications.
                    </p>
                  </div>
                </div>
                <SupabaseSetupSection />
                <div className="h-px bg-border" />
                <SupabaseAuthSection />
                <div className="h-px bg-border" />
                <SupabaseRealtimeSection />
                <div className="h-px bg-border" />
                <SupabaseRlsSection />
              </div>

              {/* Footer */}
              <footer className="mt-24 border-t border-border pt-8 pb-16">
                <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p className="text-sm font-semibold text-foreground">The Next.js Codex</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      The definitive full-stack reference. 15 chapters. Complete mastery.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
                    <span>Next.js 16</span>
                    <span className="h-1 w-1 rounded-full bg-muted-foreground/30" />
                    <span>React 19</span>
                    <span className="h-1 w-1 rounded-full bg-muted-foreground/30" />
                    <span>Supabase</span>
                    <span className="h-1 w-1 rounded-full bg-muted-foreground/30" />
                    <span>Real-Time</span>
                    <span className="h-1 w-1 rounded-full bg-muted-foreground/30" />
                    <span>RLS</span>
                    <span className="h-1 w-1 rounded-full bg-muted-foreground/30" />
                    <span>SEO</span>
                  </div>
                </div>
              </footer>
            </div>

            {/* Right-side TOC */}
            <div className="hidden xl:block w-56 shrink-0 py-16 pr-6">
              <TableOfContents />
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
