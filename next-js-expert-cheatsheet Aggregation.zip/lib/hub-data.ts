export type Platform =
  | "all"
  | "youtube"
  | "instagram"
  | "facebook"
  | "x"
  | "tiktok"
  | "twitch"
  | "pinterest"
  | "flickr"
  | "reddit"
  | "telegram"
  | "whatsapp"
  | "linkedin"
  | "discord"
  | "medium"

export type ContentType = "video" | "image" | "text" | "carousel"
export type Badge = "trending" | "popular" | "new" | "featured" | null
export type SortOption = "newest" | "popular" | "most-clicked" | "trending"

export interface SocialPost {
  id: string
  platform: Platform
  title: string
  caption: string
  thumbnail: string
  contentType: ContentType
  badge: Badge
  url: string
  likes: number
  comments: number
  shares: number
  clicks: number
  hashtags: string[]
  date: string
  aspectRatio: "square" | "landscape" | "portrait"
}

export const PLATFORMS: { id: Platform; label: string; color: string; hoverGlow: string }[] = [
  { id: "all", label: "All", color: "rgba(0,245,255,1)", hoverGlow: "rgba(0,245,255,0.25)" },
  { id: "youtube", label: "YouTube", color: "#FF0000", hoverGlow: "rgba(255,0,0,0.25)" },
  { id: "instagram", label: "Instagram", color: "#E4405F", hoverGlow: "rgba(228,64,95,0.25)" },
  { id: "facebook", label: "Facebook", color: "#1877F2", hoverGlow: "rgba(24,119,242,0.25)" },
  { id: "x", label: "X", color: "#a0a0a0", hoverGlow: "rgba(160,160,160,0.25)" },
  { id: "tiktok", label: "TikTok", color: "#00F2EA", hoverGlow: "rgba(0,242,234,0.25)" },
  { id: "twitch", label: "Twitch", color: "#9146FF", hoverGlow: "rgba(145,70,255,0.25)" },
  { id: "pinterest", label: "Pinterest", color: "#E60023", hoverGlow: "rgba(230,0,35,0.25)" },
  { id: "flickr", label: "Flickr", color: "#0063DC", hoverGlow: "rgba(0,99,220,0.25)" },
  { id: "reddit", label: "Reddit", color: "#FF4500", hoverGlow: "rgba(255,69,0,0.25)" },
  { id: "telegram", label: "Telegram", color: "#26A5E4", hoverGlow: "rgba(38,165,228,0.25)" },
  { id: "whatsapp", label: "WhatsApp", color: "#25D366", hoverGlow: "rgba(37,211,102,0.25)" },
  { id: "linkedin", label: "LinkedIn", color: "#0A66C2", hoverGlow: "rgba(10,102,194,0.25)" },
  { id: "discord", label: "Discord", color: "#5865F2", hoverGlow: "rgba(88,101,242,0.25)" },
  { id: "medium", label: "Medium", color: "#a0a0a0", hoverGlow: "rgba(160,160,160,0.25)" },
]

export function getPlatformIcon(platform: Platform): string {
  const icons: Record<Platform, string> = {
    all: "M3.75 6A2.25 2.25 0 0 1 6 3.75h2.25A2.25 2.25 0 0 1 10.5 6v2.25a2.25 2.25 0 0 1-2.25 2.25H6a2.25 2.25 0 0 1-2.25-2.25V6ZM3.75 15.75A2.25 2.25 0 0 1 6 13.5h2.25a2.25 2.25 0 0 1 2.25 2.25V18a2.25 2.25 0 0 1-2.25 2.25H6A2.25 2.25 0 0 1 3.75 18v-2.25ZM13.5 6a2.25 2.25 0 0 1 2.25-2.25H18A2.25 2.25 0 0 1 20.25 6v2.25A2.25 2.25 0 0 1 18 10.5h-2.25a2.25 2.25 0 0 1-2.25-2.25V6ZM13.5 15.75a2.25 2.25 0 0 1 2.25-2.25H18a2.25 2.25 0 0 1 2.25 2.25V18A2.25 2.25 0 0 1 18 20.25h-2.25a2.25 2.25 0 0 1-2.25-2.25v-2.25Z",
    youtube: "M23.5 6.5a3 3 0 0 0-2.1-2.1C19.5 4 12 4 12 4s-7.5 0-9.4.4A3 3 0 0 0 .5 6.5S0 8.8 0 11v1.5c0 2.2.5 4.5.5 4.5a3 3 0 0 0 2.1 2.1c1.9.4 9.4.4 9.4.4s7.5 0 9.4-.4a3 3 0 0 0 2.1-2.1s.5-2.3.5-4.5V11c0-2.2-.5-4.5-.5-4.5ZM9.75 15.5V8l6.25 3.75-6.25 3.75Z",
    instagram: "M12 2.2h4.9c1.3.1 2 .3 2.4.4.6.2 1 .5 1.5 1s.7.9 1 1.5c.1.5.4 1.1.4 2.4.1 1.4.1 1.8.1 5.2v4.1c-.1 1.3-.3 2-.4 2.4-.2.6-.5 1-1 1.5s-.9.7-1.5 1c-.5.1-1.1.4-2.4.4-1.4.1-1.8.1-5.2.1h-3.8c-1.3-.1-2-.3-2.4-.4-.6-.2-1-.5-1.5-1s-.7-.9-1-1.5c-.1-.5-.4-1.1-.4-2.4C2.2 15.5 2.2 15 2.2 12V7.1c.1-1.3.3-2 .4-2.4.2-.6.5-1 1-1.5s.9-.7 1.5-1c.5-.1 1.1-.4 2.4-.4C8.9 2.2 9.4 2.2 12 2.2ZM12 0C8.7 0 8.3 0 7.1.1 5.8.1 4.9.3 4.1.6c-.8.3-1.5.7-2.2 1.4C1.3 2.6.9 3.3.6 4.1.3 4.9.1 5.8.1 7.1 0 8.3 0 8.7 0 12s0 3.7.1 4.9c0 1.3.2 2.2.5 3 .3.8.7 1.5 1.4 2.2.7.7 1.4 1.1 2.2 1.4.8.3 1.7.5 3 .5 1.2.1 1.6.1 4.9.1s3.7 0 4.9-.1c1.3 0 2.2-.2 3-.5.8-.3 1.5-.7 2.2-1.4.7-.7 1.1-1.4 1.4-2.2.3-.8.5-1.7.5-3 .1-1.2.1-1.6.1-4.9s0-3.7-.1-4.9c0-1.3-.2-2.2-.5-3-.3-.8-.7-1.5-1.4-2.2-.7-.7-1.4-1.1-2.2-1.4-.8-.3-1.7-.5-3-.5C15.7 0 15.3 0 12 0Zm0 5.8a6.2 6.2 0 1 0 0 12.4A6.2 6.2 0 0 0 12 5.8ZM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8Zm6.4-11.8a1.4 1.4 0 1 0 0 2.8 1.4 1.4 0 0 0 0-2.8Z",
    facebook: "M24 12c0-6.6-5.4-12-12-12S0 5.4 0 12c0 6 4.4 11 10.1 11.9v-8.4H7.1V12h3v-2.7c0-3 1.8-4.7 4.5-4.7 1.3 0 2.7.2 2.7.2v2.9h-1.5c-1.5 0-2 .9-2 1.9V12h3.3l-.5 3.5h-2.8v8.4C19.6 23 24 18 24 12Z",
    x: "M18.2 2.25h3.5l-7.7 8.8 9 11.9h-7.1l-5.5-7.2-6.3 7.2H.6l8.2-9.4L0 2.25h7.3l5 6.6 5.9-6.6Zm-1.2 18.6h1.9L6.2 4.2H4.1l12.9 16.65Z",
    tiktok: "M12.5.1v17.1a4 4 0 1 1-2.8-3.8V9.5a7.8 7.8 0 1 0 6.7 7.7V8.7a8.5 8.5 0 0 0 5.1 1.7V6.5a5.3 5.3 0 0 1-5.1-3.4V.1h-3.9Z",
    twitch: "M2.1 0 .5 4.2v16.6h5.8V24h3.3l3.2-3.2h4.9L23 15.5V0H2.1Zm18.8 14.4-3.7 3.7h-5.8L8.2 21.3v-3.2H3.7V2.1h17.2v12.3ZM17 6.4v6.3h-2.1V6.4H17Zm-5.8 0v6.3H9.1V6.4h2.1Z",
    pinterest: "M12 0a12 12 0 0 0-4.4 23.2c0-.9 0-2.1.2-3.1l1.6-6.8s-.4-.8-.4-2c0-1.9 1.1-3.3 2.5-3.3 1.2 0 1.7.9 1.7 1.9 0 1.2-.7 2.9-1.1 4.5-.3 1.3.7 2.4 2 2.4 2.4 0 4-3.1 4-6.7 0-2.8-1.9-4.8-5.2-4.8-3.8 0-6.1 2.8-6.1 6 0 1.1.3 1.8.8 2.4.2.3.3.4.2.7l-.3 1c-.1.4-.3.5-.6.3C5.3 15 4.4 12.8 4.4 11c0-3.6 3-7.9 9-7.9 4.8 0 8 3.5 8 7.2 0 4.9-2.7 8.6-6.7 8.6-1.3 0-2.6-.7-3-1.6l-.9 3.3c-.3 1.1-.9 2.2-1.5 3.1 1.2.4 2.4.5 3.7.5a12 12 0 0 0 0-24Z",
    flickr: "M12 0a12 12 0 1 0 0 24 12 12 0 0 0 0-24ZM7 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8Zm10 0a4 4 0 1 1 0-8 4 4 0 0 1 0 8Z",
    reddit: "M12 0a12 12 0 1 0 0 24 12 12 0 0 0 0-24Zm6.3 13.4c0 .2.1.4.1.6 0 2.7-3.1 4.9-7 4.9s-7-2.2-7-4.9c0-.2 0-.4.1-.6a1.6 1.6 0 0 1 .8-3 1.6 1.6 0 0 1 1.1.5 8 8 0 0 1 4-1.3l.9-4 2.7.6a1.2 1.2 0 1 1 .1.6l-2.5-.5-.7 3.3a7.8 7.8 0 0 1 3.8 1.3 1.6 1.6 0 1 1 1.7 2.5ZM9.5 12.5a1.2 1.2 0 1 0 0 2.4 1.2 1.2 0 0 0 0-2.4Zm5 0a1.2 1.2 0 1 0 0 2.4 1.2 1.2 0 0 0 0-2.4Zm-5 4.1c1.2.8 3.7.8 4.9 0a.3.3 0 0 0-.4-.4c-1 .7-3.1.7-4.1 0a.3.3 0 0 0-.4.4Z",
    telegram: "M12 0a12 12 0 1 0 0 24 12 12 0 0 0 0-24Zm5.5 8.2-1.8 8.5c-.1.6-.5.7-1 .5l-2.8-2.1-1.3 1.3c-.2.2-.3.3-.6.3l.2-2.8 5.1-4.6c.2-.2 0-.3-.3-.1l-6.3 4-2.7-.8c-.6-.2-.6-.6.1-.8l10.6-4.1c.5-.2.9.1.8.7Z",
    whatsapp: "M17.5 14.4l-2-1c-.3-.1-.5-.2-.7.2l-1 1.2c-.2.2-.3.3-.6.1-.3-.1-1.3-.5-2.4-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6l.4-.5.3-.4c.1-.1.1-.3 0-.4l-1-2.4c-.3-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4-.3.3-1.2 1.2-1.2 2.8s1.2 3.3 1.4 3.5c.2.2 2.4 3.6 5.8 5.1.8.3 1.5.5 2 .7.8.3 1.6.2 2.2.1.7-.1 2-.8 2.3-1.6.3-.8.3-1.4.2-1.6-.1-.2-.3-.3-.6-.4ZM12 0a12 12 0 0 0-10.3 18l-1.7 5 5.2-1.4A12 12 0 1 0 12 0Z",
    linkedin: "M20.4 20.5h-3.6v-5.6c0-1.3 0-3-1.8-3s-2.1 1.4-2.1 2.9v5.7H9.3V9h3.4v1.6c.5-.9 1.6-1.8 3.3-1.8 3.5 0 4.2 2.3 4.2 5.3v6.3ZM5.3 7.4a2.1 2.1 0 1 1 0-4.2 2.1 2.1 0 0 1 0 4.2ZM7.1 20.5H3.5V9h3.6v11.5ZM22.2 0H1.8C.8 0 0 .8 0 1.8v20.4C0 23.2.8 24 1.8 24h20.4c1 0 1.8-.8 1.8-1.8V1.8C24 .8 23.2 0 22.2 0Z",
    discord: "M20.3 4.9A19.6 19.6 0 0 0 15.5 3a13.6 13.6 0 0 0-.6 1.3 18 18 0 0 0-5.4 0A12.5 12.5 0 0 0 8.9 3a19.5 19.5 0 0 0-4.8 1.9A20.6 20.6 0 0 0 .5 18.5a19.7 19.7 0 0 0 6 3 14.5 14.5 0 0 0 1.3-2.1 12.7 12.7 0 0 1-2-.9l.5-.4a14 14 0 0 0 12 0l.5.4a12.8 12.8 0 0 1-2 .9 14.5 14.5 0 0 0 1.3 2.1 19.6 19.6 0 0 0 6-3A20.5 20.5 0 0 0 20.3 5ZM8 15.6c-1.2 0-2.1-1.1-2.1-2.4s.9-2.4 2.1-2.4c1.2 0 2.2 1.1 2.1 2.4 0 1.3-.9 2.4-2.1 2.4Zm7.8 0c-1.2 0-2.1-1.1-2.1-2.4s.9-2.4 2.1-2.4c1.2 0 2.2 1.1 2.1 2.4 0 1.3-.9 2.4-2.1 2.4Z",
    medium: "M13.5 12a6.7 6.7 0 1 1-13.4 0 6.7 6.7 0 0 1 13.4 0Zm7.3 0c0 3.6-1.6 6.4-3.7 6.4S13.4 15.6 13.4 12s1.7-6.4 3.7-6.4 3.7 2.9 3.7 6.4Zm4.2 0c0 3.2-.6 5.8-1.3 5.8s-1.3-2.6-1.3-5.8.6-5.8 1.3-5.8 1.3 2.6 1.3 5.8Z",
  }
  return icons[platform] || icons.all
}

const thumbnails = [
  "/posts/post-1.jpg",
  "/posts/post-2.jpg",
  "/posts/post-3.jpg",
  "/posts/post-4.jpg",
  "/posts/post-5.jpg",
  "/posts/post-6.jpg",
]

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]
}

function generatePosts(): SocialPost[] {
  const templates: Omit<SocialPost, "id">[] = [
    // YouTube
    { platform: "youtube", title: "10X Your Productivity with This ONE Hack", caption: "I tried every productivity method for 30 days. Here's what actually worked... #productivity #lifehack", thumbnail: thumbnails[0], contentType: "video", badge: "trending", url: "https://youtube.com", likes: 48200, comments: 3100, shares: 8900, clicks: 125000, hashtags: ["productivity", "lifehack", "motivation"], date: "2026-02-08", aspectRatio: "landscape" },
    { platform: "youtube", title: "Building a $1M SaaS in 90 Days", caption: "The complete breakdown of how we went from zero to $1M ARR. Every tool, every decision, every mistake.", thumbnail: thumbnails[2], contentType: "video", badge: "popular", url: "https://youtube.com", likes: 92400, comments: 7800, shares: 23100, clicks: 340000, hashtags: ["saas", "startup", "business"], date: "2026-02-07", aspectRatio: "landscape" },
    { platform: "youtube", title: "The Algorithm Doesn't Want You to See This", caption: "Why your views dropped 80% and exactly how to fix it. Platform-by-platform breakdown.", thumbnail: thumbnails[5], contentType: "video", badge: "new", url: "https://youtube.com", likes: 15600, comments: 2200, shares: 5400, clicks: 67000, hashtags: ["algorithm", "growth", "socialmedia"], date: "2026-02-09", aspectRatio: "landscape" },

    // Instagram
    { platform: "instagram", title: "Golden Hour Magic", caption: "Chasing light through the streets of Tokyo. Every corner tells a different story. #photography #tokyo #goldenhour", thumbnail: thumbnails[1], contentType: "image", badge: "popular", url: "https://instagram.com", likes: 67800, comments: 1200, shares: 4500, clicks: 89000, hashtags: ["photography", "tokyo", "goldenhour", "travel"], date: "2026-02-08", aspectRatio: "portrait" },
    { platform: "instagram", title: "Behind the Scenes", caption: "What it actually takes to create one reel. 6 hours of work for 30 seconds of content.", thumbnail: thumbnails[0], contentType: "carousel", badge: "new", url: "https://instagram.com", likes: 23400, comments: 890, shares: 2100, clicks: 45000, hashtags: ["bts", "contentcreator", "reels"], date: "2026-02-09", aspectRatio: "square" },
    { platform: "instagram", title: "Street Food That Changed My Life", caption: "Found this hidden gem in a back alley in Bangkok. The flavors are unreal. Full guide in bio.", thumbnail: thumbnails[3], contentType: "image", badge: "trending", url: "https://instagram.com", likes: 54200, comments: 3400, shares: 12000, clicks: 156000, hashtags: ["streetfood", "bangkok", "foodie"], date: "2026-02-06", aspectRatio: "portrait" },

    // Facebook
    { platform: "facebook", title: "Community Meetup Recap", caption: "Over 500 people showed up to our monthly community meetup. The energy was incredible. Next one is March 15th!", thumbnail: thumbnails[4], contentType: "image", badge: "popular", url: "https://facebook.com", likes: 12300, comments: 456, shares: 2800, clicks: 34000, hashtags: ["community", "meetup", "networking"], date: "2026-02-07", aspectRatio: "landscape" },
    { platform: "facebook", title: "We're Hiring - 5 Positions Open", caption: "Join our growing team. Remote-first, competitive salary, and a mission that matters.", thumbnail: thumbnails[2], contentType: "text", badge: null, url: "https://facebook.com", likes: 5600, comments: 234, shares: 8900, clicks: 67000, hashtags: ["hiring", "remotejobs", "careers"], date: "2026-02-05", aspectRatio: "landscape" },

    // X (Twitter)
    { platform: "x", title: "Hot Take: AI Won't Replace Developers", caption: "Unpopular opinion: AI tools make good developers better and bad developers worse. Here's my reasoning in a thread...", thumbnail: thumbnails[2], contentType: "text", badge: "trending", url: "https://x.com", likes: 34500, comments: 8900, shares: 12000, clicks: 230000, hashtags: ["AI", "programming", "tech"], date: "2026-02-09", aspectRatio: "landscape" },
    { platform: "x", title: "The Framework Wars Are Over", caption: "After 10 years of framework churn, we've finally converged on the patterns that work. A thread on what survived.", thumbnail: thumbnails[5], contentType: "text", badge: "popular", url: "https://x.com", likes: 28900, comments: 4500, shares: 9800, clicks: 178000, hashtags: ["webdev", "javascript", "frameworks"], date: "2026-02-08", aspectRatio: "landscape" },

    // TikTok
    { platform: "tiktok", title: "POV: You Finally Understand Recursion", caption: "When the concept clicks and you see the matrix #coding #programming #devtok", thumbnail: thumbnails[2], contentType: "video", badge: "trending", url: "https://tiktok.com", likes: 234000, comments: 12000, shares: 45000, clicks: 890000, hashtags: ["coding", "programming", "devtok", "tech"], date: "2026-02-09", aspectRatio: "portrait" },
    { platform: "tiktok", title: "Day in the Life: Startup Founder", caption: "5am wake up, gym, 14 hours of coding, repeat. Here's what nobody tells you about startup life.", thumbnail: thumbnails[4], contentType: "video", badge: "new", url: "https://tiktok.com", likes: 89000, comments: 5600, shares: 23000, clicks: 450000, hashtags: ["startup", "founder", "dayinthelife"], date: "2026-02-08", aspectRatio: "portrait" },

    // Twitch
    { platform: "twitch", title: "24-Hour Coding Marathon - LIVE", caption: "Building an entire SaaS product live from scratch. Chat decides the features. !commands in chat.", thumbnail: thumbnails[2], contentType: "video", badge: "featured", url: "https://twitch.tv", likes: 12300, comments: 45000, shares: 3400, clicks: 89000, hashtags: ["coding", "live", "twitch", "marathon"], date: "2026-02-08", aspectRatio: "landscape" },

    // Pinterest
    { platform: "pinterest", title: "Minimal Desk Setup Inspiration", caption: "Clean, focused, and aesthetic. 15 desk setups that will make you want to redesign your workspace.", thumbnail: thumbnails[2], contentType: "image", badge: "popular", url: "https://pinterest.com", likes: 45000, comments: 890, shares: 34000, clicks: 230000, hashtags: ["desksetup", "minimal", "workspace", "aesthetic"], date: "2026-02-07", aspectRatio: "portrait" },

    // Reddit
    { platform: "reddit", title: "[Guide] Complete Next.js Production Checklist", caption: "After deploying 50+ Next.js apps to production, here's the checklist I wish I had on day one. r/nextjs", thumbnail: thumbnails[5], contentType: "text", badge: "trending", url: "https://reddit.com", likes: 8900, comments: 567, shares: 2300, clicks: 67000, hashtags: ["nextjs", "webdev", "guide"], date: "2026-02-09", aspectRatio: "landscape" },
    { platform: "reddit", title: "Show HN: I Built a Real-Time Collab Editor", caption: "Open source, self-hostable, and works offline. Built with CRDTs. Feedback welcome!", thumbnail: thumbnails[2], contentType: "text", badge: "new", url: "https://reddit.com", likes: 4500, comments: 234, shares: 1200, clicks: 34000, hashtags: ["showhn", "opensource", "webdev"], date: "2026-02-08", aspectRatio: "landscape" },

    // Telegram
    { platform: "telegram", title: "Exclusive: Early Access Drop", caption: "New product launching next week. Telegram subscribers get 48-hour early access + bonus content.", thumbnail: thumbnails[0], contentType: "text", badge: "featured", url: "https://t.me", likes: 6700, comments: 345, shares: 4500, clicks: 45000, hashtags: ["exclusive", "earlyaccess", "launch"], date: "2026-02-09", aspectRatio: "landscape" },

    // LinkedIn
    { platform: "linkedin", title: "I Got Rejected from 147 Jobs Before Landing My Dream Role", caption: "The job market is brutal. But here's what I learned from 147 rejections that most people won't tell you. A thread on resilience.", thumbnail: thumbnails[4], contentType: "text", badge: "trending", url: "https://linkedin.com", likes: 78900, comments: 4500, shares: 12000, clicks: 340000, hashtags: ["careers", "jobsearch", "motivation", "linkedin"], date: "2026-02-08", aspectRatio: "landscape" },

    // Discord
    { platform: "discord", title: "Server Hit 100K Members", caption: "Our Discord community just crossed 100,000 members. Massive giveaway happening NOW to celebrate.", thumbnail: thumbnails[5], contentType: "image", badge: "popular", url: "https://discord.gg", likes: 23000, comments: 8900, shares: 5600, clicks: 120000, hashtags: ["discord", "community", "milestone"], date: "2026-02-07", aspectRatio: "landscape" },

    // WhatsApp Business
    { platform: "whatsapp", title: "Flash Sale: 48 Hours Only", caption: "Exclusive WhatsApp-only deal. 40% off everything in store. Reply DEAL to claim your code.", thumbnail: thumbnails[3], contentType: "text", badge: "new", url: "https://wa.me", likes: 3400, comments: 890, shares: 6700, clicks: 45000, hashtags: ["sale", "exclusive", "deal"], date: "2026-02-09", aspectRatio: "square" },

    // Flickr
    { platform: "flickr", title: "Urban Decay Photography Series", caption: "Finding beauty in abandoned architecture. 35mm film, no edits. #photography #urbex #filmphotography", thumbnail: thumbnails[1], contentType: "image", badge: null, url: "https://flickr.com", likes: 4500, comments: 234, shares: 1200, clicks: 23000, hashtags: ["photography", "urbex", "film"], date: "2026-02-06", aspectRatio: "landscape" },

    // Medium
    { platform: "medium", title: "Why Senior Developers Write Less Code", caption: "The counterintuitive truth about engineering seniority: your value is inversely proportional to your lines of code.", thumbnail: thumbnails[2], contentType: "text", badge: "popular", url: "https://medium.com", likes: 12300, comments: 567, shares: 4500, clicks: 89000, hashtags: ["programming", "career", "engineering"], date: "2026-02-07", aspectRatio: "landscape" },
  ]

  return templates.map((t, i) => ({ ...t, id: `post-${i + 1}` }))
}

export const MOCK_POSTS = generatePosts()

export function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`
  return n.toString()
}

export function getRelativeTime(dateStr: string): string {
  const now = new Date("2026-02-09")
  const date = new Date(dateStr)
  const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))
  if (diffDays === 0) return "Today"
  if (diffDays === 1) return "Yesterday"
  if (diffDays < 7) return `${diffDays}d ago`
  return `${Math.floor(diffDays / 7)}w ago`
}
